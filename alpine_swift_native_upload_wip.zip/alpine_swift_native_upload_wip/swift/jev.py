"""TypeSafe Jev: one fan-out request per step, strict answer validation, shuffled-order check.

``action_space`` and ``validate_choice`` are ported from browser-use/jev-ultrafast ``model.py``
(MIT, Copyright (c) 2026 Browser Use). Requests go straight to ``POST /v1/systemone`` over one
persistent HTTP/2 client with the model pinned; an invalid answer executes nothing.
"""

from __future__ import annotations

import heapq
import itertools
import math
import random
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Optional

from . import redact
from .config import secret, settings
from .questions import BLOCKERS, LAST_ACTION_WORKED, NEXT_ACTION, RISKS, STILL_LOADING, SUBGOAL_DONE, TARGET

PRIORITY_LIVE, PRIORITY_CHECK, PRIORITY_SPECULATIVE = 0, 1, 2
OPERATIONS = {"click": "CLICK", "fill": "TYPE_TEXT", "select": "SELECT", "enter": "PRESS_ENTER"}
OPERATION_LABELS = {
    "CLICK": "Click an element, button, menu option, autocomplete suggestion, or calendar day.",
    "TYPE_TEXT": "Fill the form an editable field belongs to. Code and a small LLM supply values from the goal.",
    "SELECT": "Select an observed dropdown value.",
    "PRESS_ENTER": "Press Enter in a filled text field that has no submit button, to submit or add its value.",
}
ELEMENT_KEYS = ("role", "value", "checked", "selected", "expanded", "heading", "row", "sensitive")
RISK_ORDER = {"read_only": 0, "reversible": 1, "irreversible": 2}
IRREVERSIBLE_WORDS = re.compile(
    r"\b(pay|payment|place order|buy now|purchase|checkout|confirm|submit|transfer|send money|book now|"
    r"delete|remove account|apply now|finish|proceed to pay|complete order|sign up|register|send)\b", re.I)
PAYMENT_WORDS = re.compile(r"\b(pay|payment|purchase|buy now|place order|transfer|send money|proceed to pay)\b", re.I)


class InvalidAnswer(ValueError):
    """Jev returned something that does not validate; nothing is executed."""


class JevUnavailable(RuntimeError):
    pass


# ------------------------------------------------------------------ validation


def validate_choice(answer: Any, ids) -> dict:
    try:
        probabilities = answer["probabilities"]
        numbers = [*probabilities.values(), answer["confidence"]]
        valid = (
            answer["choice"] in ids
            and set(probabilities) == set(ids)
            and all(type(n) in (int, float) and math.isfinite(n) and 0 <= n <= 1 for n in numbers)
            and abs(sum(probabilities.values()) - 1) < 0.02
            and probabilities[answer["choice"]] >= max(probabilities.values()) - 1e-6
        )
    except (KeyError, TypeError, ValueError, AttributeError):
        valid = False
    if not valid:
        raise InvalidAnswer("Invalid TypeSafe response; no action executed.")
    return answer


def validate_noul(answer: Any) -> float:
    try:
        value = answer["noul"]
        if type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1:
            return float(value)
    except (KeyError, TypeError):
        pass
    raise InvalidAnswer("Invalid TypeSafe noul; no action executed.")


# ------------------------------------------------------------------ action space


def action_space(actions: list[dict]):
    """One index per observed element; each operation has its own valid target choices."""
    elements, indices, targets, controls = [], {}, {}, {}
    for action in actions:
        kind = action["kind"]
        if kind not in OPERATIONS:
            controls[action["id"].upper()] = action
            continue
        node = action.get("vkey") or action["node"]  # board squares share a DOM node but are distinct targets
        if node not in indices:
            index = str(len(elements) + 1)
            indices[node] = index
            element = {k: action[k] for k in ELEMENT_KEYS if k in action}
            ftype = (action.get("field") or {}).get("type")
            if ftype:
                element["type"] = ftype  # textarea vs text input vs checkbox
            element.update(index=index, label=action["label"].split(" → ")[0], operations=[])
            if kind == "select":
                element["value"] = action.get("current_value", "")
                element["options"] = []
            elements.append(element)
        index = indices[node]
        operation = OPERATIONS[kind]
        group = targets.setdefault(operation, {})
        element = elements[int(index) - 1]
        if operation not in element["operations"]:
            element["operations"].append(operation)
        target = index
        if kind == "select":
            target = f"{index}:{len(element['options']) + 1}"
            element["options"].append({"index": target, "label": action["label"], "value": action["value"]})
        group[target] = action
    return elements, targets, controls


def code_risk(action: Optional[dict]) -> str:
    """A floor on risk from the element itself, so a mislabelled Jev answer cannot lower it."""
    if not action or action.get("kind") in ("scroll", "wait"):
        return "read_only"
    label = action.get("label", "")
    if action.get("kind") == "click" and action.get("role") in ("button", "link", "menuitem", "clickable") \
            and IRREVERSIBLE_WORDS.search(label):
        return "irreversible"
    if action.get("kind") == "enter":
        # Enter in a form field may submit the form; in a search box or outside a form it adds or searches.
        f = action.get("field") or {}
        if action.get("form") is not None and not f.get("search") and f.get("type") != "search" \
                and action.get("role") != "searchbox":
            return "irreversible"
        return "reversible"
    if action.get("kind") in ("fill", "select") or action.get("role") in ("checkbox", "radio", "switch"):
        return "reversible"
    return "read_only"


def is_payment(action: Optional[dict]) -> bool:
    """A control that pays: a short imperative label ("Pay ₹500", "Place order", "Proceed to pay"). A long label
    is content (a to-do "pay rent", a card's text), not a payment control; it is still irreversible by
    ``code_risk`` and the reviewer still refuses payments."""
    label = (action or {}).get("label", "")
    return bool(action and len(label.split()) <= 8 and PAYMENT_WORDS.search(label))


# ------------------------------------------------------------------ client


class _PriorityGate:
    """A counting semaphore that admits waiters by (priority, arrival)."""

    def __init__(self, size: int):
        self._free = size
        self._heap: list = []
        self._cv = threading.Condition()
        self._seq = itertools.count()

    def acquire(self, priority: int) -> None:
        with self._cv:
            me = (priority, next(self._seq))
            heapq.heappush(self._heap, me)
            while not (self._free > 0 and self._heap[0] == me):
                self._cv.wait()
            heapq.heappop(self._heap)
            self._free -= 1
            self._cv.notify_all()

    def release(self) -> None:
        with self._cv:
            self._free += 1
            self._cv.notify_all()


class JevClient:
    def __init__(self, *, model: Optional[str] = None, url: Optional[str] = None, api_key: Optional[str] = None,
                 concurrency: Optional[int] = None, post: Optional[Callable[[dict], dict]] = None):
        cfg = settings()
        self.model = model or cfg.get("jev_model", "jev-1.14.0")
        self.url = url or cfg.get("jev_url")
        self._key = api_key or secret(cfg.get("jev_key_env", "TYPESAFE_API_KEY"))
        self._post = post
        self._client = None
        size = int(concurrency or cfg.get("jev_concurrency", 18))
        self._gate = _PriorityGate(size)
        self._pool = ThreadPoolExecutor(max_workers=size, thread_name_prefix="swift-jev")
        self.calls = 0
        self.latencies: list[int] = []

    def _http(self):
        if self._client is None:
            import httpx

            self._client = httpx.Client(http2=True, timeout=httpx.Timeout(10.0, connect=5.0),
                                        limits=httpx.Limits(max_connections=32, max_keepalive_connections=32))
        return self._client

    def ask(self, state: dict, questions: dict, priority: int = PRIORITY_LIVE) -> dict:
        """One System One request; returns the raw ``answers`` dict plus metadata."""
        body = {"model": self.model, "state": redact.scrub(state), "questions": questions}
        self._gate.acquire(priority)
        started = time.perf_counter()
        try:
            if self._post is not None:
                result = self._post(body)
            else:
                if not self._key:
                    raise JevUnavailable("TYPESAFE_API_KEY is not set; no action executed.")
                result = self._send(body)
        finally:
            self._gate.release()
        latency = round((time.perf_counter() - started) * 1000)
        self.calls += 1
        self.latencies.append(latency)
        if not isinstance(result, dict) or not isinstance(result.get("answers"), dict):
            raise InvalidAnswer("TypeSafe returned no answers; no action executed.")
        if self._post is None and result.get("model") and not str(result["model"]).startswith(self.model):
            raise InvalidAnswer(f"TypeSafe answered with {result['model']}, not the pinned {self.model}.")
        return {**result, "latency_ms": latency}

    def submit(self, state: dict, questions: dict, priority: int = PRIORITY_LIVE):
        return self._pool.submit(self.ask, state, questions, priority)

    def _send(self, body: dict) -> dict:
        import httpx

        for attempt in range(3):
            try:
                response = self._http().post(self.url, json=body, headers={"Authorization": f"Bearer {self._key}"})
            except httpx.HTTPError:
                if attempt < 2:
                    time.sleep(0.2 * 2 ** attempt)
                    continue
                raise JevUnavailable("TypeSafe connection failed; no action executed.") from None
            if response.status_code in {429, 503, 529} and attempt < 2:
                time.sleep(0.5 * 2 ** attempt)
                continue
            if response.is_error:
                # TypeSafe's own message (e.g. 402 "no available TypeSafe API credits ... add more credits at
                # https://console.typesafe.ai/settings/billing") tells the user what to do; never our request.
                detail = ""
                try:
                    d = response.json().get("detail")
                    detail = str(d.get("message") if isinstance(d, dict) else d or "")[:200]
                except Exception:
                    pass
                raise JevUnavailable(f"TypeSafe returned HTTP {response.status_code}"
                                     + (f": {detail}" if detail else "") + "; no action executed.")
            return response.json()
        raise JevUnavailable("TypeSafe unavailable")

    # ------------------------------------------------------------------ single-purpose questions

    def noul(self, state: dict, instructions: str, priority: int = PRIORITY_CHECK) -> float:
        result = self.ask(state, {"q": {"type": "noul", "instructions": instructions}}, priority)
        return validate_noul(result["answers"].get("q"))

    def choice(self, state: dict, instructions: Any, criteria: dict, priority: int = PRIORITY_CHECK) -> dict:
        result = self.ask(state, {"q": {"type": "choice", "instructions": instructions, "criteria": criteria}},
                          priority)
        return validate_choice(result["answers"].get("q"), criteria)

    def close(self) -> None:
        self._pool.shutdown(wait=False, cancel_futures=True)
        if self._client is not None:
            self._client.close()


# ------------------------------------------------------------------ the step request


def _goal_text(subgoal: str, goal: str) -> str:
    """The text Jev advances. jev-ultrafast's shape: one ``goal`` string. With a plan, that is the current
    subgoal; the overall goal goes in the state as context only. (A/B on the hotel task, NOTES.md: putting
    subgoal and overall goal side by side in the instructions made Jev skip the filters every time.)"""
    return subgoal or goal


def _state(page: dict, elements: list, subgoal: str, goal: str, history: list) -> dict:
    state = {
        "page": {k: page.get(k) for k in ("url", "title", "text")},
        "elements": elements,
        "recent_actions": [{k: h.get(k) for k in ("action", "kind", "text", "page_changed")} for h in history[-10:]],
    }
    if subgoal and goal and subgoal.strip() != goal.strip():
        state["overall_task"] = goal
    return state


def _shuffled(d: dict, rng: random.Random) -> dict:
    items = list(d.items())
    rng.shuffle(items)
    return dict(items)


def build_questions(page: dict, subgoal: str, goal: str, *, shuffle: Optional[random.Random] = None,
                    checks: bool = True):
    elements, targets, controls = action_space(page["actions"])
    operations = {key: OPERATION_LABELS[key] for key in targets}
    operations.update({key: value["label"] for key, value in controls.items()})
    operations.update(DONE="Every requirement is visibly satisfied.",
                      BLOCKED="No supported operation can progress.")
    text = _goal_text(subgoal, goal)
    if shuffle:
        operations = _shuffled(operations, shuffle)
    questions: dict[str, dict] = {"operation": {"type": "choice", "criteria": operations,
                                                "instructions": {"goal": text, "rules": NEXT_ACTION}}}
    for operation, candidates in targets.items():
        criteria = {
            index: {
                "element": f"[{index}] {a['label']}",
                "current_value": a.get("current_value", a.get("value", "")),
                **{k: a[k] for k in ("role", "checked", "selected", "expanded", "heading", "row") if k in a},
                **({"type": a["field"]["type"]} if (a.get("field") or {}).get("type") else {}),
            }
            for index, a in candidates.items()
        }
        if shuffle:
            criteria = _shuffled(criteria, shuffle)
        questions[operation.lower() + "_target"] = {
            "type": "choice", "criteria": criteria,
            "instructions": {"goal": text, "operation": operation, "rules": [NEXT_ACTION, TARGET]},
        }
    if checks:
        questions.update(
            subgoal_done={"type": "noul", "instructions": {"goal": text, "question": SUBGOAL_DONE}},
            last_action_worked={"type": "noul", "instructions": LAST_ACTION_WORKED},
            still_loading={"type": "noul", "instructions": STILL_LOADING},
            blocker_present={"type": "choice", "criteria": BLOCKERS,
                             "instructions": {"goal": text, "question": "What, if anything, blocks the goal?"}},
            risk_level={"type": "choice", "criteria": RISKS,
                        "instructions": {"goal": text, "rules": NEXT_ACTION,
                                         "question": "How risky is the single next action that advances the goal?"}},
        )
    return elements, targets, controls, operations, questions


def parse_decision(result: dict, targets: dict, controls: dict, operations: dict, *, checks: bool = True) -> dict:
    answers = result["answers"]
    op_answer = validate_choice(answers.get("operation"), operations)
    operation = op_answer["choice"]
    target, target_answer, probabilities = None, None, {}
    if operation in targets:
        # Unused target heads cannot cause an action. Validate the head selected by the operation.
        target_answer = validate_choice(answers.get(operation.lower() + "_target"), targets[operation])
        target = target_answer["choice"]
        choice = targets[operation][target]["id"]
        probabilities = {a["id"]: target_answer["probabilities"][i] for i, a in targets[operation].items()}
    else:
        choice = controls[operation]["id"] if operation in controls else operation
        probabilities[choice] = op_answer["probabilities"][operation]
    decision = {
        "choice": choice, "operation": operation, "target": target,
        "confidence": op_answer["confidence"],
        "target_confidence": target_answer["confidence"] if target_answer else None,
        "probabilities": probabilities,
        "operation_probabilities": op_answer["probabilities"],
        "latency_ms": result.get("latency_ms"), "usage": result.get("usage", {}), "model": result.get("model"),
    }
    if checks:
        decision["nouls"] = {k: validate_noul(answers.get(k)) for k in ("subgoal_done", "last_action_worked",
                                                                         "still_loading")}
        decision["blocker"] = validate_choice(answers.get("blocker_present"), BLOCKERS)["choice"]
        risk = validate_choice(answers.get("risk_level"), RISKS)
        decision["jev_risk"] = risk["choice"]
        decision["risk_confidence"] = risk["confidence"]
    return decision


def candidates(answers: dict, targets: dict, controls: dict, operations: dict, top: int = 6) -> list[dict]:
    """Jev's most likely concrete actions (P(operation) x P(target)), for the planner to choose between when Jev
    is unsure. Only observed action ids; DONE / BLOCKED are never candidates."""
    try:
        ops = validate_choice(answers.get("operation"), operations)["probabilities"]
    except InvalidAnswer:
        return []
    scored = []
    for op, p_op in ops.items():
        if op in targets:
            try:
                head = validate_choice(answers.get(op.lower() + "_target"), targets[op])
            except InvalidAnswer:
                continue
            for index, p in head["probabilities"].items():
                scored.append((p_op * p, targets[op][index]["id"], op))
        elif op in controls:
            scored.append((p_op, controls[op]["id"], op))
    scored.sort(key=lambda x: -x[0])
    return [{"id": aid, "operation": op, "score": round(s, 3)} for s, aid, op in scored[:top]]


def decide(client: JevClient, page: dict, subgoal: str, goal: str, history: list, *,
           shuffled_check: bool = False, seed: Optional[int] = None, reorder: Optional[int] = None) -> dict:
    """The live step decision; optionally the shuffled-order twin request sent at the same time.
    ``reorder`` shuffles the live request's own options (a second opinion on a low-confidence answer)."""
    elements, targets, controls, operations, questions = build_questions(
        page, subgoal, goal, shuffle=random.Random(reorder) if reorder is not None else None)
    state = _state(page, elements, subgoal, goal, history)
    twin = None
    if shuffled_check:
        rng = random.Random(seed if seed is not None else time.time_ns())
        _, t2, c2, ops2, q2 = build_questions(page, subgoal, goal, shuffle=rng, checks=False)
        twin = client.submit(state, q2, PRIORITY_CHECK)
    result = client.ask(state, questions, PRIORITY_LIVE)
    decision = parse_decision(result, targets, controls, operations)
    decision["candidates"] = candidates(result["answers"], targets, controls, operations, top=25)
    action = _action_for(page, decision["choice"])
    decision["action"] = action
    decision["code_risk"] = code_risk(action)
    decision["risk"] = max(decision["jev_risk"], decision["code_risk"], key=RISK_ORDER.get)
    decision["agree"] = None
    if twin is not None:
        decision["agree"] = _agree(decision, twin, t2, c2, ops2)
    return decision


def shuffled_agrees(client: JevClient, page: dict, subgoal: str, goal: str, history: list, decision: dict,
                    seed: Optional[int] = None) -> bool:
    """Re-ask with options in a new order; True only if the same element is chosen."""
    elements, _, _, _, _ = build_questions(page, subgoal, goal, checks=False)
    rng = random.Random(seed if seed is not None else time.time_ns())
    _, t2, c2, ops2, q2 = build_questions(page, subgoal, goal, shuffle=rng, checks=False)
    fut = client.submit(_state(page, elements, subgoal, goal, history), q2, PRIORITY_CHECK)
    return _agree(decision, fut, t2, c2, ops2)


def _agree(decision: dict, fut, targets, controls, operations) -> bool:
    try:
        other = parse_decision(fut.result(timeout=15), targets, controls, operations, checks=False)
    except Exception:
        return False
    decision["shuffled"] = {k: other[k] for k in ("choice", "operation", "confidence", "target_confidence")}
    if other["operation"] != decision["operation"]:
        return False
    if other["choice"] == decision["choice"]:
        return True
    # TYPE_TEXT fills the whole form the chosen field belongs to: two picks in the same form are the same action.
    if decision["operation"] == "TYPE_TEXT":
        mine = decision.get("action") or {}
        theirs = next((a for a in targets.get("TYPE_TEXT", {}).values() if a["id"] == other["choice"]), {})
        return mine.get("form") is not None and mine.get("form") == theirs.get("form")
    return False


def form_mass(decision: dict, page: dict) -> Optional[float]:
    """For TYPE_TEXT: the probability Jev gives to all fields of the chosen field's form (the unit that is
    actually filled). None when the field has no form."""
    action = decision.get("action") or {}
    form = action.get("form")
    if decision.get("operation") != "TYPE_TEXT" or form is None:
        return None
    by_id = {a["id"]: a for a in page.get("actions", [])}
    return sum(p for aid, p in (decision.get("probabilities") or {}).items()
               if (by_id.get(aid) or {}).get("form") == form)


def _action_for(page: dict, choice: str) -> Optional[dict]:
    return next((a for a in page["actions"] if a["id"] == choice), None)
