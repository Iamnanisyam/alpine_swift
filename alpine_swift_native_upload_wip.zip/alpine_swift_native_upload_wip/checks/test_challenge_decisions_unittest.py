"""Tests for visible evidence and decision gating; no browser or network."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from swift import config
from swift.loop import FastLoop, LoopContext, Subgoal, Control

class Page:
    def __init__(self,visible): self.visible=visible;self.tab_id='T1'
    def observe(self): return {'tab_id':'T1','marker':['same'],'actions':[]}
    def fresh(self,*a):return True
    def challenge_visible(self):return self.visible

class Tests(unittest.TestCase):
    def run_loop(self,visible,decisions):
        config.configure({})
        page=Page(visible);ctx=LoopContext(page=page,jev=None,goal='x',trace=None,control=Control(),max_steps=2)
        fast=FastLoop(ctx,Subgoal('x',{},'read_only'))
        fast.verify=lambda _: {'passed':False}
        calls=[]
        def wait(obs,reason):calls.append(reason);return obs
        fast.wait_for_challenge=wait
        fast._gate=lambda *a:(True,'ok')
        fast.execute=lambda *a:{'executed':'x'}
        fast.after=lambda *a:page.observe()
        def decide(*args,**kwargs):return decisions.pop(0)
        with patch('swift.loop.jevmod.decide',side_effect=decide):
            result=fast.run()
        return result,calls,ctx.history

    @staticmethod
    def decision(blocker,op):
        return {'blocker':blocker,'operation':op,'choice':'x','confidence':1,'target_confidence':1,
                'action':{'id':'x','kind':'click','label':'Continue'},'nouls':{}}

    def test_unrelated_visible_challenge_does_not_preempt_goal(self):
        ds=[self.decision('none','CLICK'),self.decision('none','CLICK')]
        _,calls,_=self.run_loop(True,ds)
        self.assertEqual(calls,[])

    def test_model_suspicion_without_visible_evidence_does_not_handoff(self):
        ds=[self.decision('captcha','BLOCKED'),self.decision('none','CLICK')]
        _,calls,history=self.run_loop(False,ds)
        self.assertEqual(calls,[])
        self.assertTrue(any('No visible challenge' in h.get('action','') for h in history))

    def test_confirmed_blocking_otp_handoffs(self):
        ds=[self.decision('otp','BLOCKED'),self.decision('none','CLICK'),self.decision('none','CLICK')]
        _,calls,_=self.run_loop(True,ds)
        self.assertEqual(calls,['otp'])

if __name__=='__main__':unittest.main()
