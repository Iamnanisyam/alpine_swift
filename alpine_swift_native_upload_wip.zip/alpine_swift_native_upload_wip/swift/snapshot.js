// Ported from browser-use/jev-ultrafast snapshot.js (MIT, Copyright (c) 2026 Browser Use).
// Extended for hermes-swift: heading/label context, masked sensitive fields, form grouping,
// field metadata for validators, capped per-select options. Geometry is still resolved and
// hit-tested just before input; node ids are code-owned and never come from a model.
(() => {
  if (!document.body) return null;
  const cfg = window.__swiftConfig || {};
  const cache = window.__jevFast ||= {ids:new WeakMap(), nodes:new Map(), next:1};
  const identity = e => {
    if (!cache.ids.has(e)) cache.ids.set(e,cache.next++);
    const id=cache.ids.get(e); cache.nodes.set(id,e); return id;
  };
  for (const [id,e] of cache.nodes) if (!e.isConnected) cache.nodes.delete(id);
  const idPatterns=(cfg.idPatterns||[]).map(p=>{try{return new RegExp(p,'i')}catch(_){return null}}).filter(Boolean);
  const hidden = e => ['file','hidden'].includes(e.type);
  const describe = e => [e.getAttribute('name'),e.id,e.getAttribute('placeholder'),e.getAttribute('aria-label'),
    [...(e.labels||[])].map(l=>l.innerText).join(' ')].filter(Boolean).join(' ');
  // Values of these fields never leave the page in clear text.
  const sensitive = e => {
    if (!(e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement)) return null;
    if (e.type==='password') return 'password';
    const ac=(e.getAttribute('autocomplete')||'').toLowerCase(), d=describe(e).toLowerCase();
    if (ac.startsWith('cc-') || /\b(card ?number|cardnumber|cc-?num|cvv|cvc|security code|expiry|exp-?date)\b/.test(d)) return 'card';
    if (ac==='one-time-code' || /\b(otp|one[- ]time|verification code)\b/.test(d)) return 'otp';
    // An ID field asks for the number itself: "Aadhaar number", "PAN", "Passport no." — not "Name as on Aadhaar".
    if (idPatterns.some(r=>r.test(d)) && !(/\bname\b|\baddress\b|\bdate\b|\bemail\b/.test(d) &&
        !/\b(number|no\.?|num|id)\b/.test(d.replace(/\bname\b/g,'')))) return 'id';
    return null;
  };
  cache.sensitive = sensitive;
  const hash = s => { let h=5381; for (let i=0;i<s.length;i++) h=((h<<5)+h+s.charCodeAt(i))|0; return 'h'+(h>>>0).toString(36)+':'+s.length; };
  const valueOf = e => sensitive(e) ? (e.value ? hash(e.value) : '') :
    e.tagName==='SELECT' && e.multiple ? [...e.selectedOptions].map(o=>o.value).join('\u0001') : e.value;
  const masked = e => sensitive(e) ? (e.value ? '[masked]' : '') : String(e.value);
  const visible = e => !e.closest('[aria-hidden="true"],[inert]') &&
    e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true});
  // A field's visual label when it has no programmatic one: the closest preceding sibling (or the parent's
  // own text) that is short text, as in <label>Username</label><input> without for=, or "Name: <input>".
  const visualLabel = e => {
    if (!['INPUT','TEXTAREA','SELECT'].includes(e.tagName)) return '';
    for (let s=e.previousSibling, hops=0; s && hops<4; s=s.previousSibling, hops++) {
      if (s.nodeType===1 && ['INPUT','TEXTAREA','SELECT','BUTTON'].includes(s.tagName)) break;
      const t=(s.nodeType===3 ? s.textContent : s.nodeType===1 ? s.innerText : '').replace(/\s+/g,' ').trim();
      if (t) return t.length<=60 ? t.replace(/[:*]\s*$/,'') : '';
    }
    const p=e.parentElement;
    if (p && p.children.length<=3) {
      const t=[...p.childNodes].filter(n=>n.nodeType===3).map(n=>n.textContent).join(' ').replace(/\s+/g,' ').trim();
      if (t && t.length<=60) return t.replace(/[:*]\s*$/,'');
    }
    return '';
  };
  const name = (e,seen=new Set()) => {
    if (!e || seen.has(e)) return '';
    seen.add(e);
    const referenced=(e.getAttribute('aria-labelledby')||'').split(/\s+/)
      .map(id=>name(document.getElementById(id),seen)).filter(Boolean).join(' ');
    return referenced || e.getAttribute('aria-label') ||
      [...(e.labels||[])].map(l=>name(l,seen)).filter(Boolean).join(' ') ||
      (['button','submit','reset'].includes(e.type) ? e.value : '') || e.getAttribute('alt') ||
      (['INPUT','SELECT','TEXTAREA'].includes(e.tagName) ? '' : [...e.childNodes].map(n=>n.nodeType===3 ? n.textContent :
        n.nodeType===1 && n.getAttribute('aria-hidden')!=='true' ? name(n,seen) : '').join(' ').trim()) ||
      e.getAttribute('title') || e.getAttribute('placeholder') || visualLabel(e) ||
      (['INPUT','SELECT','TEXTAREA'].includes(e.tagName) ? (e.getAttribute('name')||e.id||'').replace(/[_-]+/g,' ') : '');
  };
  // Click handlers registered by common libraries are visible on the element without patching the page:
  // d3 (v3 __onclick, v4+ __on), jQuery's data store, React props and Vue 3 invokers.
  const CLICKS=/^(click|mousedown|mouseup|pointerdown|pointerup|dblclick)$/;
  const hasHandler = e => {
    if (typeof e.onclick==='function' || typeof e.onmousedown==='function' || e.hasAttribute('onclick') ||
        e.hasAttribute('onmousedown')) return true;
    if (e.__onclick || e.__onmousedown) return true;
    if (Array.isArray(e.__on) && e.__on.some(h=>CLICKS.test(h.type))) return true;
    const jq=window.jQuery;
    if (jq && typeof jq._data==='function') {
      const ev=jq._data(e,'events');
      if (ev && (ev.click || ev.mousedown || ev.mouseup)) return true;
    }
    for (const k of Object.keys(e)) {
      if (k.startsWith('__reactProps$')) {
        const p=e[k];
        if (p && (p.onClick || p.onMouseDown || p.onPointerDown || p.onMouseUp)) return true;
      }
    }
    if (e._vei && (e._vei.onClick || e._vei.onMousedown || e._vei.onPointerdown)) return true;
    return false;
  };
  const clip = (s,n=80) => (s||'').replace(/\s+/g,' ').trim().slice(0,n);
  const HEADINGS='h1,h2,h3,h4,h5,h6,[role="heading"],legend,caption';
  const headingCache=new Map();
  // The nearest heading that precedes the element inside one of its ancestors.
  const heading = e => {
    let a=e.parentElement;
    for (let depth=0; a && depth<8; depth++, a=a.parentElement) {
      if (!headingCache.has(a)) headingCache.set(a,[...a.querySelectorAll(HEADINGS)].filter(h=>visible(h)));
      const before=headingCache.get(a).filter(h=>h!==e && !h.contains(e) &&
        (h.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_FOLLOWING || h.contains(e)));
      if (before.length) return clip(before[before.length-1].innerText);
      if (a===document.body) break;
    }
    return '';
  };
  const roles=['button','link','checkbox','radio','switch','tab','menuitem','menuitemradio',
    'option','gridcell','combobox','textbox','searchbox','spinbutton'];
  const selector='a[href],button,input,textarea,select,summary,[contenteditable="true"],'+
    roles.map(role=>'[role="'+role+'"]').join(',');
  const role = e => {
    const explicit=e.getAttribute('role');
    if (roles.includes(explicit)) return explicit;
    if (e.tagName==='BUTTON' || e.tagName==='SUMMARY') return 'button';
    if (e.tagName==='A') return 'link';
    if (e.tagName==='SELECT') return 'combobox';
    if (e.tagName==='TEXTAREA' || e.isContentEditable) return 'textbox';
    if (e.tagName==='INPUT') {
      if (['checkbox','radio'].includes(e.type)) return e.type;
      if (['button','submit','reset','image'].includes(e.type)) return 'button';
      if (e.type==='search') return 'searchbox';
      if (e.type==='number') return 'spinbutton';
      if (['text','email','url','tel','password','date','datetime-local','month','week','time'].includes(e.type)) return 'textbox';
    }
    return null;
  };
  cache.pageKey=()=>[performance.timeOrigin,location.href,scrollX,scrollY,innerWidth,innerHeight,
    [...document.querySelectorAll('input,textarea,select')].filter(e=>!hidden(e))
      .map(e=>[identity(e),valueOf(e),e.checked,e.selectedIndex,e.disabled,e.readOnly])];
  cache.guard=e=>{
    if (!e?.isConnected || !visible(e)) return null;
    const scope=e.closest('form,dialog,[role="dialog"],article,li,tr,[role="row"]') || e.parentElement;
    // A board's state lives in its pieces and square marks, not in text: guard on them too.
    // Animation classes are transient (a moved piece is 'anim' for a moment): leave them out, or a decision taken
    // during the animation would look stale a second later.
    const layout=e.tagName==='CG-BOARD' ? [...e.querySelectorAll('piece,square')]
      .filter(p=>!p.classList.contains('ghost') && !p.classList.contains('fading'))
      .map(p=>(p.cgKey||'')+':'+[...p.classList].filter(c=>!['anim','dragging'].includes(c)).join(' ')).join('|') : '';
    return [identity(e),role(e),name(e),e.value===undefined ? null : valueOf(e),e.checked??null,e.selectedIndex??null,
      e.readOnly??null,e.matches(':disabled'),e.getAttribute('aria-disabled'),
      e.getAttribute('aria-expanded'),e.getAttribute('aria-checked'),e.getAttribute('aria-selected'),
      e.getAttribute('href'),scope?.innerText?.slice(0,6000)||'',layout];
  };
  const MAX_OPTIONS=cfg.maxOptions||60;
  const actions=[];
  // A form without a <form> element (fields and a button in a <div>, common in single-page apps): the nearest
  // ancestor, a few levels up, that holds at least two text-like fields. Real forms come first.
  const FIELDS=['text','email','password','tel','number','search','url','date','datetime-local','month','week','time']
    .map(t=>'input[type='+t+']').concat(['input:not([type])','textarea','select']).join(',');
  const groupCount=new Map();
  const formOf = e => {
    const real=e.form || e.closest('form,[role="form"],fieldset');
    if (real) return real;
    for (let a=e.parentElement, depth=0; a && a!==document.body && depth<5; a=a.parentElement, depth++) {
      if (!groupCount.has(a)) groupCount.set(a,[...a.querySelectorAll(FIELDS)].filter(x=>visible(x)).length);
      const n=groupCount.get(a);
      if (n>=2) return n<=30 ? a : null;
    }
    return null;
  };
  // A search box: Enter runs it, and running it commits nothing.
  const searchLike = (e,form) => e.type==='search' || role(e)==='searchbox' ||
    ['q','query','search','s'].includes((e.getAttribute('name')||'').toLowerCase()) ||
    /\bsearch|\bquery\b|\bfind\b/i.test([e.id,e.getAttribute('placeholder'),e.getAttribute('aria-label'),
      [...(e.labels||[])].map(l=>l.innerText).join(' ')].filter(Boolean).join(' ')) ||
    !!(form && (form.getAttribute('role')==='search' || /search/i.test(form.getAttribute('action')||'')));
  // Styled checkboxes and radios: the native input is transparent over its own drawing (opacity 0, still on top)
  // or hidden with its <label> drawn instead. The control is still what the user clicks; target that.
  const toggleTarget = e => {
    if (!(e instanceof HTMLInputElement) || !['checkbox','radio'].includes(e.type) || e.closest('[inert]')) return null;
    const r=e.getBoundingClientRect();
    if (r.width>=8 && r.height>=8 && e.checkVisibility({checkVisibilityCSS:true}) &&
        document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)===e) return e;
    return [...(e.labels||[])].find(l=>visible(l) && l.getBoundingClientRect().width>0) || null;
  };
  // Text of the row/list item a control sits in: tells look-alike controls apart ("Delete" in each row).
  const rowText = e => {
    const row=e.closest('li,tr,[role="row"],[role="listitem"],article');
    if (!row || row===e) return '';
    const t=clip(row.innerText,100);
    return t && t!==clip(name(e),100) ? t : '';
  };
  // A short label for a non-semantic element: its accessible name, else attributes that name it.
  const hintLabel = e => {
    const own=clip(name(e),80);
    if (own) return own;
    const keyish=e.cgKey || e.getAttribute('data-key') || e.getAttribute('data-square') ||
      e.getAttribute('data-testid') || e.getAttribute('data-id') || '';
    if (e instanceof SVGElement) {
      const b=e.getBoundingClientRect(), st=getComputedStyle(e);
      const fill=e.getAttribute('fill') || (st.fill && st.fill!=='none' ? st.fill : '');
      const words=[e.tagName.toLowerCase(), fill && 'fill '+fill, e.getAttribute('stroke') && 'stroke '+e.getAttribute('stroke'),
        e.tagName.toLowerCase()==='text' ? '"'+clip(e.textContent,20)+'"' : '', Math.round(b.width)+'x'+Math.round(b.height)+'px'];
      return clip(words.filter(Boolean).join(' '),80);
    }
    const cls=typeof e.className==='string' ? e.className.split(/\s+/).filter(c=>c && c.length<20).slice(0,3).join(' ') : '';
    return clip([cls||e.tagName.toLowerCase(), keyish].filter(Boolean).join(' '),80);
  };
  for (const e of document.querySelectorAll(selector)) {
    if (hidden(e) || e.matches(':disabled') || e.closest('[aria-disabled="true"]')) continue;
    const at=visible(e) ? e : toggleTarget(e);  // the element that receives the click
    if (!at) continue;
    const r=at.getBoundingClientRect(), x=r.x+r.width/2, y=r.y+r.height/2, rname=role(e);
    if (!rname || r.width<=0 || r.height<=0 || x<0 || y<0 || x>=innerWidth || y>=innerHeight) continue;
    if (rname==='gridcell' && e.querySelector('button,[role="button"]')) continue;
    const form=formOf(e);
    const base={node:identity(at),role:rname,label:clip(name(e),160)||rname,
      rect:{x:r.x,y:r.y,w:r.width,h:r.height}};
    const ctx=heading(e); if (ctx) base.heading=ctx;
    const row=rowText(e); if (row) base.row=row;
    if (form) base.form=identity(form);
    const kind=sensitive(e); if (kind) base.sensitive=kind;
    if (['INPUT','TEXTAREA','SELECT'].includes(e.tagName)) {
      base.field={type:e.type||e.tagName.toLowerCase(),name:e.getAttribute('name')||'',
        autocomplete:e.getAttribute('autocomplete')||'',required:!!e.required,
        maxlength:e.maxLength>0?e.maxLength:null,pattern:e.getAttribute('pattern')||'',
        inputmode:e.getAttribute('inputmode')||'',placeholder:clip(e.getAttribute('placeholder')||'',60),
        label_text:clip([...(e.labels||[])].map(l=>l.innerText).join(' '),80)};
      if (e.tagName==='INPUT' && searchLike(e,form)) base.field.search=true;
    }
    for (const key of ['checked','selected','expanded']) {
      const value=e.getAttribute('aria-'+key);
      if (value!==null) base[key]=value;
    }
    if (['checkbox','radio'].includes(e.type)) base.checked=String(e.checked);
    if (e.tagName==='SELECT') {
      const current=[...e.selectedOptions].map(o=>o.label).join(', ');
      const multi=e.multiple;
      // A multi-select toggles each option, so every option stays a target and carries its state.
      const options=[...e.options].filter(o=>(multi || !o.selected) && !o.disabled && !o.closest('optgroup[disabled]'));
      base.option_count=e.options.length; base.selected_value=e.value;
      if (multi) base.multiple=true;
      for (const o of options.slice(0,MAX_OPTIONS))
        actions.push({...base,kind:'select',value:o.value,current_value:current,
          label:base.label+' → '+o.label+(multi ? (o.selected ? ' (selected; choose again to unselect)' : ' (not selected)') : '')});
      if (!options.length || options.length>MAX_OPTIONS)
        actions.push({...base,kind:'click',value:current,current_value:current,label:'Open '+base.label});
    } else {
      const editable=!e.readOnly && e.getAttribute('aria-readonly')!=='true' &&
        (['textbox','searchbox','spinbutton'].includes(rname) ||
          (rname==='combobox' && ['INPUT','TEXTAREA'].includes(e.tagName)));
      // Inputs report their value; a custom combobox (often a <button>) reports its visible text.
      const value=['INPUT','TEXTAREA'].includes(e.tagName) ? masked(e) :
        e.isContentEditable || rname==='combobox' ? clip(e.innerText,200) : '';
      actions.push({...base,kind:editable?'fill':'click',value});
      if (editable) actions.push({...base,kind:'click',value,label:'Open '+base.label});
      // Enter submits a filled field that has no submit control (to-do inputs, chat boxes), and runs a search
      // box even when it has a button (the button may be covered by the box's own suggestions).
      if (editable && e.value && e.tagName!=='TEXTAREA' && !kind) {
        const submit=form && [...form.querySelectorAll('button,input[type=submit],input[type=image],[role=button]')]
          .some(b=>visible(b) && (b.tagName!=='BUTTON' || (b.type||'submit')==='submit'));
        if (!submit || base.field?.search) actions.push({...base,kind:'enter',value,label:'Press Enter in '+base.label});
      }
    }
  }
  // Board widgets (chessground, used by Lichess and others): pieces ignore the pointer and the board maps a
  // click position to a square. Code computes each square's point from the board's own geometry and exposes
  // it as one indexed target; the model only ever picks an index.
  const boards=new Set();
  for (const board of document.querySelectorAll('cg-board')) {
    const r=board.getBoundingClientRect();
    if (r.width<80 || r.height<80 || !visible(board)) continue;
    boards.add(board);
    const wrap=board.closest('.cg-wrap'), black=!!wrap && wrap.classList.contains('orientation-black');
    const pieces={}, marks={};
    for (const p of board.querySelectorAll('piece')) if (p.cgKey && !p.classList.contains('ghost'))
      pieces[p.cgKey]=[...p.classList].filter(c=>!['fading','anim','dragging'].includes(c)).join(' ');
    for (const s of board.querySelectorAll('square')) if (s.cgKey)
      marks[s.cgKey]=(marks[s.cgKey]||[]).concat([...s.classList]);
    const node=identity(board), files='abcdefgh';
    const selected=Object.entries(marks).find(([k,v])=>v.includes('selected'));
    // The page's own FEN (many chess sites show it in a field) gives the side to move.
    const fen=[...document.querySelectorAll('input,textarea')].map(i=>i.value||'')
      .find(v=>/^([pnbrqkPNBRQK1-8]+\/){7}[pnbrqkPNBRQK1-8]+ [wb] /.test(v));
    const turn=fen ? (fen.split(' ')[1]==='w' ? 'White' : 'Black') : '';
    const boardHint='Chess board. A move takes two clicks: first the square holding the piece to move'+
      (turn ? ' (it is '+turn+' to move, so a '+turn.toLowerCase()+' piece)' : '')+', then its destination, which is '+
      'shown as a legal move destination once the piece is selected. Clicking an empty square with no piece selected '+
      'does nothing.';
    const dests=Object.entries(marks).filter(([k,v])=>v.includes('move-dest')).map(([k])=>k).sort();
    const selNote=selected ? ' Selected now: '+selected[0]+' ('+(pieces[selected[0]]||'')+'), legal destinations: '+
      (dests.length ? dests.join(', ') : 'none, so select a different piece') + '.' : ' No piece is selected now.';
    const fullHint=boardHint+selNote;
    for (let f=0; f<8; f++) for (let rank=1; rank<=8; rank++) {
      const key=files[f]+rank, col=black ? 7-f : f, row=black ? rank-1 : 8-rank;
      const notes=(marks[key]||[]).map(m=>m==='move-dest'?'legal move destination':m==='oc'?'capture':
        m==='selected'?'selected':m==='last-move'?'last move':m==='check'?'in check':'').filter(Boolean);
      actions.push({node, vkey:node+':'+key, role:'square', kind:'click', value:'', heading:fullHint,
        point:{fx:(col+0.5)/8, fy:(row+0.5)/8},
        label:'square '+key+' ('+(pieces[key]||'empty')+(notes.length?'; '+notes.join(', '):'')+')',
        rect:{x:r.x+col*r.width/8, y:r.y+row*r.height/8, w:r.width/8, h:r.height/8}});
    }
  }
  // Clickable elements that are not semantic controls: the outermost element showing a pointer cursor (or
  // with an onclick attribute) such as card divs, SVG shapes and board pieces. Still code-owned indices.
  const semantic=new Set(actions.map(a=>a.node));
  const area=innerWidth*innerHeight;
  let extra=0;
  for (const e of document.body.querySelectorAll('*')) {
    if (extra>=80) break;
    if (e.matches(selector) || e.closest(selector) || ['HTML','BODY','LABEL','OPTION'].includes(e.tagName)) continue;
    if (boards.has(e) || [...boards].some(b=>b.contains(e) || e.contains(b))) continue;
    const r=e.getBoundingClientRect();
    if (r.width<4 || r.height<4 || r.width*r.height>area*0.5 || r.bottom<=0 || r.right<=0 ||
        r.top>=innerHeight || r.left>=innerWidth) continue;
    const pointer=getComputedStyle(e).cursor==='pointer';
    // SVG shapes and text inside a visible drawing are targets too: charts, diagrams and games attach click
    // handlers to them with no cursor hint.
    const shape=e instanceof SVGGraphicsElement && !!e.ownerSVGElement &&
      ['circle','ellipse','rect','polygon','path','text','polyline','line'].includes(e.tagName.toLowerCase());
    const handler=!pointer && !shape && hasHandler(e);
    if (!pointer && !shape && !handler) continue;
    // A handler on a container of controls is event delegation (the page listens there for its controls'
    // clicks): the controls are the targets, not the container.
    if (handler && e.querySelectorAll(selector).length>=2) continue;
    const parent=e.parentElement;
    if (pointer && !shape && parent && parent!==document.body && getComputedStyle(parent).cursor==='pointer') continue;
    if (!visible(e) || e.closest('[aria-disabled="true"]')) continue;
    // A pointer container (toolbar, menu) whose own children carry the click handlers: target the children,
    // since clicking the container's centre may hit nothing useful.
    const parts=[...e.querySelectorAll('*')].filter(c=>hasHandler(c) && !c.matches(selector) && visible(c))
      .filter((c,i,all)=>!all.some(o=>o!==c && o.contains(c))).slice(0,24);
    const targets=parts.length>=2 ? parts : [e];
    for (const t of targets) {
      const tr=t===e ? r : t.getBoundingClientRect();
      if (tr.width<4 || tr.height<4) continue;
      const x=tr.x+tr.width/2, y=tr.y+tr.height/2;
      if (x<0 || y<0 || x>=innerWidth || y>=innerHeight) continue;
      const hit=document.elementFromPoint(x,y);
      if (!hit || !(t===hit || t.contains(hit))) continue;
      const node=identity(t);
      if (semantic.has(node)) continue;
      semantic.add(node);
      const base={node,role:'clickable',label:hintLabel(t),rect:{x:tr.x,y:tr.y,w:tr.width,h:tr.height}};
      const ctx=heading(t); if (ctx) base.heading=ctx;
      const row=rowText(t); if (row) base.row=row;
      actions.push({...base,kind:'click',value:''});
      extra++;
    }
  }
  // Disabled selects are not actions, but the form filler needs them: dependent dropdowns (district after
  // state) are disabled until their parent changes.
  const disabled_fields=[];
  for (const e of document.querySelectorAll('select:disabled')) {
    if (!visible(e)) continue;
    const form=formOf(e);
    disabled_fields.push({node:identity(e),label:clip(name(e),160)||e.getAttribute('name')||'select',
      form:form?identity(form):null,heading:heading(e)||'',
      field:{type:e.type,name:e.getAttribute('name')||'',autocomplete:e.getAttribute('autocomplete')||'',
        required:!!e.required,label_text:clip([...(e.labels||[])].map(l=>l.innerText).join(' '),80)}});
  }
  const words=[], walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  const range=document.createRange(); let node,length=0;
  while ((node=walker.nextNode()) && length<6000) {
    const value=node.textContent.trim(), parent=node.parentElement;
    if (!value || !parent || parent.closest('script,style,noscript,template') || !visible(parent)) continue;
    range.selectNodeContents(node); const r=range.getBoundingClientRect();
    if (r.width>0 && r.height>0 && r.bottom>0 && r.top<innerHeight && r.right>0 && r.left<innerWidth) {
      words.push(value); length+=value.length;
    }
  }
  const text=words.join('\n').slice(0,6000), height=document.documentElement.scrollHeight;
  const page_key=cache.pageKey(), guards={};
  for (const a of actions) if (!(a.node in guards)) guards[a.node]=cache.guard(cache.nodes.get(a.node));
  const semantics=actions.map(({rect,...action})=>action);
  const marker=[performance.timeOrigin,location.href,scrollX,scrollY,innerWidth,innerHeight,
    document.title,text,semantics,page_key[6]];
  const omitted_actions=Math.max(0,actions.length-250);
  actions.splice(250);
  actions.forEach((a,i)=>a.id='e'+(i+1));
  if (scrollY+innerHeight<height-2) actions.push({id:'scroll_down',kind:'scroll',label:'Scroll down',delta:560});
  if (scrollY>0) actions.push({id:'scroll_up',kind:'scroll',label:'Scroll up',delta:-560});
  const width=document.documentElement.scrollWidth;
  if (scrollX+innerWidth<width-2) actions.push({id:'scroll_right',kind:'scroll',label:'Scroll right',delta_x:800});
  if (scrollX>0) actions.push({id:'scroll_left',kind:'scroll',label:'Scroll left',delta_x:-800});
  actions.push({id:'wait',kind:'wait',label:'Wait for the page to update'});
  return {url:location.href,title:document.title,w:innerWidth,h:innerHeight,text,ready:document.readyState,
    scroll:{y:scrollY,height,x:scrollX,width},actions,marker,page_key,guards,omitted_actions,disabled_fields};
})()
