"""Identity store, validators, domain binding, field detection and redaction (offline)."""

import json
import os
import stat

import pytest

from swift import identity, redact
from swift.identity import IdentityError, IdentityStore, aadhaar_valid, detect_kind, host_allowed, pan_valid, pin_valid

VALID_AADHAAR = "999941057058"  # UIDAI's published sandbox test number (passes Verhoeff)


def test_verhoeff_and_formats():
    assert aadhaar_valid(VALID_AADHAAR) and aadhaar_valid("9999 4105 7058")
    assert not aadhaar_valid("234123412345")  # wrong check digit
    assert not aadhaar_valid("123412341234")  # cannot start with 0/1
    assert pan_valid("ABCPE1234F") and not pan_valid("ABCDE1234F")  # 4th letter is the holder type
    assert pin_valid("560001") and not pin_valid("060001") and not pin_valid("56001")


@pytest.mark.parametrize("url,ok", [
    ("https://uidai.gov.in/kyc", True), ("https://myaadhaar.uidai.gov.in/x", True),
    ("http://uidai.gov.in/kyc", False), ("https://uidai.gov.in.evil.com/", False),
    ("https://evil.com/?q=uidai.gov.in", False), ("http://127.0.0.1:8080/kyc", True),
])
def test_domain_binding(url, ok):
    assert host_allowed(url, ["uidai.gov.in", "127.0.0.1"]) is ok


def test_store_encrypts_and_never_lists_values(tmp_path):
    store = IdentityStore(tmp_path / "id.enc")
    item = store.add("aadhaar", "9999 4105 7058", ["uidai.gov.in"], label="Mine")
    raw = (tmp_path / "id.enc").read_bytes()
    assert VALID_AADHAAR.encode() not in raw
    assert stat.S_IMODE(os.stat(tmp_path / "id.enc").st_mode) == 0o600
    assert stat.S_IMODE(os.stat(tmp_path / "id.key").st_mode) == 0o600
    listed = json.dumps(store.list())
    assert VALID_AADHAAR not in listed and item["masked"].endswith("7058")
    assert store.find("aadhaar", "https://uidai.gov.in/") and store.find("aadhaar", "https://other.in/") is None


def test_invalid_values_and_missing_domains_are_refused(tmp_path):
    store = IdentityStore(tmp_path / "id.enc")
    with pytest.raises(IdentityError):
        store.add("aadhaar", "234123412345", ["uidai.gov.in"])
    with pytest.raises(IdentityError):
        store.add("pan", "ABCPE1234F", [])


class FakePage:
    def __init__(self, url):
        self.url, self.typed = url, []

    def evaluate(self, expr):
        return self.url

    def fill_node(self, node, text, *, per_key=False, secret=False):
        assert secret, "identity values are only typed through the secret path"
        self.typed.append((node, text))
        return True

    def has_value(self, node):
        return True


def test_fill_rechecks_the_domain_at_the_moment_of_typing(tmp_path):
    store = IdentityStore(tmp_path / "id.enc")
    item = store.add("aadhaar", VALID_AADHAAR, ["uidai.gov.in"])
    good = FakePage("https://uidai.gov.in/kyc")
    out = store.fill(good, "https://uidai.gov.in/kyc", 7, item["id"])
    assert out["ok"] and good.typed == [(7, VALID_AADHAAR)] and VALID_AADHAAR not in json.dumps(out)
    moved = FakePage("https://evil.example/kyc")  # navigated away after the decision
    with pytest.raises(IdentityError):
        store.fill(moved, "https://uidai.gov.in/kyc", 7, item["id"])
    assert moved.typed == []


@pytest.mark.parametrize("label,kind", [
    ("Aadhaar number", "aadhaar"), ("Aadhaar No.", "aadhaar"), ("UID", "aadhaar"), ("PAN", "pan"),
    ("PAN number", "pan"), ("Passport number", "passport"),
    ("Name as on Aadhaar", None), ("Address as per passport", None), ("Father's name (as on PAN)", None),
])
def test_detect_kind_only_for_fields_that_ask_for_the_number(label, kind):
    assert detect_kind({"label": label}) == kind


def test_redaction_scrubs_registered_values_and_patterns():
    redact.register(VALID_AADHAAR)
    text = "id 9999 4105 7058, raw 999941057058, card 4111 1111 1111 1111, pan ABCPE1234F"
    out = redact.scrub_text(text)
    assert "7058" not in out.replace("[redacted]", "") or "9999" not in out
    assert "999941057058" not in out and "4111" not in out and "ABCPE1234F" not in out


def test_scrub_masks_sensitive_actions_and_screenshots():
    obj = {"actions": [{"label": "Password", "sensitive": "password", "value": "hunter22"},
                       {"label": "City", "value": "Pune"}], "screenshot": "AAAA", "password": "x1"}
    out = redact.scrub(obj)
    assert out["actions"][0]["value"] == "[masked]" and out["actions"][1]["value"] == "Pune"
    assert out["screenshot"] == "[screenshot omitted]" and out["password"] == "[redacted]"


def test_host_redaction_registrar_gets_exact_value_patterns():
    seen = []
    redact.set_host_registrar(lambda pats: seen.extend(pats))
    try:
        redact.register(VALID_AADHAAR)
        redact.register(VALID_AADHAAR)  # sent once
    finally:
        redact.set_host_registrar(None)
    import re

    assert seen and all(len(p) >= 2 for p in seen)
    assert any(re.fullmatch(p, VALID_AADHAAR) for p in seen)
    assert any(re.fullmatch(p, "9999 4105 7058") for p in seen)
    assert len(seen) == len(set(seen))


def test_identity_module_has_no_value_returning_api():
    public = [n for n in dir(IdentityStore) if not n.startswith("_")]
    assert "get_value" not in public and "reveal" not in public
    assert identity.mask(VALID_AADHAAR) == "••••••••7058"
