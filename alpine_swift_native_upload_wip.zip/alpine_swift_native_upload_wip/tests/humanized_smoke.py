"""Optional live check against the already-running shared Cloak service.

Creates and closes only two temporary tabs in the existing profile. Never launches
another browser or accesses remote websites. Run on a machine with a display.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from swift.chrome import _load_settings_file
from swift.cloak import require_session, task_lock
from swift.human_input import patched_page
from swift.transport import DirectCDP


def main():
    _load_settings_file()
    endpoint = require_session()
    with task_lock():
        cdp = DirectCDP(endpoint)
        tabs = []
        try:
            for _ in range(2):
                tab = cdp.new_tab('about:blank'); tabs.append(tab)
                with patched_page(tab.target_id) as page:
                    assert hasattr(page, '_original'), 'Cloak patch marker missing'
                    page.set_content('''<input id="name"><button id="b">Go</button>
                      <iframe id="f" srcdoc="<button id='inner'>Frame</button>"></iframe>
                      <script>window.events=[]; for (const e of ['click','input'])
                      document.addEventListener(e, x => window.events.push([e,x.isTrusted]));</script>''')
                    page.locator('#name').fill('test')
                    page.locator('#b').click()
                    page.frame_locator('#f').locator('#inner').click()
                    page.mouse.wheel(0, 100)
                    events = page.evaluate('window.events')
                    assert ['click', True] in events and ['input', True] in events, events
                    assert page.locator('#name').input_value() == 'test'
            print('Passed: patched page marker, typed value, trusted events, frame click, and two tabs.')
            print('This is a functional smoke test; it does not prove human-like timing or stealth.')
        finally:
            for tab in tabs: cdp.close_tab(tab)
            cdp.close()


if __name__ == '__main__': main()
