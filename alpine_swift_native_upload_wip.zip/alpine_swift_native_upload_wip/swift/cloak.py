"""One externally owned Cloak session. Clients only attach; they never launch a fallback.

Run ``python -m swift.cloak serve`` under Xvfb on a Linux server. The service
holds a process lock for its lifetime and records the exact browser WebSocket ID.
A Chrome-looking user agent is not used as proof of the browser's identity.
"""
from __future__ import annotations

import json
import os
import secrets
import signal
import sys
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

from .config import settings, secret


def profile_dir() -> Path:
    return Path(settings().get('chrome.profile_dir')).expanduser().resolve()


def endpoint() -> str:
    return f"http://127.0.0.1:{int(settings().get('chrome.port', 9242))}"


@contextmanager
def file_lock(name: str, *, blocking: bool = True):
    import fcntl  # Deployment target is Linux (including Alpine).

    directory = profile_dir()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (directory / name).open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError:
            raise RuntimeError('The single Cloak service is already running') from None
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def task_lock():
    return file_lock('swift-input.lock')


def require_session(url: str | None = None) -> str:
    from .chrome import version_info, pid_alive

    wanted = endpoint()
    if url and url.rstrip('/') != wanted:
        raise RuntimeError(f'Only the shared Cloak endpoint {wanted} is permitted')
    try:
        record = json.loads((profile_dir() / 'swift-cloak.json').read_text())
    except (OSError, ValueError):
        raise RuntimeError('Start python -m swift.cloak serve first; no Chrome fallback is allowed') from None
    info = version_info(int(settings().get('chrome.port', 9242)))
    if (not info or record.get('backend') != 'cloakbrowser' or
            not pid_alive(int(record.get('service_pid', 0))) or
            record.get('ws') != info.get('webSocketDebuggerUrl') or
            record.get('profile') != str(profile_dir())):
        raise RuntimeError('Shared Cloak session is unavailable or its identity changed; refusing attachment')
    return wanted


def launch_options() -> dict:
    """Only one fixed residential proxy; credentials are never printed or written to the profile."""
    from .platform import is_root, desktop_session

    if is_root():
        raise RuntimeError('Run Cloak as a non-root user; its sandbox must remain enabled')
    if not desktop_session():
        raise RuntimeError('Headed Cloak needs DISPLAY; start it with xvfb-run -a on a server')
    proxy = secret('CLOAK_PROXY_URL').strip()
    options = {'headless': False, 'humanize': True,
               'license_key': secret('CLOAKBROWSER_LICENSE_KEY') or None}
    if proxy:
        try:
            parsed = urlsplit(proxy)
            valid = parsed.scheme in ('http', 'https', 'socks5') and parsed.hostname and parsed.port
        except ValueError:
            valid = False
        if not valid:
            raise RuntimeError('CLOAK_PROXY_URL must be an http, https or socks5 URL with a host and port')
        # One configured proxy is used at launch; never retry without it.
        options.update(proxy=proxy, geoip=True)
    return options


def serve() -> None:
    from .chrome import version_info
    from cloakbrowser import launch_persistent_context

    if settings().get('task_contexts') == 'context' or settings().get('proxy.enabled', False):
        raise RuntimeError('Use the default context and one launcher-level proxy only')
    port = int(settings().get('chrome.port', 9242))
    if not 1024 <= port <= 65535:
        raise ValueError('Cloak port must be between 1024 and 65535')
    with file_lock('swift-service.lock', blocking=False):
        if version_info(port):
            raise RuntimeError(f'Port {port} is occupied; refusing to launch a second browser')
        seed_file = profile_dir() / 'swift-fingerprint'
        if not seed_file.exists():
            seed_file.write_text(str(secrets.randbelow(2**31 - 1) + 1))
        seed = str(int(seed_file.read_text().strip()))
        args = [f'--remote-debugging-port={port}', '--remote-debugging-address=127.0.0.1',
                f'--fingerprint={seed}', '--disable-background-timer-throttling',
                '--disable-renderer-backgrounding', '--disable-backgrounding-occluded-windows']
        # Arbitrary executable/argument overrides are deliberately not passed to Cloak.
        from playwright.sync_api import Error as PlaywrightError

        options = launch_options()
        from .chrome import agent_preferences
        agent_preferences(profile_dir())
        context = launch_persistent_context(str(profile_dir()), args=args, **options)
        # Run on new documents and frames; existing documents get an immediate copy.
        cursor = Path(__file__).with_name('cursor.js').read_text()
        context.add_init_script(cursor)
        for page in context.pages:
            try:
                page.evaluate(cursor)
            except Exception:
                pass
        record_file = profile_dir() / 'swift-cloak.json'
        previous = {}
        stopping = False

        def stop(*_):
            nonlocal stopping
            stopping = True

        try:
            info = version_info(port)
            if not info or not info.get('webSocketDebuggerUrl'):
                raise RuntimeError('Cloak did not expose its CDP endpoint')
            product = info.get('Browser', '')
            import re
            match = re.search(r'(?:Chrome|Chromium)/(\d+)', product)
            if not match or int(match.group(1)) < 155:
                raise RuntimeError(f'Cloak Chromium 155+ required; got {product!r}. Check the Pro license and binary.')
            tmp = record_file.with_suffix('.tmp')
            tmp.write_text(json.dumps({'backend': 'cloakbrowser', 'profile': str(profile_dir()),
                                       'service_pid': os.getpid(), 'ws': info['webSocketDebuggerUrl']}))
            tmp.chmod(0o600)
            tmp.replace(record_file)
            for sig in (signal.SIGINT, signal.SIGTERM):
                previous[sig] = signal.signal(sig, stop)
            print(f'Cloak ready: {endpoint()} (one persistent profile)', flush=True)
            # Pump Playwright's event loop so disconnects and wrapper callbacks are serviced.
            while not stopping:
                if not context.pages:
                    context.new_page()
                page = context.pages[0]
                try:
                    page.wait_for_timeout(250)
                except PlaywrightError:
                    if not page.is_closed():
                        raise
                    # A task may close this tab during the wait. Continue on another tab;
                    # a real browser disconnect still fails when trying to create a page.
                    if not context.pages:
                        context.new_page()
        finally:
            record_file.unlink(missing_ok=True)
            for sig, handler in previous.items():
                signal.signal(sig, handler)
            context.close()


def _load_launcher_env() -> None:
    """Read launcher-only values from the same Hermes .env used by the service.

    shlex parses quoting without executing shell substitutions. Explicit process
    environment always wins. API keys remain with Hermes, not the browser launcher.
    """
    import shlex
    path = Path(os.environ.get('HERMES_HOME', '~/.hermes')).expanduser() / '.env'
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        entry = line.strip()
        if entry.startswith('export '):
            entry = entry[7:].lstrip()
        name, separator, raw = entry.partition('=')
        if not separator or name.strip() not in ('CLOAK_PROXY_URL', 'CLOAKBROWSER_LICENSE_KEY'):
            continue
        name = name.strip()
        try:
            parsed = shlex.split(raw, comments=True)
        except ValueError:
            raise RuntimeError(f'Invalid quoting for {name} in launcher environment file') from None
        if len(parsed) > 1:
            raise RuntimeError(f'Invalid value for {name} in launcher environment file')
        os.environ.setdefault(name, parsed[0] if parsed else '')


def main(argv=None) -> int:
    from .chrome import _load_settings_file

    _load_settings_file()
    _load_launcher_env()
    argv = sys.argv[1:] if argv is None else argv
    command = argv[0] if argv else 'serve'
    if command == 'serve':
        serve()
    elif command in ('status', 'detect'):
        print(require_session())
    elif command == 'stop':
        require_session()
        record = json.loads((profile_dir() / 'swift-cloak.json').read_text())
        os.kill(record['service_pid'], signal.SIGTERM)
    else:
        raise ValueError('Use serve, status, or stop')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
