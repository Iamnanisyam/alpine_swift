"""Behavior and call-count regressions for the streamlined browser and forms."""
import json
from types import SimpleNamespace

import pytest

from swift import cloak, config, dropdowns, forms, platform
from swift.page import ActionRefused, Page


@pytest.fixture
def launch_env(monkeypatch):
    monkeypatch.setattr(platform, 'is_root', lambda: False)
    monkeypatch.setattr(platform, 'desktop_session', lambda: 'x11')
    monkeypatch.delenv('CLOAK_PROXY_URL', raising=False)


def test_proxy_optional(launch_env):
    opts = cloak.launch_options()
    assert 'proxy' not in opts and opts['headless'] is False


@pytest.mark.parametrize('proxy', ['direct://host:80', 'http://host', 'http://host:wrong'])
def test_invalid_proxy_rejected_without_printing_credentials(launch_env, monkeypatch, proxy):
    monkeypatch.setenv('CLOAK_PROXY_URL', proxy)
    with pytest.raises(RuntimeError):
        cloak.launch_options()


def test_single_proxy_passed_unchanged(launch_env, monkeypatch):
    proxy = 'http://user:password@static.example:8000'
    monkeypatch.setenv('CLOAK_PROXY_URL', proxy)
    opts = cloak.launch_options()
    assert opts['proxy'] == proxy and opts['geoip'] is True
    assert 'bypass' not in opts and 'executable_path' not in opts


def test_string_false_is_headed(launch_env, monkeypatch):
    config.configure({'chrome': {'headless': 'false'}})
    monkeypatch.setenv('CLOAK_PROXY_URL', 'http://static.example:8000')
    assert cloak.launch_options()['headless'] is False


def test_cloak_rejects_root(monkeypatch):
    monkeypatch.setattr(platform, 'is_root', lambda: True)
    with pytest.raises(RuntimeError, match='non-root'):
        cloak.launch_options()


def test_ready_select_has_no_wait_or_second_options_fetch(monkeypatch):
    field = forms.Field(index='1', node=1, kind='native_select', desc={'label': 'State'})
    field.value = 'Andhra Pradesh'
    monkeypatch.setattr(dropdowns, 'wait_options', lambda *a, **k: pytest.fail('unnecessary stability wait'))
    calls = []
    monkeypatch.setattr(dropdowns, 'choose_native', lambda *a, **k: calls.append(k) or {'ok': True})
    assert forms.FormFiller()._apply(object(), field)
    assert calls[0]['options'] is None


def test_dependent_options_reused(monkeypatch):
    field = forms.Field(index='1', node=1, kind='native_select', desc={'label': 'District'}, dependent=True)
    field.value = 'Nellore'
    options = [{'label': 'Nellore', 'value': 'nl'}]
    monkeypatch.setattr(dropdowns, 'wait_options', lambda *a, **k: options)
    seen = []
    monkeypatch.setattr(dropdowns, 'choose_native', lambda *a, **k: seen.append(k['options']) or {'ok': True})
    assert forms.FormFiller()._apply(object(), field)
    assert seen == [options]


def test_duplicate_exact_select_is_not_silently_first(monkeypatch):
    options = [{'label': 'Central', 'value': 'a'}, {'label': 'Central', 'value': 'b'}]
    monkeypatch.setattr(dropdowns, '_ask_jev', lambda *a: None)
    page = SimpleNamespace(evaluate=lambda expr: pytest.fail('ambiguous selection committed'))
    assert not dropdowns.choose_native(page, 1, 'Central', options=options)['ok']


def test_already_selected_option_requires_no_browser_write():
    page = SimpleNamespace(evaluate=lambda expr: pytest.fail('redundant browser write'))
    out = dropdowns.choose_native(page, 1, 'AP', options=[
        {'label': 'Andhra Pradesh', 'value': 'ap', 'selected': True}])
    assert out['ok'] and out['unchanged']


@pytest.mark.parametrize('got,want,kind,ok', [
    ('AP', 'Andhra Pradesh', None, False), ('abc', 'ABC', None, False),
    ('123560001', '560001', 'pincode', False), ('+91 98765 43210', '9876543210', 'phone', True),
    ('  Asha  ', 'Asha', None, True)])
def test_readback_checks_value_not_dropdown_abbreviations(got, want, kind, ok):
    f = SimpleNamespace(node=1, value=want, desc={'class': kind})
    assert forms.FormFiller()._read_back(SimpleNamespace(read_value=lambda _: got), f) is ok


def field_page(state):
    page = Page.__new__(Page)
    page.evaluate = lambda _: state
    page._resolve_in_view = lambda *a: {'x': 20, 'y': 30}
    page._click_at = lambda *a: pytest.fail('unnecessary click')
    page._select_all = lambda: None
    page.call = lambda *a, **k: None
    page._human = lambda *a: None
    return page


def test_unchanged_field_skips_input():
    page = field_page({'same': True})
    page._select_all = lambda: pytest.fail('unchanged field modified')
    assert page.fill_node(1, 'Asha')


def test_focused_field_skips_mouse():
    assert field_page({'focused': True}).fill_node(1, 'Asha')


def test_sensitive_field_never_uses_fast_path_without_secret():
    with pytest.raises(ActionRefused):
        field_page({'same': True, 'sensitive': 'password'}).fill_node(1, 'secret')


def test_model_integrity_manifest():
    import hashlib
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'MODEL_INTEGRITY.json').read_text())
    for filename, digest in manifest['files'].items():
        assert hashlib.sha256((root / filename).read_bytes()).hexdigest() == digest
    for key, value in manifest['settings'].items():
        assert config.DEFAULTS[key] == value
