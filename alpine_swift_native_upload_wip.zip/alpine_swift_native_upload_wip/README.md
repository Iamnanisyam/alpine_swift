# Alpine Swift — Cloak edition

> **Implementation WIP:** Read [IMPLEMENTATION_NOTES.md](IMPLEMENTATION_NOTES.md). Legacy statements below may describe the previous release; vault fill is disabled and live integration is unverified.

> **Not production-ready:** This partially hardened copy still has major integration gaps. Read [PRODUCTION_READINESS_REVIEW.md](PRODUCTION_READINESS_REVIEW.md) before use.

A Hermes browser agent using **TypeSafe Jev + Mercury 3**, one persistent
**CloakBrowser** profile, and **one static residential proxy for all browser tabs**.

This is the complete source repository. Install from this ZIP's extracted folder;
the installer uses these files, not an older GitHub checkout. No API keys, proxy
credentials, browser binaries, browser profiles, or dependency caches are bundled.

## Start here

1. Keep your existing GitHub repository and replace its source files with this
   release if you want to preserve history and settings. Include `.github/` and
   `.gitignore` when uploading. Do not upload your real `.env` or browser profile.
2. On Ubuntu/Debian, extract this ZIP as the non-root user who runs Hermes.
3. Run `bash deploy/install-ubuntu.sh --server` from the extracted directory.
   It asks for missing Jev/Mercury keys and `CLOAK_PROXY_URL`, with input hidden.
4. Restart Hermes after setup so its browser tools attach to Cloak's endpoint.
5. Run `python tests/cloak_smoke.py` using the service's Python environment after
   loading your Hermes config. Check the proxy exit IP in a Cloak tab before doing
   real work, and sign in once in the new persistent profile.

Use `--desktop` instead of `--server` for a desktop service. Read
[CLOAK_SETUP.md](CLOAK_SETUP.md) for manual setup, Alpine Linux compatibility,
credential format, and limitations. [config.example.yaml](config.example.yaml)
is a complete example, including unchanged model defaults. Merge it with your
Hermes configuration; do not overwrite unrelated settings or other plugins.

## What stays

- Jev 1.14 decisions and Mercury 3 value generation, planning and review settings.
- Code-first form filling with one model request for unresolved form values.
- Native selects, custom dropdowns, dependent fields, masked inputs and readback.
- Confidence gates and independent outcome checks.
- Vault integration, encrypted identity storage, redaction and task-owned tab cleanup.
- Optional live view and browser-use reasoning fallback, attached to the same browser.
- Four useful Hermes tools: `browse`, `browser_status`, `browser_close_task`,
  `identity_list`. No additional stealth browser framework is installed.

[MODEL_INTEGRITY.json](MODEL_INTEGRITY.json) records hashes of the unchanged model
adapters, questions, decision loop, rate limiting, predicates and snapshot, plus
model configuration values. Tests verify those hashes and settings.

## What was removed

Stock Chrome detection and launch paths; the unused Hermes supervisor bootstrap;
per-domain proxy switching and separate proxy cookie stores; the unused widget
registry; obsolete Chrome-only benchmark runners/results; and a CI job that
installed Google Chrome. Useful tests, local HTML fixtures and licenses remain.
Playwright remains a Cloak dependency; it is not a second browser backend.

## Execution refinements

- One shared context; task tabs open without creating a new window.
- Cloak session identity checked before attachment; no browser launch fallback.
- One static proxy at browser launch. A missing/invalid proxy prevents startup;
  proxy errors are not retried through a direct connection.
- Fast eased mouse paths with no idle wandering or intentional input errors.
- Already-correct fields skip typing; already-focused fields skip redundant clicks.
- Ready native selects skip a stability delay; dependent option lists are reused.
- Dropdown matching normalizes each option once; ambiguous duplicates are not
  silently resolved by choosing the first item.
- Custom selections poll for committed state instead of always sleeping first.
- Text readback checks the actual value, not dropdown abbreviation equivalence.
- Timed-out CDP calls release their pending entries.

These remove avoidable work. No live-site speedup or bot-detection success rate is
claimed. Swift's mouse path does not replace browser-use or Hermes-native input.

## Development and validation

```bash
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
python -m pyflakes swift tests __init__.py
node --check swift/snapshot.js
bash -n deploy/install-ubuntu.sh
```

Unit tests use no browser, proxy or model credentials. The optional live smoke test
attaches to the existing Cloak session, tests a local in-memory form, and closes
only its own tab. It does not test proxy routing, Amazon, or your live accounts.
Deployment remains unverified until tested on your actual VPS with your proxy.

## Layout

- `swift/`: browser execution, forms, models, state and verification.
- `deploy/`: installer and Cloak systemd services (historical service filenames).
- `tests/`: offline tests, live smoke script and local HTML fixtures.
- `plugin.yaml`, `__init__.py`, `skills/`: Hermes integration.

Original attribution is retained in [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md),
[LICENSE](LICENSE) and [LICENSE-jev-ultrafast](LICENSE-jev-ultrafast).
