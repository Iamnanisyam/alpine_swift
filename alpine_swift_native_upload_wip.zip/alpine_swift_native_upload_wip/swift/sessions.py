"""Login registry and task-owned tabs in one persistent Cloak context.

Popups are adopted by opener ID. Verified task tabs close immediately; failed
task tabs remain briefly for inspection. Separate browser contexts are refused.
"""

from __future__ import annotations

import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

from .config import data_dir, settings
from .transport import CDP, CDPError, TabRef

SIGNED_IN_JS = r"""(() => {
  const t=(document.body?.innerText||'').slice(0,20000);
  const links=[...document.querySelectorAll('a,button,[role=menuitem]')].map(e=>(e.innerText||e.getAttribute('aria-label')||'').trim().toLowerCase());
  const out=links.some(l=>/^(sign ?out|log ?out|logout)$/.test(l)) || /\b(sign ?out|log ?out)\b/i.test(t.slice(0,4000));
  const signIn=links.some(l=>/^(sign ?in|log ?in|login)$/.test(l));
  const pw=!!document.querySelector('input[type=password]');
  return {signed_out_markers: signIn || pw, signed_in_markers: out};
})()"""


def site_of(url: str) -> str:
    """Registrable-ish site key: the host without a leading www."""
    host = (urlsplit(url).hostname or "").lower()
    return host[4:] if host.startswith("www.") else host


def mask_account(account: str) -> str:
    if not account:
        return ""
    if "@" in account:
        user, _, dom = account.partition("@")
        return (user[:1] + "•" * max(1, len(user) - 1)) + "@" + dom
    return "•" * max(0, len(account) - 3) + account[-3:]


class LoginRegistry:
    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else data_dir() / "sessions.json"
        self._lock = threading.Lock()

    def _load(self) -> dict:
        try:
            return json.loads(self.path.read_text())
        except (OSError, ValueError):
            return {}

    def _save(self, data: dict) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=1, sort_keys=True))
        os.replace(tmp, self.path)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def record(self, url: str, signed_in: bool, account: str = "", expiry: Optional[float] = None) -> dict:
        site = site_of(url)
        with self._lock:
            data = self._load()
            entry = data.get(site, {})
            entry.update(site=site, signed_in=bool(signed_in), last_confirmed=int(time.time()))
            if account:
                entry["account"] = mask_account(account)
            if expiry:
                entry["expected_expiry"] = int(expiry)
            data[site] = entry
            self._save(data)
            return entry

    def get(self, url: str) -> Optional[dict]:
        return self._load().get(site_of(url))

    def all(self) -> list[dict]:
        return sorted(self._load().values(), key=lambda e: e.get("site", ""))


def session_cookie_expiry(cdp: CDP, url: str, session_id: Optional[str] = None) -> Optional[float]:
    """Latest expiry among likely session cookies for ``url`` (None if there are none)."""
    try:
        cookies = cdp.call("Network.getCookies", {"urls": [url]}, session_id=session_id).get("cookies", [])
    except CDPError:
        return None
    pat = re.compile(r"sess|auth|token|sid|login|jwt|remember", re.I)
    hits = [c for c in cookies if pat.search(c.get("name", ""))]
    if not hits:
        return None
    exp = [c.get("expires", -1) for c in hits]
    return max(exp) if max(exp) > 0 else float("inf")


def signed_in_state(page, jev=None) -> dict:
    """Code first (cookies and markers); a Jev noul only when the markers disagree or are absent."""
    obs_url = page.evaluate("location.href") or ""
    markers = page.evaluate(SIGNED_IN_JS) or {}
    cookie_exp = session_cookie_expiry(page.cdp, obs_url, page.tab.session_id)
    if markers.get("signed_in_markers") and not markers.get("signed_out_markers"):
        return {"signed_in": True, "method": "markers", "cookie_expiry": cookie_exp}
    if markers.get("signed_out_markers") and not markers.get("signed_in_markers"):
        return {"signed_in": False, "method": "markers", "cookie_expiry": cookie_exp}
    if jev is not None:
        from .questions import SIGNED_IN

        try:
            text = page.evaluate("document.body ? document.body.innerText.slice(0,4000) : ''")
            p = jev.noul({"page": {"url": obs_url, "text": text}}, SIGNED_IN)
            return {"signed_in": p >= 0.7, "method": "jev", "probability": p, "cookie_expiry": cookie_exp}
        except Exception:
            pass
    return {"signed_in": None, "method": "unknown", "cookie_expiry": cookie_exp}


@dataclass
class TaskTabs:
    task_id: str
    context_id: Optional[str] = None
    tabs: dict[str, TabRef] = field(default_factory=dict)
    status: str = "running"
    finished_at: Optional[float] = None
    current_step: str = ""
    goal: str = ""
    liveview: str = ""


class TabRegistry:
    """Which task owns which tab. The only place tabs are created or closed."""

    def __init__(self, cdp: CDP, mode: Optional[str] = None):
        self.cdp = cdp
        self.mode = mode or settings().get("task_contexts", "auto")
        self.tasks: dict[str, TaskTabs] = {}
        self._lock = threading.Lock()

    def start(self, task_id: str, goal: str = "", proxy: Optional[dict] = None) -> TaskTabs:
        with self._lock:
            if task_id in self.tasks:
                return self.tasks[task_id]
            t = TaskTabs(task_id, goal=goal)
            if self.mode == "context" or proxy:
                raise CDPError("Cloak-only mode forbids isolated contexts and per-task proxies")
            self.tasks[task_id] = t
            return t

    def new_tab(self, task_id: str, url: str = "about:blank") -> TabRef:
        t = self.tasks[task_id]
        tab = self.cdp.new_tab(url, context_id=t.context_id)
        with self._lock:
            t.tabs[tab.target_id] = tab
        return tab

    def owner(self, target_id: str) -> Optional[str]:
        for tid, t in self.tasks.items():
            if target_id in t.tabs:
                return tid
        return None

    def owns(self, task_id: str, target_id: str) -> bool:
        t = self.tasks.get(task_id)
        return bool(t and target_id in t.tabs)

    def adopt_popups(self, task_id: str) -> list[TabRef]:
        """Register every page target whose opener is one of this task's tabs."""
        t = self.tasks.get(task_id)
        if not t:
            return []
        try:
            infos = self.cdp.call("Target.getTargets").get("targetInfos", [])
        except CDPError:
            return []
        adopted = []
        changed = True
        while changed:
            changed = False
            for info in infos:
                tid = info.get("targetId")
                if info.get("type") != "page" or tid in t.tabs:
                    continue
                if info.get("openerId") in t.tabs and self.owner(tid) is None:
                    tab = TabRef(tid, self.cdp.attach(tid), t.context_id)
                    with self._lock:
                        t.tabs[tid] = tab
                    adopted.append(tab)
                    changed = True
        return adopted

    def close_task(self, task_id: str, confirm_s: float = 3.0) -> int:
        """Close every tab the task owns and confirm they are gone (``Target.closeTarget`` only starts the
        close: a tab can still be listed for a moment afterwards). A proxied context's cookies are saved first."""
        t = self.tasks.get(task_id)
        if not t:
            return 0
        self.adopt_popups(task_id)  # a pop-up opened by the last action belongs to the task too
        tabs = list(t.tabs.values())
        for tab in tabs:
            self.cdp.close_tab(tab)
        remaining = {tab.target_id for tab in tabs}
        deadline = time.monotonic() + confirm_s
        retried = False
        while remaining and time.monotonic() < deadline:
            try:
                live = {i.get("targetId") for i in self.cdp.call("Target.getTargets").get("targetInfos", [])}
            except CDPError:
                break
            remaining &= live
            if remaining and not retried and time.monotonic() > deadline - confirm_s / 2:
                for tid in remaining:
                    try:
                        self.cdp.call("Target.closeTarget", {"targetId": tid})
                    except CDPError:
                        pass
                retried = True
            if remaining:
                time.sleep(0.05)
        n = len(tabs) - len(remaining)
        t.tabs = {tid: tab for tid, tab in t.tabs.items() if tid in remaining}
        if remaining:
            t.status = "close_failed"
            return n
        t.status = "closed"
        return n

    def finish(self, task_id: str, verified: bool) -> None:
        t = self.tasks.get(task_id)
        if not t:
            return
        t.finished_at = time.time()
        if verified:
            self.close_task(task_id)
            if t.status != "close_failed":
                t.status = "closed"
        else:
            t.status = "failed_kept"

    def sweep(self, ttl_minutes: Optional[float] = None) -> list[str]:
        ttl = 60 * float(ttl_minutes if ttl_minutes is not None else settings().get("failed_task_tab_ttl_minutes", 30))
        closed = []
        for tid, t in list(self.tasks.items()):
            if t.status == "failed_kept" and t.finished_at and time.time() - t.finished_at >= ttl:
                self.close_task(tid)
                closed.append(tid)
        return closed

    def close_kept_on_origin(self, origin: str, exclude_task: str = "") -> list[str]:
        """Close kept tabs of failed tasks that are on ``origin``. Hermes's vault fills the first tab on an
        origin that holds the form, so a kept tab there would take a new task's fill (measured: "Hermes filled
        a different tab on this origin"). The failed task's inspection window ends early; that is recorded."""
        from .vaultfill import origin_of

        closed = []
        for tid, t in list(self.tasks.items()):
            if tid == exclude_task or t.status != "failed_kept" or not t.tabs:
                continue
            on_origin = False
            for tab in t.tabs.values():
                try:
                    info = self.cdp.call("Target.getTargetInfo", {"targetId": tab.target_id}).get("targetInfo", {})
                except CDPError:
                    continue
                if origin_of(info.get("url", "")) == origin:
                    on_origin = True
                    break
            if on_origin:
                self.close_task(tid)
                t.status = "closed_for_vault_fill"
                closed.append(tid)
        return closed

    def status(self) -> list[dict]:
        return [{"task_id": t.task_id, "status": t.status, "goal": t.goal[:200], "tabs": list(t.tabs),
                 "context": bool(t.context_id), "current_step": t.current_step, "liveview": t.liveview}
                for t in self.tasks.values()]
