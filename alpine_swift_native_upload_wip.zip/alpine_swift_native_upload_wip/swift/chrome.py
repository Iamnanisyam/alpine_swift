"""Compatibility utilities for the single Cloak service; no Chrome launcher exists."""
from __future__ import annotations
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

def version_info(port: int, timeout: float = 1.0) -> Optional[dict]:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=timeout) as r:
            return json.loads(r.read())
    except (urllib.error.URLError, OSError, ValueError):
        return None


def pid_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


PASSWORD_PREFS = {"credentials_enable_service": False,
                  "profile": {"password_manager_enabled": False, "password_manager_leak_detection": False}}


def _merged(base: dict, extra: dict) -> dict:
    out = dict(base)
    for key, value in extra.items():
        out[key] = _merged(out.get(key) if isinstance(out.get(key), dict) else {}, value) \
            if isinstance(value, dict) else value
    return out


def agent_preferences(profile_dir: Path, enabled: bool = True) -> bool:
    """Merge ``PASSWORD_PREFS`` into the profile's Preferences. Called only just before the launcher starts Chrome
    on the profile (never while a Chrome runs on it); other preferences are kept. True when the file changed."""
    if not enabled:
        return False
    prefs = profile_dir / "Default" / "Preferences"
    try:
        data = json.loads(prefs.read_text()) if prefs.exists() else {}
    except (OSError, ValueError):
        return False  # unreadable: leave the file to Chrome
    merged = _merged(data if isinstance(data, dict) else {}, PASSWORD_PREFS)
    if merged == data:
        return False
    prefs.parent.mkdir(parents=True, exist_ok=True)
    tmp = prefs.with_name("Preferences.swift-tmp")
    tmp.write_text(json.dumps(merged))
    os.replace(tmp, prefs)
    return True


def _load_settings_file() -> None:
    """For the systemd entry point: read the plugin's settings from ~/.hermes/config.yaml."""
    from .config import configure

    home = Path(os.environ.get("HERMES_HOME") or "~/.hermes").expanduser()
    path = Path(os.environ.get("HERMES_CONFIG") or home / "config.yaml").expanduser()
    import yaml

    if not path.exists():
        configure({})
        return
    try:
        data = yaml.safe_load(path.read_text()) or {}
        values = data.get("plugins", {}).get("entries", {}).get("hermes-swift", {}).get("settings", {})
        if not isinstance(values, dict):
            raise ValueError("plugin settings must be a mapping")
    except (OSError, ValueError, AttributeError, yaml.YAMLError) as exc:
        raise RuntimeError(f"Cannot load Hermes configuration: {path}") from exc
    configure(values)


def ensure_chrome() -> str:
    """Historical function name: attach to the verified Cloak service only."""
    from .cloak import require_session
    return require_session()


def main(argv=None) -> int:
    from .cloak import main as cloak_main
    return cloak_main(argv)


if __name__ == '__main__':
    raise SystemExit(main())
