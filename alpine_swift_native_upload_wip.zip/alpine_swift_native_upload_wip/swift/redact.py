"""Masks secrets in snapshots, logs, traces and tool results.

Two layers: structural masking (fields marked ``sensitive`` by snapshot.js never carry a value), and a
registry of exact secret values (identity numbers, anything Hermes's vault fills) that are scrubbed from
any string before it leaves the process.
"""

from __future__ import annotations

import re
import threading
from typing import Any

_LOCK = threading.Lock()
_SECRETS: set[str] = set()
MASK = "[redacted]"

_PATTERNS = [
    re.compile(r"\b(?:\d[ -]?){13,19}\b"),          # card-like digit runs
    re.compile(r"\b\d{4}[ -]?\d{4}[ -]?\d{4}\b"),     # Aadhaar-like 12 digits
    re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b"),            # PAN
]


_HOST_REGISTRAR = None  # Hermes's ctx.register_redaction_patterns, set by the runtime
_HOST_SENT: set[str] = set()


def set_host_registrar(fn) -> None:
    global _HOST_REGISTRAR
    _HOST_REGISTRAR = fn


def _host_patterns(value: str) -> list[str]:
    """Exact-value patterns for Hermes's redaction (it requires >= 2 literal leading characters)."""
    pats = [re.escape(value)]
    digits = re.sub(r"\D", "", value)
    if len(digits) >= 8 and digits != value:
        pats.append(re.escape(digits))
    if len(digits) >= 8:
        pats.append(digits[:2] + "".join(f"[ -]?{c}" for c in digits[2:]))
    return [p for p in pats if len(re.sub(r"\\.", "x", p)) >= 2]


def register(value: str) -> None:
    """Remember a secret value (and its digit-only form) so it is scrubbed everywhere: here, and in Hermes's
    own redaction boundary (logs, tool results, model egress) through the public plugin API."""
    if not value:
        return
    with _LOCK:
        _SECRETS.add(value)
        digits = re.sub(r"\D", "", value)
        if len(digits) >= 6:
            _SECRETS.add(digits)
        fresh = value not in _HOST_SENT
        _HOST_SENT.add(value)
    if fresh and _HOST_REGISTRAR is not None:
        try:
            _HOST_REGISTRAR(_host_patterns(value))
        except Exception:
            pass


def scrub_text(text: str) -> str:
    if not isinstance(text, str) or not text:
        return text
    with _LOCK:
        secrets = sorted(_SECRETS, key=len, reverse=True)
    for s in secrets:
        if s in text:
            text = text.replace(s, MASK)
        if s.isdigit() and len(s) >= 6:
            # Also catch the same digits written with spaces or dashes.
            spaced = r"[ -]?".join(re.escape(c) for c in s)
            text = re.sub(spaced, MASK, text)
    for p in _PATTERNS:
        text = p.sub(MASK, text)
    return text


SENSITIVE_KEYS = {"password", "card_number", "cvv", "cvc", "otp", "secret", "token", "api_key", "aadhaar", "pan"}


def scrub(obj: Any) -> Any:
    """Deep-scrub a JSON-like object. Sensitive actions lose their value; strings are scrubbed."""
    if isinstance(obj, str):
        return scrub_text(obj)
    if isinstance(obj, list):
        return [scrub(x) for x in obj]
    if isinstance(obj, tuple):
        return [scrub(x) for x in obj]
    if isinstance(obj, dict):
        out = {}
        sensitive = bool(obj.get("sensitive"))
        for k, v in obj.items():
            if k == "screenshot":
                out[k] = "[screenshot omitted]"
            elif isinstance(k, str) and k.lower() in SENSITIVE_KEYS and v:
                out[k] = MASK
            elif sensitive and k in ("value", "current_value", "text") and v:
                out[k] = "[masked]"
            else:
                out[k] = scrub(v)
        return out
    return obj


def clear() -> None:
    with _LOCK:
        _SECRETS.clear()
        _HOST_SENT.clear()
