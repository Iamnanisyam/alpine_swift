"""The fast loop: observe, one Jev fan-out decision, gated and guarded action, code verification.

Ported from browser-use/jev-ultrafast ``agent.py`` (MIT, Copyright (c) 2026 Browser Use): the decision
is consumed once before any mutation, a stale page means observe-and-decide again (never act twice),
and three consecutive actions that changed nothing stop the loop. Added: confidence gates by risk,
the shuffled-order check, subgoal predicates, blockers that go to the user, and live-view controls.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from . import jev as jevmod
from . import predicates
from .config import settings
from .page import ActionRefused, Covered, Page, StalePage
from .transport import CDPError, TransportLost

DONE, BLOCKED, LOW_CONFIDENCE, NEEDS_USER, NEEDS_REVIEW, BUDGET, STOPPED, REPLAN = (
    "done", "blocked", "low_confidence", "needs_user", "needs_review", "budget", "stopped", "replan")


@dataclass
class Subgoal:
    description: str
    success: dict
    risk: str = "read_only"
    ready: Optional[dict] = None  # optional predicate that must pass before an irreversible step


@dataclass
class LoopResult:
    status: str
    reason: str = ""
    verified: bool = False
    steps: int = 0
    pending: Optional[dict] = None
    blocker: Optional[str] = None
    check: Optional[dict] = None
    skip_to: Optional[int] = None  # index of a later subgoal whose predicate already passes


class Control:
    """Pause / step / resume / stop / take-over, shared with the live view."""

    def __init__(self):
        self._cv = threading.Condition()
        self.paused = False
        self.steps_allowed = 0
        self.stopped = False
        self.takeover = False
        self.takeovers = 0  # completed take-overs; the loop tells Jev the user acted on the page
        self.state = "running"

    def before_action(self) -> bool:
        """Block while paused or taken over; False when the task was stopped."""
        with self._cv:
            while not self.stopped and (self.takeover or (self.paused and self.steps_allowed == 0)):
                self.state = "takeover" if self.takeover else "paused"
                self._cv.wait(timeout=0.5)
            if self.stopped:
                self.state = "stopped"
                return False
            if self.paused:
                self.steps_allowed -= 1
            self.state = "running"
            return True

    def set(self, command: str) -> None:
        with self._cv:
            if command == "pause":
                self.paused, self.steps_allowed = True, 0
            elif command == "step":
                self.paused, self.steps_allowed = True, self.steps_allowed + 1
            elif command == "resume":
                self.paused, self.steps_allowed = False, 0
            elif command == "stop":
                self.stopped = True
            elif command == "takeover":
                self.takeover = True
            elif command == "handback":
                if self.takeover:
                    self.takeovers += 1
                self.takeover = False
            self._cv.notify_all()


@dataclass
class LoopContext:
    page: Page
    jev: jevmod.JevClient
    goal: str
    trace: Any
    fill_form: Optional[Callable[..., dict]] = None  # forms.fill_form bound by the controller
    decision_fallback: Any = None  # direct LLM, only on Jev failure or uncertainty
    control: Control = field(default_factory=Control)
    history: list = field(default_factory=list)
    risk_ceiling: str = "normal"
    on_step: Optional[Callable[[dict], None]] = None
    max_steps: int = 0
    plan_future: Any = None  # the planner's pending result; the loop yields at a step boundary when it lands


class FastLoop:
    def __init__(self, ctx: LoopContext, subgoal: Subgoal, later: Optional[list[tuple[int, dict]]] = None):
        self.ctx = ctx
        self.subgoal = subgoal
        # (index, predicate) of later subgoals, furthest first; one that passes means this step is behind us.
        self.later = sorted(later or [], key=lambda x: -x[0])
        cfg = settings()
        self.t_read = float(cfg.get("thresholds.read_only", 0.5))
        self.t_rev = float(cfg.get("thresholds.reversible", 0.7))
        self.t_rev_op = float(cfg.get("thresholds.reversible_operation", 0.4))
        self.max_steps = ctx.max_steps or int(cfg.get("max_steps_per_subgoal", 40))
        # WAIT is bounded by time, not by count: each wait returns as soon as the page changes, and consecutive
        # waits grow (1 s, 2 s, ... up to 4 s) until max_wait_s in total for this subgoal.
        self.max_wait_s = float(cfg.get("max_wait_s", 30))
        self.waited_s = 0.0
        self.covered = 0  # consecutive attempts whose target was under another element
        self.decision: Optional[dict] = None
        self.unverified_done = 0
        self.seen_takeovers = ctx.control.takeovers

    # ------------------------------------------------------------------ helpers

    def observe(self) -> dict:
        try:
            return self.ctx.page.observe()
        except TransportLost:
            self.ctx.page.reattach()
            return self.ctx.page.observe()

    def verify(self, obs: dict) -> dict:
        return predicates.check(self.subgoal.success, obs, self.ctx.page)

    def _log(self, event: str, **data) -> None:
        if self.ctx.trace:
            self.ctx.trace.log(event, subgoal=self.subgoal.description, **data)

    @staticmethod
    def action_risk(d: dict, subgoal_risk: str = "read_only") -> str:
        """Risk of this one action. Typing or choosing a value commits nothing (reversible). A click is as risky
        as the highest of Jev's label, the code floor and, for a button inside a form while the subgoal is
        irreversible, the subgoal itself (an unlabelled "Continue" can submit). Scroll and wait only read."""
        action = d.get("action") or {}
        kind = action.get("kind")
        if kind in ("scroll", "wait") or d["operation"] not in jevmod.OPERATION_LABELS:
            return "read_only"
        if kind in ("fill", "select"):
            return "reversible"
        if kind == "enter":
            return max(d["jev_risk"], d["code_risk"], key=jevmod.RISK_ORDER.get)
        risk = max(d["jev_risk"], d["code_risk"], key=jevmod.RISK_ORDER.get)
        submit_like = action.get("role") == "button" and (action.get("form") is not None or
                                                         (action.get("field") or {}).get("type") == "submit")
        if subgoal_risk == "irreversible" and submit_like:
            risk = "irreversible"
        return risk

    def _gate(self, d: dict, obs: dict) -> tuple[bool, str]:
        """Confidence gates by risk. Returns (act, reason); sets ``d["gate_status"]`` when not acting."""
        d["gate_status"] = LOW_CONFIDENCE
        risk = self.action_risk(d, self.subgoal.risk)
        d["gated_risk"] = risk
        op_c = d["confidence"]
        tgt_c = d["target_confidence"] if d["target_confidence"] is not None else op_c
        mass = jevmod.form_mass(d, obs)
        if mass is not None and mass > tgt_c:
            d["form_mass"] = round(mass, 3)
            tgt_c = mass  # the whole form is the target of TYPE_TEXT
        if d.get('source') == 'llm_fallback':
            # Model-reported confidence is not a calibrated Jev probability and
            # is never treated as independent shuffled agreement. High-impact
            # decisions still require explicit review.
            if self.ctx.risk_ceiling == 'read_only' and risk != 'read_only':
                d['gate_status'] = BLOCKED
                return False, 'fallback action refused by read-only ceiling'
            if risk == 'irreversible':
                # A single LLM answer is not Jev agreement. Auto mode still
                # requires a supplied completion predicate, a separate readiness
                # check, confidence threshold, and no payment action.
                ready = (predicates.check(self.subgoal.ready, obs, self.ctx.page)['passed'] if self.subgoal.ready
                         else predicates.form_ready(obs, d.get('action')))
                if (settings().get('irreversible_policy', 'auto_after_checks') == 'auto_after_checks'
                        and self.subgoal.success and ready and op_c >= self.t_rev and tgt_c >= self.t_rev
                        and not jevmod.is_payment(d.get('action'))):
                    return True, 'fallback passed readiness and confidence checks; outcome predicate required'
                d['gate_status'] = NEEDS_REVIEW
                return False, 'irreversible fallback action requires user review'
            floor = self.t_read if risk == 'read_only' else self.t_rev
            if op_c < floor or tgt_c < floor:
                return False, 'fallback confidence below threshold'
            return True, 'fallback passed code risk and confidence checks'
        if risk == "read_only":
            if op_c >= self.t_read and tgt_c >= self.t_read:
                return True, "read_only gate passed"
            agree = jevmod.shuffled_agrees(self.ctx.jev, obs, self.subgoal.description, self.ctx.goal,
                                           self.ctx.history, d)
            d["agree"] = agree
            return (True, "read_only re-ask agreed") if agree else (False, "read_only below threshold; re-ask disagreed")
        if self.ctx.risk_ceiling == "read_only":
            d["gate_status"] = BLOCKED
            return False, f"{risk} action refused by risk_ceiling=read_only"
        if d["agree"] is None:
            d["agree"] = jevmod.shuffled_agrees(self.ctx.jev, obs, self.subgoal.description, self.ctx.goal,
                                                self.ctx.history, d)
        if risk == "reversible":
            if op_c >= self.t_rev and tgt_c >= self.t_rev and d["agree"]:
                return True, "reversible gate passed"
            # Below threshold: the spec's re-ask. A second independent shuffled request must pick the same
            # element, the element itself must be clear (target confidence at threshold), and the operation
            # must clear the tuned operation floor.
            if d["agree"] and tgt_c >= self.t_rev and op_c >= self.t_rev_op:
                again = jevmod.shuffled_agrees(self.ctx.jev, obs, self.subgoal.description, self.ctx.goal,
                                               self.ctx.history, d)
                d["agree_reask"] = again
                if again:
                    return True, f"reversible re-ask agreed (op {op_c:.2f}, target {tgt_c:.2f})"
            return False, f"reversible gate failed (op {op_c:.2f}, target {tgt_c:.2f}, agree {d['agree']})"
        # irreversible
        if not d["agree"]:
            return False, "irreversible: shuffled check disagreed"
        ready = (predicates.check(self.subgoal.ready, obs, self.ctx.page)["passed"] if self.subgoal.ready
                 else predicates.form_ready(obs, d.get("action")))
        if not ready:
            return False, "irreversible: subgoal's ready predicate not satisfied"
        # Payment remains subject to the existing explicit approval boundary.
        policy = settings().get('irreversible_policy', 'auto_after_checks')
        if (policy == 'auto_after_checks' and not jevmod.is_payment(d.get('action'))
                and self.subgoal.success and op_c >= self.t_rev and tgt_c >= self.t_rev):
            return True, 'irreversible action passed readiness and confidence checks; outcome predicate required'
        d["gate_status"] = NEEDS_REVIEW
        return False, "irreversible: needs user review"

    def fallback_decision(self, obs: dict, reason: str) -> Optional[dict]:
        fallback = self.ctx.decision_fallback
        if fallback is None:
            return None
        try:
            result = fallback.decide(obs, self.ctx.goal, self.ctx.history)
        except Exception:
            self._log('fallback_failed', reason=reason)
            return None
        self._log('fallback_decision', reason=reason, choice=result.get('choice'),
                  operation=result.get('operation'), confidence=result.get('confidence'))
        return result

    def wait_for_challenge(self, obs: dict, reason: str) -> Optional[dict]:
        """Stay on the observed tab, bound the wait, and never replay a decision."""
        self._log('needs_user', blocker=reason, message='Complete and submit the visible challenge in this tab')
        deadline = time.monotonic() + max(1.0, float(settings().get('challenge_timeout_s', 300)))
        clear_reads = 0
        while time.monotonic() < deadline:
            if not self.ctx.control.before_action():
                return None
            time.sleep(min(1.0, max(0.0, deadline - time.monotonic())))
            try:
                current = self.observe()
                if current.get('tab_id') != obs.get('tab_id'):
                    raise RuntimeError('The challenge tab changed')
                visible = self.ctx.page.challenge_visible()
            except (StalePage, CDPError):
                continue
            clear_reads = 0 if visible else clear_reads + 1
            if clear_reads >= 2:
                self._log('challenge_cleared', blocker=reason)
                return self.observe()
        self._log('challenge_timeout', blocker=reason)
        return None

    # ------------------------------------------------------------------ main

    def run(self) -> LoopResult:
        ctx, steps, obs = self.ctx, 0, self.observe()
        speculative = self.subgoal.risk != "read_only"
        reorder = None  # set for one re-ask after a low-confidence BLOCKED
        while True:
            for index, pred in self.later:
                later_check = predicates.check(pred, obs, ctx.page)
                if later_check["passed"]:
                    self._log("skip_ahead", to_subgoal=index, check=later_check)
                    return LoopResult(DONE, "a later subgoal's check passed", verified=True, steps=steps,
                                      check=later_check, skip_to=index)
            check = self.verify(obs)
            if check["passed"]:
                self._log("verified", check=check)
                return LoopResult(DONE, "predicate passed", verified=True, steps=steps, check=check)
            if ctx.plan_future is not None and ctx.plan_future.done():
                return LoopResult(REPLAN, "plan ready", steps=steps)
            if steps >= self.max_steps:
                return LoopResult(BUDGET, f"step budget {self.max_steps} reached", steps=steps, check=check)
            if not ctx.control.before_action():
                return LoopResult(STOPPED, "stopped by user", steps=steps)
            if ctx.control.takeovers != self.seen_takeovers:
                # The user acted on the page during a take-over: their actions are not in our history.
                self.seen_takeovers = ctx.control.takeovers
                ctx.history.append({"step": len(ctx.history) + 1, "action": "The user took control and acted on "
                                    "the page; judge progress from the page's current state, not from the action "
                                    "count", "kind": "wait", "page_changed": True})
                obs = self.observe()
                continue
            if not ctx.page.fresh(obs):
                obs = self.observe()
            started = time.perf_counter()
            try:
                d = jevmod.decide(ctx.jev, obs, self.subgoal.description, ctx.goal, ctx.history,
                                  shuffled_check=speculative, reorder=reorder)
            except (jevmod.InvalidAnswer, jevmod.JevUnavailable, TimeoutError, ValueError) as exc:
                self._log("jev_failed", error=type(exc).__name__)
                d = self.fallback_decision(obs, 'jev_failed')
                if d is None:
                    return LoopResult(BLOCKED, 'Jev and direct fallback unavailable', steps=steps)
                if not ctx.page.fresh(obs):
                    obs = self.observe()
                    continue
            # A low-confidence BLOCKED result can also use the direct fallback.
            if d.get('source') != 'llm_fallback' and d.get('operation') == 'BLOCKED' and d.get('confidence', 0) < self.t_read:
                alternative = self.fallback_decision(obs, 'low_confidence')
                if alternative is not None:
                    if not ctx.page.fresh(obs):
                        obs = self.observe()
                        continue
                    d = alternative
            d["decide_ms"] = round((time.perf_counter() - started) * 1000)
            self.decision = d
            self._log("decision", **{k: d.get(k) for k in ("choice", "operation", "target", "confidence",
                                                            "target_confidence", "risk", "agree", "blocker",
                                                            "nouls", "decide_ms")},
                      label=(d.get("action") or {}).get("label"))
            if ctx.on_step:
                ctx.on_step({"phase": "decision", "decision": d, "page": obs})

            if d["blocker"] in ("captcha", "otp") and d["operation"] in ("BLOCKED", "WAIT", "DONE"):
                # Both current visible evidence and a decision that the goal is
                # blocked are required. Discard a decision on a changed page.
                if not ctx.page.fresh(obs):
                    obs = self.observe()
                    continue
                if hasattr(ctx.page, 'challenge_visible') and ctx.page.challenge_visible():
                    resumed = self.wait_for_challenge(obs, d['blocker'])
                    if resumed is None:
                        return LoopResult(BLOCKED, 'Challenge wait timed out or was stopped; the same tab is retained', steps=steps)
                    obs = resumed
                    continue
                # Do not ask a person to solve an unconfirmed challenge. Re-observe
                # and ask Jev again, bounded by the ordinary step budget.
                ctx.history.append({'kind': 'wait', 'action': 'No visible challenge was confirmed; continue with available controls', 'page_changed': False})
                steps += 1
                obs = self.observe()
                continue
            if d["blocker"] == "login_wall" and d["operation"] in ("BLOCKED", "WAIT", "DONE"):
                return LoopResult(NEEDS_USER, 'login_wall needs the user', steps=steps, blocker='login_wall')
            if d["operation"] == "DONE":
                # Jev's DONE alone never counts.
                fresh = self.observe()
                check = self.verify(fresh)
                if check["passed"]:
                    return LoopResult(DONE, "predicate passed", verified=True, steps=steps, check=check)
                if any(predicates.check(p, fresh, ctx.page)["passed"] for _, p in self.later):
                    obs = fresh
                    continue  # the top of the loop records the skip
                self.unverified_done += 1
                self._log("unverified_done", check=check)
                if self.unverified_done >= 3:
                    return LoopResult(BLOCKED, "model reported done but the success check failed", steps=steps,
                                      check=check)
                # Tell the next decision, in the action history (code-written, not page text), that DONE was
                # premature, so it continues instead of repeating DONE.
                ctx.history.append({"step": len(ctx.history) + 1, "action": "Claimed DONE, but a requirement is "
                                    "still unmet; continue with the remaining requirements", "kind": "wait",
                                    "operation": "DONE", "page_changed": False, "url": fresh.get("url"),
                                    "tab_id": fresh.get("tab_id")})
                obs = fresh
                steps += 1
                continue
            if d["operation"] == "BLOCKED":
                # The spec's read-only rule applies to giving up too: below threshold, re-ask once with the
                # options in a new order before stopping.
                if d["confidence"] < self.t_read and reorder is None:
                    reorder = time.time_ns() % 10_000 + 1
                    self._log("reask_blocked", confidence=d["confidence"])
                    continue
                if d["confidence"] < self.t_read and d.get("candidates"):
                    # Still an unsure "blocked" after the re-ask: that is low confidence, not a dead end. The
                    # planner chooses among Jev's own candidates, or confirms that none should be done.
                    return LoopResult(LOW_CONFIDENCE, f"unsure BLOCKED (confidence {d['confidence']:.2f})",
                                      steps=steps, pending={"decision": d, "page": obs})
                return LoopResult(BLOCKED, "no supported operation can progress", steps=steps,
                                  blocker=d["blocker"] if d["blocker"] != "none" else None)
            reorder = None

            go, why = self._gate(d, obs)
            self._log("gate", act=go, reason=why)
            if not go and d.get('source') != 'llm_fallback' and d.get('gate_status') == LOW_CONFIDENCE:
                alternative = self.fallback_decision(obs, 'low_confidence')
                if alternative is not None:
                    if not ctx.page.fresh(obs):
                        obs = self.observe()
                        continue
                    if alternative.get('operation') == 'BLOCKED':
                        blocker = alternative.get('blocker')
                        if blocker in ('captcha', 'otp') and hasattr(ctx.page, 'challenge_visible') and ctx.page.challenge_visible():
                            resumed = self.wait_for_challenge(obs, blocker)
                            if resumed is None:
                                return LoopResult(BLOCKED, 'Challenge wait timed out or was stopped; the same tab is retained', steps=steps)
                            obs = resumed
                            continue
                        return LoopResult(BLOCKED, 'Direct fallback could not identify a safe action', steps=steps)
                    d = alternative
                    go, why = self._gate(d, obs)
                    self._log('fallback_gate', act=go, reason=why)
            if not go:
                return LoopResult(d["gate_status"], why, steps=steps, pending={"decision": d, "page": obs})

            result = self.execute(d, obs)
            steps += 1
            if result == "stale":
                obs = self.observe()
                continue
            if isinstance(result, LoopResult):
                return result
            obs = self.after(d, obs, result)
            stop = self.no_change_stop() or self.repetition_guard()
            if stop:
                return stop

    def execute(self, d: dict, obs: dict, approved: bool = False):
        """Consume once, then act. Returns 'stale', a LoopResult, or an execution record."""
        ctx = self.ctx
        self.decision = None  # consume once: a retry cannot double-click
        action = d.get("action")
        if action is None:
            return "stale"
        text = None
        started = time.perf_counter()
        try:
            if action["kind"] == "fill" and ctx.fill_form is not None:
                if not ctx.page.fresh(obs):
                    return "stale"
                record = ctx.fill_form(ctx.page, obs, action, goal=ctx.goal, subgoal=self.subgoal.description,
                                       history=ctx.history)
                text = record.get("summary")
                if record.get("needs_user"):
                    return LoopResult(NEEDS_USER, record["needs_user"], blocker="input_required")
            elif action["kind"] == "fill":
                return LoopResult(BLOCKED, "TYPE_TEXT needs the form filler")
            elif action["kind"] == "wait":
                if self.waited_s >= self.max_wait_s:
                    return LoopResult(BLOCKED, f"the page did not change in {self.waited_s:.0f} s of waiting")
                seconds = min(1.0 + self.consecutive_waits(), 4.0, self.max_wait_s - self.waited_s)
                ctx.page.act({**action, "wait_s": seconds}, obs)
                self.waited_s += time.perf_counter() - started
            else:
                ctx.page.act(action, obs)
        except Covered as exc:
            # The target is there but under something else (a suggestion list, a banner). Re-deciding blindly
            # would pick it again: the history says what covers it, and three in a row stop the loop.
            self.covered += 1
            self._log("covered", target=exc.label, cover=exc.cover)
            if self.covered >= 3:
                return LoopResult(BLOCKED, f"target stays covered: {exc}")
            ctx.history.append({"step": len(ctx.history) + 1, "note": True, "kind": "wait", "page_changed": False,
                                "action": f"Could not click {exc}; close or avoid what covers it, or use another "
                                          "way to do this", "url": obs.get("url"), "tab_id": obs.get("tab_id")})
            return "stale"
        except StalePage:
            return "stale"
        except ActionRefused as exc:
            self._log("refused", error=str(exc))
            return LoopResult(BLOCKED, f"action refused: {exc}")
        except TimeoutError:
            if d.get("gated_risk") == "irreversible" or approved:
                # Never retry a submit blindly; check whether it already went through.
                fresh = self.observe()
                if self.verify(fresh)["passed"]:
                    return LoopResult(DONE, "confirmation found after timeout", verified=True)
                return LoopResult(BLOCKED, "submit timed out and no confirmation is visible; not retried")
            return "stale"
        except TransportLost:
            ctx.page.reattach()
            return "stale"
        except RuntimeError as exc:
            return LoopResult(BLOCKED, str(exc))
        self.covered = 0
        return {"text": text, "exec_ms": round((time.perf_counter() - started) * 1000), "kind": action["kind"]}

    def consecutive_waits(self) -> int:
        n = 0
        for h in reversed(self.ctx.history):
            if h.get("note"):
                continue
            if h.get("operation") != "WAIT":
                break
            n += 1
        return n

    def after(self, d: dict, before: dict, record: dict) -> dict:
        ctx = self.ctx
        action = d["action"]
        entry = {
            "step": len(ctx.history) + 1, "action": action["label"], "kind": action["kind"], "choice": d["choice"],
            "choice_node": action.get("vkey") or action.get("node"),
            "operation": d["operation"], "confidence": d["confidence"], "target_confidence": d["target_confidence"],
            "risk": d.get("gated_risk"), "agree": d.get("agree"), "text": record.get("text"),
            "decide_ms": d.get("decide_ms"), "exec_ms": record.get("exec_ms"), "url": before["url"],
            "tab_id": before.get("tab_id"), "page_changed": None,
        }
        ctx.history.append(entry)
        obs = self.observe()
        entry["page_changed"] = obs["fingerprint"] != before["fingerprint"]
        entry["url_after"] = obs["url"]
        self._log("action", **entry)
        if ctx.on_step:
            ctx.on_step({"phase": "action", "entry": entry, "page": obs})
        return obs

    def repeated(self) -> int:
        """How many times in a row the last action (same element, kind and page) was executed."""
        acts = [h for h in self.ctx.history if not h.get("note")]
        if not acts or acts[-1].get("operation") == "WAIT":
            return 0  # waiting is bounded by time (max_wait_s), not by repetition
        if acts[-1].get("kind") == "scroll" and acts[-1].get("page_changed"):
            return 0  # a scroll that moved the page is progress; the page's end shows as "changed nothing"
        key = lambda h: (h.get("choice_node") or h.get("action"), h.get("kind"), h.get("url"))  # noqa: E731
        last, n = key(acts[-1]), 0
        for h in reversed(acts):
            if key(h) != last:
                break
            n += 1
        return n

    def repetition_guard(self) -> Optional[LoopResult]:
        """The same action again and again is a loop even when the page changes each time (a menu toggling open
        and shut). At 3 the history tells Jev to try something else; at 5 the loop stops."""
        n = self.repeated()
        if n >= 5:
            return LoopResult(BLOCKED, f"repeated '{self.ctx.history[-1]['action']}' 5 times without reaching the goal",
                              steps=len(self.ctx.history))
        if n == 3:
            last = self.ctx.history[-1]
            self.ctx.history.append({"step": len(self.ctx.history) + 1, "note": True, "kind": "wait",
                                     "action": f"'{last['action']}' was done 3 times in a row without reaching the "
                                               "goal; if the goal does not ask for it again, choose a different action",
                                     "page_changed": False, "url": last.get("url"), "tab_id": last.get("tab_id")})
        return None

    def no_change_stop(self) -> Optional[LoopResult]:
        """jev-ultrafast's guard: three consecutive actions that changed nothing stop the loop. Kept when they
        include the same control twice (stuck). Three *different* controls that changed nothing are exploration
        (a page where most controls are decoys: WebGames "buttons" hides its answer behind the 17th of 17), so
        the stop then comes at ``max_no_change`` (6) in a row."""
        acts = [h for h in self.ctx.history if not h.get("note")]
        run = 0
        for h in reversed(acts):
            if h.get("page_changed") is not False or h.get("kind") == "wait":
                break
            run += 1
        if run < 3:
            return None
        recent = acts[-3:]
        distinct = len({(h.get("choice_node") or h.get("action"), h.get("kind")) for h in recent}) == 3
        if not distinct:
            return LoopResult(BLOCKED, "three consecutive actions changed nothing", steps=len(self.ctx.history))
        if run >= int(settings().get("max_no_change", 6)):
            return LoopResult(BLOCKED, f"{run} consecutive actions changed nothing", steps=len(self.ctx.history))
        return None
