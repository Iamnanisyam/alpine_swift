"""Observed actions over a CDP transport, one task-owned tab per Page.

Ported from browser-use/jev-ultrafast ``browser.py`` (MIT, Copyright (c) 2026 Browser Use).
Kept exactly: freshness guard before input, geometry re-resolved and ``elementFromPoint``
hit-tested immediately before input, node ids owned by code. Added: tab id checks, masked
sensitive fields, ``press_key``, ``set_files``, ``scroll_container``, ``read_value`` and a
secret-typing path that never returns values.
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path
from typing import Any, Optional

from .transport import CDP, CDPError, TabRef

READ_STATE = Path(__file__).with_name("snapshot.js").read_text()
MARKER = f"(() => {{ const state={READ_STATE}; return state?.marker ?? null; }})()"
SELECT_ALL_MOD = 4 if sys.platform == "darwin" else 2

KEYS = {
    "Enter": ("Enter", "Enter", 13, "\r"), "Tab": ("Tab", "Tab", 9, ""), "Escape": ("Escape", "Escape", 27, ""),
    "Backspace": ("Backspace", "Backspace", 8, ""), "ArrowDown": ("ArrowDown", "ArrowDown", 40, ""),
    "ArrowUp": ("ArrowUp", "ArrowUp", 38, ""), "ArrowLeft": ("ArrowLeft", "ArrowLeft", 37, ""),
    "ArrowRight": ("ArrowRight", "ArrowRight", 39, ""), "Home": ("Home", "Home", 36, ""),
    "End": ("End", "End", 35, ""), "PageDown": ("PageDown", "PageDown", 34, ""), "PageUp": ("PageUp", "PageUp", 33, ""),
    "Space": (" ", "Space", 32, " "),
}


class StalePage(ValueError):
    """A decision no longer refers to the observed page."""


class Covered(StalePage):
    """The target is on the page, but another element is on top of every point we would click."""

    def __init__(self, label: str, cover: str):
        super().__init__(f"'{label}' is covered by '{cover}'")
        self.label, self.cover = label, cover


class ActionRefused(RuntimeError):
    """The action was not executed, by rule (sensitive field, wrong tab, invalid node)."""


def fingerprint(state: dict) -> str:
    content = {k: state.get(k) for k in ("url", "text", "actions", "scroll")}
    return hashlib.sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()


# Resolve a code-owned node, refuse anything not visible, enabled and on top at the point that is clicked.
# Returns {x, y}; {covered: <label>} when the element is there but something else is on top of it; else null.
_RESOLVE = """(action => {
  const e=window.__jevFast?.nodes.get(action.node);
  if (!e?.isConnected || e.matches(':disabled') || e.closest('[aria-disabled="true"],[inert]')) return null;
  // A styled checkbox or radio may be transparent over its own drawing; it must still be on top (below).
  const toggle=e instanceof HTMLInputElement && ['checkbox','radio'].includes(e.type);
  if (!e.checkVisibility({checkOpacity:!toggle,checkVisibilityCSS:true})) return null;
  if ((action.kind==='fill' || action.kind==='enter') && (e.readOnly || e.getAttribute('aria-readonly')==='true')) return null;
  const r=e.getBoundingClientRect(), p=action.point;
  if (!r.width || !r.height) return null;
  // A code-computed point inside the element (board squares), else its centre, else other points inside it
  // when something covers the centre (a partly covered button). Never a model coordinate.
  const given=p && p.fx>0 && p.fx<1 && p.fy>0 && p.fy<1;
  const points=given ? [[p.fx,p.fy]] : [[.5,.5],[.25,.5],[.75,.5],[.5,.25],[.5,.75],[.12,.5],[.88,.5]];
  let x=null, y=null, cover=null;
  for (const [fx,fy] of points) {
    const px=r.x+r.width*fx, py=r.y+r.height*fy;
    if (px<0 || py<0 || px>=innerWidth || py>=innerHeight) continue;
    const hit=document.elementFromPoint(px,py);
    if (hit && e.contains(hit)) { x=px; y=py; break; }
    cover=cover || hit;
  }
  if (x===null) {
    if (!cover) return null;
    const t=(cover.getAttribute('aria-label') || cover.innerText || '').replace(/\\s+/g,' ').trim().slice(0,60);
    return {covered: t || cover.tagName.toLowerCase()};
  }
  if (action.kind==='select') {
    if (e.tagName!=='SELECT') return null;
    const opt=[...e.options].find(o=>o.value===action.value && !o.disabled && !o.closest('optgroup[disabled]'));
    if (!opt) return null;
  }
  return {x,y};
})"""

_SETTLE = """(action => new Promise(resolve => {
  const field=window.__jevFast?.nodes.get(action.node);
  const autocomplete=action.kind==='fill' && field?.getAttribute('role')==='combobox';
  let frames=0, stopped=false;
  const finish=()=>{stopped=true;resolve()};
  setTimeout(finish,autocomplete ? 200 : 50);
  const ready=()=>{
    if (stopped) return;
    const ids=(field?.getAttribute('aria-controls')||field?.getAttribute('aria-owns')||'')
      .split(/\\s+/).filter(Boolean);
    const roots=ids.length ? ids.map(id=>document.getElementById(id)).filter(Boolean) : [document];
    const options=roots.flatMap(root=>[...root.querySelectorAll('[role="option"]')]);
    if (++frames>=2 && (!autocomplete || options.some(e=>{
      const r=e.getBoundingClientRect();
      return r.width && r.height && r.bottom>0 && r.top<innerHeight &&
        e.checkVisibility({checkOpacity:true,checkVisibilityCSS:true});
    }))) finish();
    else requestAnimationFrame(ready);
  };
  requestAnimationFrame(ready);
}))"""


class Page:
    """One task-owned tab. Every snapshot carries the tab id; ``fresh`` checks it."""

    def __init__(self, cdp: CDP, tab: TabRef, *, id_patterns: Optional[list[str]] = None,
                 width: int = 1280, height: int = 800):
        self.cdp = cdp
        self.tab = tab
        self.after_input: Optional[dict] = None
        self.id_patterns = id_patterns or []
        self.closed = False
        self._setup(width, height)

    # -------------------------------------------------------------- plumbing

    @classmethod
    def open(cls, cdp: CDP, url: str, *, context_id: Optional[str] = None, **kw) -> "Page":
        tab = cdp.new_tab("about:blank", context_id=context_id)
        page = cls(cdp, tab, **kw)
        if url and url != "about:blank":
            page.navigate(url)
        return page

    @property
    def tab_id(self) -> str:
        return self.tab.target_id

    def _setup(self, width: int, height: int) -> None:
        self.call("Page.enable")
        self.call("Emulation.setDeviceMetricsOverride", width=width, height=height, deviceScaleFactor=1, mobile=False)
        # Focus emulation (jev-ultrafast) keeps the page "focused" and visible even when another window is in
        # front; without it a hidden page stops rendering and input waits up to 5 s.
        self.call("Emulation.setFocusEmulationEnabled", enabled=True)
        self.call("Page.addScriptToEvaluateOnNewDocument",
                  source=f"window.__swiftConfig={json.dumps({'idPatterns': self.id_patterns})};")
        self.evaluate(f"window.__swiftConfig={json.dumps({'idPatterns': self.id_patterns})}")

    def call(self, method: str, timeout: float = 10.0, **params) -> dict:
        if self.closed:
            raise ActionRefused("This tab is closed.")
        return self.cdp.call(method, params, session_id=self.tab.session_id, timeout=timeout)

    def reattach(self) -> None:
        """After ``TransportLost``: attach a new session to the same tab and restore emulation."""
        sid = self.cdp.attach(self.tab.target_id)
        self.tab = TabRef(self.tab.target_id, sid, self.tab.context_id)
        self._setup(1280, 800)

    def evaluate(self, expression: str, await_promise: bool = False, timeout: float = 10.0):
        response = self.call("Runtime.evaluate", expression=expression, returnByValue=True,
                             awaitPromise=await_promise, timeout=timeout)
        if response.get("exceptionDetails"):
            raise StalePage("Document changed during evaluation")
        return response.get("result", {}).get("value")

    def navigate(self, url: str, wait_s: float = 20.0) -> None:
        from .urlsafety import check

        reason = check(url)
        if reason:
            raise ActionRefused(f"Refusing to open {url!r}: {reason}")
        self.call("Page.navigate", url=url)
        self.wait_ready(wait_s)

    def wait_ready(self, wait_s: float = 15.0, settle_s: float = 2.0) -> None:
        """Until the document is complete, or has been interactive for ``settle_s``: pages heavy with ads and
        trackers stay 'interactive' for many seconds (dictionary.com: over 20 s) while their content is usable."""
        deadline = time.monotonic() + wait_s
        interactive_since = None
        while time.monotonic() < deadline:
            try:
                state = self.evaluate("document.readyState")
                if state == "complete":
                    return
                if state == "interactive":
                    interactive_since = interactive_since or time.monotonic()
                    if time.monotonic() - interactive_since >= settle_s:
                        return
            except (StalePage, CDPError):
                pass
            time.sleep(0.03)

    # -------------------------------------------------------------- observe

    def observe(self, screenshot: bool = False) -> dict:
        if self.after_input:
            action, self.after_input = self.after_input, None
            try:
                self.call("Runtime.evaluate", expression=f"{_SETTLE}({json.dumps(_slim(action))})",
                          awaitPromise=True, returnByValue=True, timeout=3)
            except (CDPError, TimeoutError):
                pass
        for attempt in range(10):
            try:
                info = self.evaluate(READ_STATE)
                if info is None:
                    raise StalePage("Document is navigating")
                info["fingerprint"] = fingerprint(info)
                info["tab_id"] = self.tab_id
                if screenshot:
                    info["screenshot"] = self.call("Page.captureScreenshot", format="jpeg", quality=72)["data"]
                return info
            except StalePage:
                if attempt == 9:
                    raise
                time.sleep(0.02 * (attempt + 1))
        raise StalePage("Page did not settle")

    def fresh(self, page: dict, action: Optional[dict] = None) -> bool:
        if page.get("tab_id") != self.tab_id:
            return False
        if action is not None and action["kind"] in {"click", "select"}:
            node = action["node"]
            if type(node) is not int:
                return False
            current = self.evaluate(
                "(() => { const c=window.__jevFast; "
                f"return c ? [c.pageKey(),c.guard(c.nodes.get({node}))] : null; }})()"
            )
            return current == [page["page_key"], page["guards"].get(str(node))]
        return self.evaluate(MARKER) == page["marker"]

    # -------------------------------------------------------------- act

    def act(self, action: dict, page: dict, text: Optional[str] = None, *, secret: bool = False) -> dict:
        """Execute one observed action. ``secret=True`` is only for vault/identity values."""
        if page.get("tab_id") != self.tab_id:
            raise ActionRefused("Action names a tab this page does not own.")
        if action["kind"] == "fill" and action.get("sensitive") and not secret:
            raise ActionRefused(f"Field is {action['sensitive']}; values come only from the vault or identity store.")
        if not self.fresh(page, action):
            raise StalePage("Page changed since this decision. Observe again.")
        kind = action["kind"]
        if kind == "wait":
            changed = self.wait_for_change(page, float(action.get("wait_s", 1.0)))
            return {"executed": action["id"], "changed": changed}
        if kind == "scroll":
            dx, dy = int(action.get("delta_x") or 0), int(action.get("delta") or 0)
            self._human([('move', page.get('w', 1280) // 2, int(page.get('h', 800) * 0.8)),
                         ('wheel', dx, dy)])
            self.after_input = action
            return {"executed": action["id"]}
        if type(action.get("node")) is not int:
            raise ActionRefused("Invalid observed node")
        try:
            target = self.evaluate(f"{_RESOLVE}({json.dumps(_slim(action))})")
        except StalePage:
            if kind == "select":
                raise RuntimeError("Dropdown execution was interrupted; inspect before retrying.") from None
            raise
        if target is None:
            if kind == "select":
                raise RuntimeError("Dropdown execution was not confirmed; inspect before retrying.")
            raise StalePage("Target changed or is covered. Observe again.")
        if target.get("covered"):
            raise Covered(str(action.get("label", ""))[:60], str(target["covered"]))
        if kind == "select":
            self.select_node(action['node'], action['value'])
        else:
            steps = [('click', target['x'], target['y'])]
            if kind == 'enter':
                steps.append(('press', 'Enter'))
            if kind == 'fill':
                if text is None:
                    raise ActionRefused('No text to type.')
                steps.extend([('press', 'ControlOrMeta+A'), ('type', text)])
            self._human(steps, label=f"{kind.capitalize()} {str(action.get('label', ''))[:16]}")
        self.after_input = action
        return {"executed": action["id"]}

    def challenge_visible(self) -> bool:
        # Positive, currently visible evidence only; provider reputation and a
        # Jev prediction alone never trigger a handoff. Frame interiors cannot
        # always be inspected across origins, so this is necessarily heuristic.
        script = Path(__file__).with_name('challenge.js').read_text()
        return bool(self.evaluate(script))

    def wait_for_change(self, page: dict, seconds: float) -> bool:
        """WAIT: return as soon as the page differs from the observation (same marker ``fresh`` uses), or after
        ``seconds``. True when it changed. A navigation counts as a change."""
        deadline = time.monotonic() + max(0.1, seconds)
        while True:
            try:
                if self.evaluate(MARKER) != page.get("marker"):
                    return True
            except (StalePage, CDPError):
                return True
            if time.monotonic() >= deadline:
                return False
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))

    def _human(self, steps, label: str = '') -> None:
        from .human_input import perform
        from .redact import scrub_text
        perform(self.tab_id, steps, label=scrub_text(label)[:24])

    def _click_at(self, x: float, y: float) -> None:
        self._human([('click', x, y)])

    def _select_all(self) -> None:
        self._human([('press', 'ControlOrMeta+A')])

    def type_keys(self, text: str) -> None:
        self._human([('type', text)])

    def press_key(self, key: str) -> None:
        if key not in KEYS:
            raise ActionRefused(f'Unsupported key {key!r}')
        self._human([('press', key)])

    def select_node(self, node: int, value: str) -> None:
        # Tag only the already-observed node, so model output is never a selector.
        import secrets
        token = secrets.token_hex(16)
        tagged = self.evaluate(f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); "
                               f"if (!e?.isConnected) return false; e.setAttribute('data-swift-target', {json.dumps(token)}); return true; }})()")
        if not tagged:
            raise StalePage('Select is no longer connected')
        try:
            self._human([('select', f'[data-swift-target="{token}"]', value)])
        finally:
            try:
                self.evaluate(f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); "
                              f"if (e?.getAttribute('data-swift-target')==={json.dumps(token)}) e.removeAttribute('data-swift-target'); }})()")
            except (StalePage, CDPError):
                pass

    def _resolve_in_view(self, node: int, kind: str, block: str = "center") -> Optional[dict]:
        """Hit-test a code-owned node; scroll it into view once if it is off screen."""
        spec = json.dumps({"node": int(node), "kind": kind})
        target = self.evaluate(f"{_RESOLVE}({spec})")
        # Do not inject scrollIntoView: the caller must choose a humanized scroll.
        return None if target is None or target.get("covered") else target

    def click_node(self, node: int, block: str = "center") -> bool:
        """Hit-tested click on an observed node (used by helpers that already matched in code)."""
        target = self._resolve_in_view(node, "click", block)
        if target is None:
            return False
        self._click_at(target["x"], target["y"])
        self.after_input = {"node": node, "kind": "click"}
        return True

    def is_sensitive(self, node: int) -> Optional[str]:
        return self.evaluate(f"(() => {{ const c=window.__jevFast, e=c?.nodes.get({int(node)}); "
                             "return e && c.sensitive ? c.sensitive(e) : null; })()")

    def fill_node(self, node: int, text: str, *, per_key: bool = False, secret: bool = False) -> bool:
        """Type into one code-owned field: hit-test, click, select all, insert (or per-key for masks).
        Used by the form filler for every field of the form Jev chose. Sensitive fields only with ``secret``."""
        state = self.evaluate(
            f"(() => {{ const c=window.__jevFast, e=c?.nodes.get({int(node)}); "
            "if (!e?.isConnected) return null; return {"
            "sensitive:c.sensitive ? c.sensitive(e) : null, focused:document.activeElement===e, "
            f"same:('value' in e && String(e.value)==={json.dumps(text)})}}; }})()")
        if state is None:
            return False
        if not secret and state.get("sensitive"):
            raise ActionRefused("Field is sensitive; values come only from the vault or identity store.")
        target = self._resolve_in_view(node, "fill")
        if target is None:
            return False
        if state.get("same"):
            return True
        if not state.get("focused"):
            self._click_at(target["x"], target["y"])
        self._human([('press', 'ControlOrMeta+A'), ('type', text)])
        self.after_input = {"node": int(node), "kind": "fill"}
        return True

    def focus_node(self, node: int) -> bool:
        return self.click_node(node)

    def _node_input(self, node: int, operation: str, value, *, origin: Optional[str] = None) -> None:
        """Give the adapter a temporary selector for a code-owned, observed node."""
        import secrets
        token = secrets.token_hex(16)
        tagged = self.evaluate(f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); "
                               f"if (!e?.isConnected || e.disabled) return false; e.setAttribute('data-swift-target', {json.dumps(token)}); return true; }})()")
        if not tagged:
            raise StalePage('Observed target is no longer connected')
        selector = f'[data-swift-target="{token}"]'
        try:
            self._human([(operation, selector, value, origin)] if origin else [(operation, selector, value)])
        finally:
            try:
                self.evaluate(f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); "
                              f"if (e?.getAttribute('data-swift-target')==={json.dumps(token)}) e.removeAttribute('data-swift-target'); }})()")
            except (StalePage, CDPError):
                pass

    def vault_descriptor(self, node: int) -> Optional[dict]:
        # No field values are read or returned.
        return self.evaluate(f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); "
            "if (!e?.isConnected) return null; return {index:1, type:e.type||'', name:e.name||'', "
            "autocomplete:e.autocomplete||'', label:e.getAttribute('aria-label') || "
            "[...(e.labels||[])].map(l=>l.innerText).join(' '), maxLength:e.maxLength>0?e.maxLength:null}; })()")

    def fill_vault_value(self, node: int, value: str, origin: str, *, expected: str = 'password') -> bool:
        # Never insert the value into a CDP evaluation expression or a log.
        sensitive = self.is_sensitive(node)
        if (expected == 'password' and sensitive != 'password') or (expected == 'card' and sensitive != 'card'):
            return False
        if self._resolve_in_view(node, 'fill') is None:
            return False
        self._node_input(node, 'fill_bound', value, origin=origin)
        return self.has_value(node)

    def set_files(self, node: int, paths: list[str]) -> None:
        # Playwright FileChooser.set_files and set_input_files both assign the
        # input. The requested native OS chooser path is not implemented.
        raise ActionRefused('Native file chooser automation is not available')

    def scroll_container(self, node: int, delta: int) -> bool:
        # Unlike the old direct DOM scrollTop mutation, wheel input goes through Cloak.
        state = self.evaluate(
            f"(() => {{ let e=window.__jevFast?.nodes.get({int(node)}); "
            "while(e && e!==document.body && !(e.scrollHeight>e.clientHeight+2 && "
            "/(auto|scroll)/.test(getComputedStyle(e).overflowY))) e=e.parentElement; "
            "if(!e || e===document.body) return null; const r=e.getBoundingClientRect(); "
            "return {x:r.x+r.width/2,y:r.y+r.height/2,before:e.scrollTop}; })()")
        if not state:
            return False
        self._human([('move', state['x'], state['y']), ('wheel', 0, int(delta))])
        after = self.evaluate(
            f"(() => {{ let e=window.__jevFast?.nodes.get({int(node)}); "
            "while(e && e!==document.body && !(e.scrollHeight>e.clientHeight+2 && "
            "/(auto|scroll)/.test(getComputedStyle(e).overflowY))) e=e.parentElement; "
            "return e && e!==document.body ? e.scrollTop : null; })()")
        return after is not None and after != state['before']

    def read_value(self, node: int) -> Optional[str]:
        """Committed value of a field; sensitive fields come back masked."""
        return self.evaluate(
            f"(() => {{ const c=window.__jevFast, e=c?.nodes.get({int(node)}); if (!e?.isConnected) return null; "
            "if (c.sensitive && c.sensitive(e)) return e.value ? '[masked]' : ''; "
            "if (e.tagName==='SELECT') return [...e.selectedOptions].map(o=>o.label).join(', '); "
            "if (['INPUT','TEXTAREA'].includes(e.tagName)) return String(e.value); "
            "return (e.innerText||'').trim(); })()")

    def doc_id(self) -> Optional[list]:
        """Identity of the current document (changes on navigation)."""
        try:
            return self.evaluate("[performance.timeOrigin, location.href]")
        except (StalePage, CDPError):
            return None

    def http_status(self) -> Optional[int]:
        """The main document's HTTP status (PerformanceNavigationTiming.responseStatus, Chrome 109+)."""
        try:
            value = self.evaluate("(performance.getEntriesByType('navigation')[0]||{}).responseStatus||null")
            return int(value) if value else None
        except (StalePage, CDPError, ValueError, TypeError):
            return None

    def set_value_native(self, node: int, value: str) -> bool:
        """Use Playwright's patched locator for date/time inputs; verify readback."""
        if self._resolve_in_view(node, 'fill') is None:
            return False
        self._node_input(node, 'fill', value)
        return self.read_value(node) == value

    def has_value(self, node: int) -> bool:
        return bool(self.evaluate(
            f"(() => {{ const e=window.__jevFast?.nodes.get({int(node)}); return !!(e && e.value); }})()"))

    def close(self) -> None:
        if not self.closed:
            self.cdp.close_tab(self.tab)
            self.closed = True


def _slim(action: dict) -> dict:
    out = {k: action[k] for k in ("node", "kind", "value") if k in action}
    p = action.get("point")
    if isinstance(p, dict) and all(type(p.get(k)) in (int, float) for k in ("fx", "fy")):
        out["point"] = {"fx": float(p["fx"]), "fy": float(p["fy"])}  # from the snapshot (code), never a model
    return out
