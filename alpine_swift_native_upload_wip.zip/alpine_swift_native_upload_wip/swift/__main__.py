"""One-time configuration; does not start a browser."""
from __future__ import annotations

import getpass
import os
import secrets
import sys
import tempfile
from pathlib import Path
from urllib.parse import urlsplit


def _value(prompt: str) -> str:
    value = getpass.getpass(prompt).strip()
    if '\n' in value or '\r' in value or '\x00' in value:
        raise ValueError('Values must be single-line text')
    return value


def _env_quote(value: str) -> str:
    # Double-quoted EnvironmentFile syntax also works with standard dotenv parsers.
    return '"' + value.replace('\\', '\\\\').replace('"', '\\"') + '"'


def setup() -> None:
    from .chrome import _load_settings_file
    from .cloak import file_lock, profile_dir

    _load_settings_file()
    inception = _value('Inception API key: ')
    typesafe = _value('TypeSafe API key: ')
    proxy = _value('Proxy URL (optional; leave blank for direct): ')
    if not inception or not typesafe:
        raise ValueError('Both Inception and TypeSafe API keys are required; nothing was saved')
    if proxy:
        try:
            p = urlsplit(proxy)
            valid = p.scheme in ('http', 'https', 'socks5') and p.hostname and p.port
        except ValueError:
            valid = False
        if not valid:
            raise ValueError('Proxy must be an http, https, or socks5 URL with host and port')
    envfile = Path(os.environ.get('HERMES_HOME', '~/.hermes')).expanduser() / '.env'
    envfile.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if envfile.is_symlink():
        raise ValueError('Refusing to overwrite a symlinked .env file')
    existing = envfile.read_text() if envfile.exists() else ''
    keys = {'INCEPTION_API_KEY': inception, 'TYPESAFE_API_KEY': typesafe, 'CLOAK_PROXY_URL': proxy}
    lines = [line for line in existing.splitlines() if not any(
        line.strip().startswith(prefix + '=') or line.strip().startswith('export ' + prefix + '=')
        for prefix in keys)]
    lines.extend(k + '=' + _env_quote(v) for k, v in keys.items())
    # The launcher uses the same lock, so setup cannot change identity while it runs.
    with file_lock('swift-service.lock', blocking=False):
        seedfile = profile_dir() / 'swift-fingerprint'
        if seedfile.exists():
            seed = seedfile.read_text().strip()
            if not seed.isdecimal() or not 0 < int(seed) < 2**31:
                raise ValueError('Existing fingerprint seed is invalid; it was not changed')
        else:
            fd = os.open(seedfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as f:
                f.write(str(secrets.randbelow(2**31 - 1) + 1))
        fd, name = tempfile.mkstemp(prefix='.swift-env-', dir=envfile.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, 'w') as f:
                f.write('\n'.join(lines) + '\n')
            os.replace(name, envfile)
        finally:
            if os.path.exists(name):
                os.unlink(name)
    print(f'Saved API keys and proxy setting to {envfile} (owner-only).')
    print(f'Persistent profile and seed: {profile_dir()}')
    print('Next: start the headed browser service and connect VNC if needed; see IMPLEMENTATION_NOTES.md.')


def main() -> int:
    if sys.argv[1:] != ['setup']:
        print('Usage: python -m swift setup', file=sys.stderr)
        return 2
    try:
        setup()
    except (OSError, ValueError, RuntimeError, EOFError, KeyboardInterrupt) as exc:
        print(f'Setup failed: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
