"""Process-wide runtime: one Jev client, one controller, one live view, built lazily on first use."""

from __future__ import annotations

import json
import os
import threading
from typing import Any, Callable, Optional

from . import redact
from .config import DEFAULTS, configure, settings
from .controller import Controller
from .identity import IdentityStore
from .jev import JevClient
from .textmodel import TextModel
from .transport import HarnessCDP

_LOCK = threading.Lock()
_BROWSER_LOCK = threading.Lock()
_RUNTIME: Optional["Runtime"] = None


def cdp_url() -> str:
    """The shared Chrome's debugging endpoint: ``BROWSER_CDP_URL`` (the same override Hermes reads), else the
    launcher's own port from this plugin's settings. Hermes's ``browser.cdp_url`` must point at the same port;
    it is not read here because plugins only see their own settings namespace."""
    url = os.environ.get("BROWSER_CDP_URL", "")
    return url or f"http://127.0.0.1:{settings().get('chrome.port', 9242)}"


class Runtime:
    def __init__(self, *, llm: Any = None, dispatch: Optional[Callable[..., Any]] = None,
                 transport: str = "hermes", cdp: Optional[str] = None):
        self.dispatch = dispatch
        self.transport_kind = transport
        self.cdp_url = cdp or cdp_url()
        self.jev = JevClient()
        self.identity = IdentityStore()
        self.liveview = None
        lv = settings().get("liveview", {})
        if lv.get("enabled", True):
            try:
                from .liveview import LiveView

                self.liveview = LiveView(self.cdp_url, port=int(lv.get("port", 8766))).start()
            except Exception:
                self.liveview = None
        self.controller = Controller(cdp_factory=self._cdp_for, jev=self.jev, llm=llm, dispatch=self._dispatch_for,
                                     # Bind the browse text helper to Mercury 3 even if legacy settings name another provider.
                                     textmodel=TextModel(models=[dict(DEFAULTS['text_models'][0])],
                                                         planner_models=[]), identity=self.identity, liveview=self.liveview,
                                     cdp_url=self.cdp_url)
        self._host_task = threading.local()

    def _cdp_for(self, host_task: str):
        from .cloak import require_session

        require_session(self.cdp_url)
        # Direct attachment cannot ask Hermes/browser-harness to launch another browser.
        return HarnessCDP(self.cdp_url, prefer_harness=False)

    def _dispatch_for(self, name: str, args: dict):
        if self.dispatch is None:
            raise RuntimeError("tool dispatch is only available inside Hermes")
        return self.dispatch(name, args, task_id=getattr(self._host_task, "id", None) or "default")

    def ensure_browser(self) -> None:
        from .cloak import require_session

        with _BROWSER_LOCK:
            self.cdp_url = require_session(self.cdp_url)
            # Companion tools must attach to this same endpoint. Restart Hermes after migration
            # so an already-running supervisor cannot retain the former Chrome session.
            os.environ["BROWSER_CDP_URL"] = self.cdp_url

    def browse(self, args: dict, host_task: str) -> dict:
        self._host_task.id = host_task
        self.ensure_browser()
        from .cloak import task_lock

        with task_lock():
            return self.controller.browse(
                goal=str(args.get("goal", "")).strip(), start_url=str(args.get("start_url") or ""),
                success_criteria=args.get("success_criteria"),
                risk_ceiling="read_only" if args.get("risk_ceiling") == "read_only" else "normal",
                host_task=host_task, profile=args.get("profile") if isinstance(args.get("profile"), dict) else None)


def get(ctx: Any = None, **kw) -> Runtime:
    global _RUNTIME
    with _LOCK:
        if _RUNTIME is None:
            if ctx is not None:
                configure(getter=lambda key, default=None: ctx.get_config(key, default=default))
                if hasattr(ctx, "register_redaction_patterns"):
                    redact.set_host_registrar(ctx.register_redaction_patterns)
            _RUNTIME = Runtime(llm=getattr(ctx, "llm", None),
                               dispatch=(lambda n, a, **k: ctx.dispatch_tool(n, a, **k)) if ctx else None, **kw)
        return _RUNTIME


def reset() -> None:
    global _RUNTIME
    _RUNTIME = None


def dumps(obj: Any) -> str:
    return json.dumps(redact.scrub(obj), default=str, ensure_ascii=False)
