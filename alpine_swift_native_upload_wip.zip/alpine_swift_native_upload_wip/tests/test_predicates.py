"""Code predicates: the only thing that can make a task verified (offline)."""

import pytest

from swift import predicates as P


def obs(url="https://shop.test/a", title="Shop", text="", actions=None):
    return {"url": url, "title": title, "text": text, "actions": actions or [], "disabled_fields": []}


def test_empty_predicate_never_passes():
    assert P.check({}, obs())["passed"] is False
    assert P.check(None, obs())["passed"] is False
    assert P.check({"bogus": 1}, obs())["passed"] is False


def test_all_keys_must_pass():
    o = obs(url="https://w.org/wiki/G%C3%B6del%27s_incompleteness_theorems", title="Gödel's incompleteness theorems",
            text="Results for Lisbon")
    assert P.check({"url_contains": "/wiki/Gödel's", "title_contains": "gödel's incompleteness",
                    "text_visible": ["results for lisbon"]}, o)["passed"]
    assert not P.check({"url_contains": "/wiki/", "text_visible": ["Casa Flora"]}, o)["passed"]


def test_url_matches_regex_and_bad_regex_is_dropped():
    o = obs(url="https://x.test/order/123/confirmed")
    assert P.check({"url_matches": r"/order/\d+/confirmed$"}, o)["passed"]
    assert P.clean({"url_matches": "([unclosed"}) == {}


def test_text_absent():
    assert not P.check({"text_absent": ["error"]}, obs(text="An error occurred"))["passed"]
    assert P.check({"text_absent": ["error"]}, obs(text="All good"))["passed"]


def test_fields_tolerate_formatting():
    actions = [
        {"node": 1, "kind": "fill", "label": "Mobile number *", "value": "(987) 654-3210", "role": "textbox"},
        {"node": 2, "kind": "fill", "label": "Date of birth", "value": "1999-02-14", "role": "textbox"},
        {"node": 3, "kind": "click", "label": "Free cancellation", "role": "checkbox", "checked": "true"},
        {"node": 4, "kind": "select", "label": "Stay category → Nature", "current_value": "Design",
         "selected_value": "Design", "value": "Nature", "role": "combobox"},
    ]
    o = obs(actions=actions)
    assert P.check({"fields": {"Mobile": "98765 43210", "Date of birth": "14/02/1999",
                               "Free cancellation": "enabled", "Stay category": "Design"}}, o)["passed"]
    assert P.check({"fields": {"Design": "true"}}, o)["passed"]  # a dropdown option chosen by name
    assert not P.check({"fields": {"Mobile": "9876543211"}}, o)["passed"]
    assert not P.check({"fields": {"Free cancellation": "false"}}, o)["passed"]


def test_sensitive_values_are_masked_in_field_values():
    actions = [{"node": 1, "kind": "fill", "label": "Password", "value": "[masked]", "sensitive": "password"}]
    assert P.field_values(None, obs(actions=actions)) == {"Password": "[masked]"}


def test_discriminative_drops_checks_already_true():
    o = obs(url="https://en.wikipedia.org/wiki/Main_Page", title="Wikipedia")
    pred = {"url_contains": "wikipedia.org", "title_contains": "Gödel"}
    assert P.discriminative(pred, o) == {"title_contains": "Gödel"}
    assert P.discriminative({"url_contains": "wikipedia.org"}, o) == {}


def test_merge_and_items_roundtrip():
    merged = P.merge({"text_visible": ["A"], "url_contains": "/x"}, {"text_visible": ["B"], "url_contains": "/y"})
    assert merged["text_visible"] == ["A", "B"] and merged["url_contains"] == "/y"
    assert P.from_items(P.items(merged)) == merged


@pytest.mark.parametrize("pred,kept", [
    ({"text_visible": ["Casa Flora"]}, {"text_visible": ["Casa Flora"]}),
    ({"text_visible": ["Count: 3"]}, {}),  # guessed page wording
    ({"fields": {"Design": "true"}}, {"fields": {"Design": "true"}}),
    ({"fields": {"Destination": "Lisbon"}}, {"fields": {"Destination": "Lisbon"}}),
    ({"fields": {"Destination": "Porto"}}, {}),
    ({"url_contains": "#casa-flora"}, {"url_contains": "#casa-flora"}),
])
def test_ground_keeps_only_user_grounded_planner_checks(pred, kept):
    goal = "Find Design stays in Lisbon, then open Casa Flora."
    assert P.ground(pred, goal, "https://x.test/", '{"url_contains": "#casa-flora"}') == kept


def test_form_ready_requires_required_fields_and_enabled_dependents():
    action = {"node": 9, "form": 1}
    filled = {"node": 1, "kind": "fill", "form": 1, "value": "x", "field": {"required": True}}
    empty = {"node": 2, "kind": "fill", "form": 1, "value": "", "field": {"required": True}}
    assert P.form_ready(obs(actions=[filled]), action)
    assert not P.form_ready(obs(actions=[filled, empty]), action)
    o = obs(actions=[filled])
    o["disabled_fields"] = [{"node": 3, "form": 1, "field": {"required": True}}]
    assert not P.form_ready(o, action)
