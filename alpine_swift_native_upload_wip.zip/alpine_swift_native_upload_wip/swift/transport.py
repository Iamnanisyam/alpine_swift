"""Direct CDP transport for the shared Cloak browser. No browser bootstrap backends."""

from __future__ import annotations

import itertools
import json
import queue
import threading
import urllib.request
from dataclasses import dataclass
from typing import Any, Callable, Optional, Protocol


class CDPError(RuntimeError):
    """A CDP error reply or a lost connection. No action can be assumed to have happened."""


class TransportLost(CDPError):
    """The connection went away; capture or connect again and re-check state."""


@dataclass(frozen=True)
class TabRef:
    target_id: str
    session_id: str
    context_id: Optional[str] = None


class CDP(Protocol):
    def call(self, method: str, params: Optional[dict] = None, session_id: Optional[str] = None,
             timeout: float = 5.0) -> dict: ...

    def new_tab(self, url: str = "about:blank", context_id: Optional[str] = None) -> TabRef: ...

    def close_tab(self, tab: TabRef) -> None: ...

    def attach(self, target_id: str) -> str: ...

    def events(self) -> list[dict]: ...


def is_headless_version(product: str, user_agent: str) -> bool:
    return "HeadlessChrome" in str(product) or "HeadlessChrome" in str(user_agent)


class _TabMixin:
    """Tab helpers shared by all transports, built on ``call``."""

    _owned_sessions: set

    def attach(self, target_id: str) -> str:
        sid = self.call("Target.attachToTarget", {"targetId": target_id, "flatten": True})["sessionId"]
        self._owned_sessions.add(sid)
        return sid

    def detach(self, session_id: str) -> None:
        if session_id in self._owned_sessions:
            self._owned_sessions.discard(session_id)
            try:
                self.call("Target.detachFromTarget", {"sessionId": session_id})
            except CDPError:
                pass

    def _headless(self) -> bool:
        """Whether the shared Chrome is headless; cached per transport. Chrome 156's new headless mode reports the
        product as "Chrome/..."; only its user agent says "HeadlessChrome" (verified)."""
        cached = getattr(self, "_is_headless", None)
        if cached is None:
            try:
                version = self.call("Browser.getVersion")
                cached = is_headless_version(version.get("product", ""), version.get("userAgent", ""))
            except Exception:
                cached = True
            self._is_headless = cached
        return cached

    def new_tab(self, url: str = "about:blank", context_id: Optional[str] = None) -> TabRef:
        # Tasks share the persistent default context and open tabs, never new windows.
        params: dict[str, Any] = {"url": url, "background": not self._headless(), "newWindow": False}
        if context_id:
            raise CDPError("Cloak-only mode requires the shared default profile")
        target = self.call("Target.createTarget", params)["targetId"]
        return TabRef(target, self.attach(target), context_id)

    def close_tab(self, tab: TabRef) -> None:
        self.detach(tab.session_id)
        try:
            self.call("Target.closeTarget", {"targetId": tab.target_id})
        except CDPError:
            pass

    def detach_all(self) -> None:
        for sid in list(self._owned_sessions):
            self.detach(sid)


class DirectCDP(_TabMixin):
    """A thread-safe CDP client over one browser WebSocket (flattened sessions)."""

    def __init__(self, cdp_url: str, connect_timeout: float = 10.0):
        from websockets.sync.client import connect

        self.cdp_url = cdp_url.rstrip("/")
        ws_url = self.cdp_url
        if ws_url.startswith("http"):
            with urllib.request.urlopen(f"{ws_url}/json/version", timeout=connect_timeout) as r:
                ws_url = json.loads(r.read())["webSocketDebuggerUrl"]
        self._ws = connect(ws_url, max_size=None, open_timeout=connect_timeout)
        self._ids = itertools.count(1)
        self._pending: dict[int, queue.Queue] = {}
        self._lock = threading.Lock()
        self._events: "queue.Queue[dict]" = queue.Queue(maxsize=10000)
        self._listeners: list[Callable[[dict], None]] = []
        self._closed = False
        self._owned_sessions = set()
        self._reader = threading.Thread(target=self._read, name="swift-cdp-reader", daemon=True)
        self._reader.start()

    def _read(self) -> None:
        try:
            for raw in self._ws:
                msg = json.loads(raw)
                if "id" in msg:
                    with self._lock:
                        q = self._pending.pop(msg["id"], None)
                    if q:
                        q.put(msg)
                else:
                    for listener in list(self._listeners):
                        try:
                            listener(msg)
                        except Exception:
                            pass
                    try:
                        self._events.put_nowait(msg)
                    except queue.Full:
                        try:
                            self._events.get_nowait()
                        except queue.Empty:
                            pass
                        self._events.put_nowait(msg)
        except Exception:
            pass
        finally:
            self._closed = True
            with self._lock:
                pending, self._pending = self._pending, {}
            for q in pending.values():
                q.put({"error": {"message": "connection closed"}, "_lost": True})

    def add_listener(self, fn: Callable[[dict], None]) -> None:
        self._listeners.append(fn)

    def remove_listener(self, fn: Callable[[dict], None]) -> None:
        if fn in self._listeners:
            self._listeners.remove(fn)

    def call(self, method: str, params: Optional[dict] = None, session_id: Optional[str] = None,
             timeout: float = 5.0) -> dict:
        if self._closed:
            raise TransportLost("CDP connection is closed")
        msg_id = next(self._ids)
        q: queue.Queue = queue.Queue(maxsize=1)
        with self._lock:
            self._pending[msg_id] = q
        msg: dict[str, Any] = {"id": msg_id, "method": method, "params": params or {}}
        if session_id:
            msg["sessionId"] = session_id
        try:
            self._ws.send(json.dumps(msg))
        except Exception as exc:
            with self._lock:
                self._pending.pop(msg_id, None)
            raise TransportLost(f"CDP send failed: {exc}") from None
        try:
            reply = q.get(timeout=timeout)
        except queue.Empty:
            with self._lock:
                self._pending.pop(msg_id, None)
            raise TimeoutError(f"CDP {method} got no reply within {timeout}s") from None
        if reply.get("_lost"):
            raise TransportLost("CDP connection closed during the call")
        if "error" in reply:
            raise CDPError(f"{method}: {reply['error'].get('message')}")
        return reply.get("result", {})

    def send(self, method: str, params: Optional[dict] = None, session_id: Optional[str] = None) -> None:
        """Fire and forget: safe to call from an event listener (which runs on the reader thread, where a
        blocking ``call`` would wait for a reply only that same thread can deliver)."""
        if self._closed:
            return
        msg: dict[str, Any] = {"id": next(self._ids), "method": method, "params": params or {}}
        if session_id:
            msg["sessionId"] = session_id
        try:
            self._ws.send(json.dumps(msg))
        except Exception:
            pass

    def events(self) -> list[dict]:
        out = []
        while True:
            try:
                out.append(self._events.get_nowait())
            except queue.Empty:
                return out

    def close(self) -> None:
        self.detach_all()
        self._closed = True
        try:
            self._ws.close()
        except Exception:
            pass


class HarnessCDP(DirectCDP):
    """Compatibility name for callers; always direct CDP, never starts a daemon."""

    def __init__(self, cdp_url: Optional[str] = None, prefer_harness: bool = False):
        from .cloak import require_session
        super().__init__(require_session(cdp_url))
