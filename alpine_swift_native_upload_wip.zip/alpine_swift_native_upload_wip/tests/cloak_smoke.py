"""Opt-in local fixture smoke test against an already running, configured Cloak service.

Run: python tests/cloak_smoke.py
Does not launch another browser, call an LLM, or contact an external site. It opens
one about:blank tab and sets fixture HTML via CDP, then closes only that tab.
This checks browser mechanics; verify the proxy exit IP separately before real work.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main():
    from swift.chrome import _load_settings_file
    from swift.cloak import require_session
    from swift.page import Page
    from swift.transport import HarnessCDP

    _load_settings_file()
    cdp = HarnessCDP(require_session())
    tab = cdp.new_tab()
    try:
        page = Page(cdp, tab)
        tree = page.call('Page.getFrameTree')
        page.call('Page.setDocumentContent', frameId=tree['frameTree']['frame']['id'], html='''
            <label>Name<input id="name"></label>
            <label>State<select id="state"><option value="">Choose</option>
            <option value="ap">Andhra Pradesh</option></select></label>
            <button onclick="document.querySelector('#result').textContent=document.querySelector('#name').value">Save</button>
            <output id="result"></output>''')
        obs = page.observe()
        field = next(a for a in obs['actions'] if a['kind'] == 'fill' and a['label'] == 'Name')
        assert page.fill_node(field['node'], 'Cloak smoke')
        assert page.read_value(field['node']) == 'Cloak smoke'
        obs = page.observe()
        button = next(a for a in obs['actions'] if a['kind'] == 'click' and a['label'] == 'Save')
        page.act(button, obs)
        assert page.evaluate("document.querySelector('#result').textContent") == 'Cloak smoke'
        from swift.dropdowns import choose_native
        obs = page.observe()
        select = next(a for a in obs['actions'] if a['kind'] == 'select')
        assert choose_native(page, select['node'], 'AP')['ok']
        print('PASS: shared session, snapshot, input, curved click and native selection')
    finally:
        cdp.close_tab(tab)
        cdp.close()


if __name__ == '__main__':
    main()
