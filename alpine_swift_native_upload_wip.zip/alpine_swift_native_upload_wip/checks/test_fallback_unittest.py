import sys
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from swift import config, jev
from swift.decision_fallback import DecisionFallback, FallbackError
from swift.upload_classification import map_files, UploadMappingError
from swift.loop import FastLoop, LoopContext, Subgoal, Control

OBS={'url':'https://example.test','title':'Example','text':'Select a result','tab_id':'T1','marker':['x'],
     'actions':[{'id':'a1','node':1,'kind':'click','role':'link','label':'Result'},
                {'id':'a2','node':2,'kind':'fill','role':'textbox','label':'Query'},
                {'id':'wait','kind':'wait','label':'Wait'}]}

class Model:
    models=[{'model':'mercury-3','base_url':'https://api.inceptionlabs.ai/v1','key_env':'INCEPTION_API_KEY'}]
    def __init__(self,response):self.response=response;self.calls=[]
    def _call_openai(self,model,system,user,purpose):
        self.calls.append((model,system,user,purpose));return self.response

def answer(action='a1',risk='read_only',confidence=.9,blocker='none'):
    return {'action_id':action,'risk':risk,'confidence':confidence,'blocker':blocker}

class FallbackTests(unittest.TestCase):
    def tearDown(self):config.configure({})
    def test_direct_fallback_selects_only_observed_id(self):
        model=Model(answer()); d=DecisionFallback(model).decide(OBS,'open result',[])
        self.assertEqual(d['action']['id'],'a1');self.assertEqual(d['source'],'llm_fallback')
        self.assertEqual(model.calls[0][3],'decision_fallback')
        self.assertEqual(model.calls[0][0]['model'],'mercury-3')
        self.assertIsNone(d['agree'])
    def test_disabled_fallback_does_not_call_model(self):
        config.configure({'decision_fallback': {'enabled': False}})
        model=Model(answer())
        with self.assertRaises(FallbackError):DecisionFallback(model).decide(OBS,'goal',[])
        self.assertEqual(model.calls,[])

    def test_invented_target_and_malformed_confidence_rejected(self):
        for result in (answer('unknown'),answer(confidence=True),answer(blocker='captcha')):
            with self.assertRaises(FallbackError):DecisionFallback(Model(result)).decide(OBS,'goal',[])
    def test_no_fallback_on_successful_jev(self):
        class Page:
            def observe(self):return OBS
            def fresh(self,*a):return True
        class FB:
            def decide(self,*a):raise AssertionError('fallback should not be called')
        ctx=LoopContext(Page(),None,'goal',None,control=Control(),max_steps=1,decision_fallback=FB())
        fast=FastLoop(ctx,Subgoal('goal',{},'read_only'));fast.verify=lambda _:{'passed':False}
        fast.execute=lambda *a:{'executed':'a1'};fast.after=lambda *a:OBS
        d=DecisionFallback(Model(answer())).decide(OBS,'goal',[]);d.pop('source')
        with patch('swift.loop.jevmod.decide',return_value=d):result=fast.run()
        self.assertEqual(result.status,'budget')
    def test_jev_unavailable_calls_fallback_once(self):
        class Page:
            def observe(self):return OBS
            def fresh(self,*a):return True
        model=Model(answer());ctx=LoopContext(Page(),None,'goal',None,control=Control(),max_steps=1,
                                               decision_fallback=DecisionFallback(model))
        fast=FastLoop(ctx,Subgoal('goal',{},'read_only'));fast.verify=lambda _:{'passed':False}
        acted=[];fast.execute=lambda d,o:acted.append(d['choice']) or {'executed':'a1'};fast.after=lambda *a:OBS
        with patch('swift.loop.jevmod.decide',side_effect=jev.JevUnavailable('offline')):result=fast.run()
        self.assertEqual(result.status,'budget');self.assertEqual(acted,['a1']);self.assertEqual(len(model.calls),1)
    def test_low_confidence_jev_uses_fallback(self):
        class Page:
            def observe(self):return OBS
            def fresh(self,*a):return True
        model=Model(answer());ctx=LoopContext(Page(),None,'goal',None,control=Control(),max_steps=1,
                                               decision_fallback=DecisionFallback(model))
        fast=FastLoop(ctx,Subgoal('goal',{},'read_only'));fast.verify=lambda _:{'passed':False}
        acted=[];fast.execute=lambda d,o:acted.append(d['choice']) or {'executed':'a1'};fast.after=lambda *a:OBS
        d=DecisionFallback(Model(answer(confidence=.1))).decide(OBS,'goal',[]);d.pop('source')
        with patch('swift.loop.jevmod.decide',return_value=d),patch('swift.loop.jevmod.shuffled_agrees',return_value=False):result=fast.run()
        self.assertEqual(result.status,'budget');self.assertEqual(acted,['a1']);self.assertEqual(len(model.calls),1)
    def test_fallback_nonpayment_action_can_proceed_after_explicit_checks(self):
        ctx=LoopContext(object(),None,'goal',None,control=Control());fast=FastLoop(ctx,Subgoal('goal',{'title_contains':'done'},'reversible'))
        obs={'actions':[{'id':'x','node':4,'kind':'click','label':'Submit','role':'button'}]}
        d=DecisionFallback(Model(answer('x','irreversible'))).decide(obs,'goal',[])
        with patch('swift.loop.predicates.form_ready',return_value=True):
            self.assertTrue(fast._gate(d,obs)[0])

    def test_fallback_irreversible_action_does_not_auto_approve(self):
        class P: pass
        ctx=LoopContext(P(),None,'goal',None,control=Control());fast=FastLoop(ctx,Subgoal('goal',{},'reversible'))
        obs={'actions':[{'id':'x','node':4,'kind':'click','label':'Submit','role':'button'}]}
        d=DecisionFallback(Model(answer('x','irreversible'))).decide(obs,'goal',[])
        ok,_=fast._gate(d,obs);self.assertFalse(ok);self.assertEqual(d['gate_status'],'needs_review')

class ClassificationTests(unittest.TestCase):
    fields=[{'id':'passport','label':'Passport scan'},{'id':'photo','label':'Profile photo'}]
    paths=['/private/passport.pdf','/private/photo.jpg']
    class Jev:
        def __init__(self,conf=.9):self.calls=[];self.conf=conf
        def ask(self,state,questions):
            self.calls.append((state,questions))
            return {'answers':{f'q{i}':{'choice':f'f{i+1}','confidence':self.conf,
                    'probabilities':{k:float(k==f'f{i+1}') for k in q['criteria']}} for i,q in enumerate(questions.values())}}
    def test_two_mappings_in_one_jev_request(self):
        client=self.Jev();mapped=map_files(self.fields,self.paths,client)
        self.assertEqual(mapped,{'passport':self.paths[0],'photo':self.paths[1]})
        self.assertEqual(len(client.calls),1);self.assertEqual(len(client.calls[0][1]),2)
        self.assertNotIn('/private/',repr(client.calls))
    def test_jev_failure_uses_one_direct_fallback(self):
        class Down:
            def ask(self,*a):raise jev.JevUnavailable('offline')
        model=Model({'mapping':{'passport':'f1','photo':'f2'}})
        mapped=map_files(self.fields,self.paths,Down(),DecisionFallback(model))
        self.assertEqual(mapped['passport'],self.paths[0]);self.assertEqual(len(model.calls),1)

    def test_uncertain_mapping_uses_one_direct_fallback(self):
        model=Model({'mapping':{'passport':'f1','photo':'f2'}});fb=DecisionFallback(model)
        mapped=map_files(self.fields,self.paths,self.Jev(conf=.2),fb)
        self.assertEqual(mapped['photo'],self.paths[1]);self.assertEqual(len(model.calls),1)
    def test_duplicate_high_confidence_jev_mapping_falls_back_once(self):
        class Duplicate:
            def ask(self, state, questions):
                return {'answers': {key: {'choice': 'f1', 'confidence': .95,
                        'probabilities': {choice: float(choice == 'f1') for choice in q['criteria']}}
                        for key, q in questions.items()}}
        model = Model({'mapping': {'passport': 'f1', 'photo': 'f2'}})
        self.assertEqual(map_files(self.fields, self.paths, Duplicate(), DecisionFallback(model)),
                         {'passport': self.paths[0], 'photo': self.paths[1]})
        self.assertEqual(len(model.calls), 1)
    def test_invalid_or_duplicate_mapping_is_rejected(self):
        model=Model({'mapping':{'passport':'f1','photo':'f1'}})
        with self.assertRaises(UploadMappingError):map_files(self.fields,self.paths,self.Jev(conf=.1),DecisionFallback(model))

if __name__=='__main__':unittest.main()
