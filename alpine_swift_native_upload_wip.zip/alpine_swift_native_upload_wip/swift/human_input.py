"""Attach to the recorded browser and apply Cloak's documented Playwright human patch.

Unlike the standalone prototype, Hermes and the browser owner are separate processes.
This adapter attaches to the existing browser only; it never launches a context or browser.
"""
from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path


@contextmanager
def patched_page(target_id: str):
    from .cloak import require_session
    from playwright.sync_api import sync_playwright
    from cloakbrowser.human import patch_page, resolve_config

    endpoint = require_session()
    pw = sync_playwright().start()
    try:
        browser = pw.chromium.connect_over_cdp(endpoint)
        matches = []
        # Resolve by CDP target identity, never by URL or tab order.
        for context in browser.contexts:
            for page in context.pages:
                session = context.new_cdp_session(page)
                try:
                    info = session.send('Target.getTargetInfo').get('targetInfo', {})
                finally:
                    session.detach()
                if info.get('targetId') == target_id:
                    matches.append(page)
        if len(matches) != 1:
            raise RuntimeError('The owned browser tab could not be uniquely resolved')
        page = matches[0]
        patch_page(page, resolve_config('default'))
        # Cloak documents _original as the unpatched escape hatch. Fail closed if
        # the installed version does not expose it; never silently use raw input.
        if not hasattr(page, '_original'):
            raise RuntimeError('Cloak humanizer could not be verified on the attached page')
        yield page
    finally:
        # Stop only the Playwright client connection; the owning service keeps the browser alive.
        pw.stop()


def perform(target_id: str, steps: list[tuple], *, label: str = ""):
    with patched_page(target_id) as page:
        # The label is display-only and never includes typed text.
        try:
            script = Path(__file__).with_name('cursor.js').read_text()
            for frame in page.frames:
                try:
                    frame.evaluate(script)
                except Exception:
                    pass
        except Exception:
            pass
        # Text values are never shown in the badge. The caller provides a short
        # sanitized action label when available.
        if label:
            try:
                page.evaluate('(v) => window.__swiftCursor?.(v, "Working")', label[:24])
            except Exception:
                pass
        for step in steps:
            op, *args = step
            if op == 'click': page.mouse.click(*args)
            elif op == 'move': page.mouse.move(*args)
            elif op == 'wheel': page.mouse.wheel(*args)
            elif op == 'press': page.keyboard.press(*args)
            elif op == 'type': page.keyboard.type(*args)
            elif op == 'select': page.locator(args[0]).select_option(value=args[1])
            elif op == 'fill_bound':
                from .vaultfill import origin_of
                if origin_of(page.url) != args[2]:
                    raise RuntimeError('Page origin changed before fill')
                page.locator(args[0]).fill(args[1])
            elif op == 'fill': page.locator(args[0]).fill(args[1])
            else: raise ValueError('Unsupported humanized input operation')
            try:
                page.evaluate('(v) => window.__swiftCursor?.(v, "OK")', (label or op.capitalize())[:24])
            except Exception:
                pass
