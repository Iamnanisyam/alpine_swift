"""Offline contract checks; these do not replace an actual headed browser test."""
import json
import os
import stat
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from swift import config, cloak, platform
from swift.__main__ import setup
from swift.controller import Controller
from swift.loop import FastLoop, LoopContext, Subgoal, Control
from swift import human_input, jev


class SetupTests(unittest.TestCase):
    def test_setup_keeps_existing_settings_and_stable_seed(self):
        with tempfile.TemporaryDirectory() as td:
            home=Path(td); profile=home/'profile'; env=home/'.env'; env.write_text('UNRELATED=keep\n')
            config.configure({'chrome':{'profile_dir':str(profile)}})
            with patch.dict(os.environ, {'HERMES_HOME':td}), patch('swift.chrome._load_settings_file'), \
                 patch('swift.__main__._value', side_effect=['mercury-key','jev-key','']):
                setup()
            seed=(profile/'swift-fingerprint').read_text()
            self.assertIn('UNRELATED=keep',env.read_text())
            self.assertEqual(stat.S_IMODE(env.stat().st_mode),0o600)
            self.assertEqual(stat.S_IMODE((profile/'swift-fingerprint').stat().st_mode),0o600)
            with patch.dict(os.environ, {'HERMES_HOME':td}), patch('swift.chrome._load_settings_file'), \
                 patch('swift.__main__._value', side_effect=['m2','j2','']):
                setup()
            self.assertEqual(seed,(profile/'swift-fingerprint').read_text())
            self.assertEqual(env.read_text().count('INCEPTION_API_KEY='),1)

    def test_missing_key_writes_nothing(self):
        with tempfile.TemporaryDirectory() as td:
            config.configure({'chrome':{'profile_dir':str(Path(td)/'profile')}})
            with patch.dict(os.environ, {'HERMES_HOME':td}), patch('swift.chrome._load_settings_file'), \
                 patch('swift.__main__._value', side_effect=['','jev','']):
                with self.assertRaises(ValueError): setup()
            self.assertFalse((Path(td)/'.env').exists())

    def test_launcher_env_parses_without_shell_expansion(self):
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'.env').write_text('CLOAK_PROXY_URL="http://user:pa$word@proxy.test:8080"\n')
            with patch.dict(os.environ, {'HERMES_HOME':td}, clear=True):
                cloak._load_launcher_env()
                self.assertEqual(os.environ['CLOAK_PROXY_URL'],'http://user:pa$word@proxy.test:8080')

    def test_optional_proxy_and_forced_headed(self):
        with patch.object(platform,'is_root',return_value=False), patch.object(platform,'desktop_session',return_value='x11'), \
             patch.object(cloak,'secret',return_value=''):
            opts=cloak.launch_options()
        self.assertFalse(opts['headless']); self.assertTrue(opts['humanize']); self.assertNotIn('proxy',opts)

class DecisionTests(unittest.TestCase):
    def test_planner_review_tiebreak_never_call_text_model(self):
        controller=Controller.__new__(Controller)
        class FailText:
            def plan(self,*a,**k): raise AssertionError('Must not call text model')
        controller.textmodel=FailText()
        sub=controller.plan('goal','https://example.test',{'title_contains':'done'})[0]
        self.assertEqual(sub.description,'goal'); self.assertIn('title_contains',sub.success)
        self.assertFalse(controller.review('goal',sub,{},{} )['approve'])
        self.assertIsNone(controller.tiebreak('goal',sub,{}, {}, []))

    def test_challenge_resumes_on_same_page_after_change(self):
        class Trace:
            def log(self,*a,**k): pass
        class Page:
            def __init__(self): self.n=0
            def observe(self): self.n+=1; return {'marker':['changed'], 'tab_id':'same'}
            def challenge_visible(self): return False
        page=Page(); control=Control()
        loop=FastLoop(LoopContext(page=page,jev=None,goal='x',trace=Trace(),control=control),Subgoal('x',{},'reversible'))
        with patch('swift.loop.time.sleep'):
            resumed=loop.wait_for_challenge({'marker':['before'],'tab_id':'same'},'otp')
        self.assertEqual(resumed['tab_id'],'same');self.assertEqual(page.n,3)

    def test_jev_builds_operation_and_targets_together(self):
        obs={'actions':[{'id':'a','kind':'click','node':1,'label':'Go','role':'button'},
                        {'id':'b','kind':'fill','node':2,'label':'Query','role':'textbox'}]}
        _, targets, _, operations, questions = jev.build_questions(obs,'goal','goal',checks=False)
        self.assertIn('CLICK',operations);self.assertIn('TYPE_TEXT',operations)
        self.assertIn('click_target',questions);self.assertIn('type_text_target',questions)
        self.assertEqual(targets['CLICK']['1']['id'],'a')

class HumanTests(unittest.TestCase):
    def test_attaches_existing_target_and_patches_before_actions(self):
        events=[]
        class Mouse:
            def click(self,*a): events.append(('click',a))
            def move(self,*a): events.append(('move',a))
            def wheel(self,*a): events.append(('wheel',a))
        class Keyboard:
            def press(self,*a): events.append(('press',a))
            def type(self,*a): events.append(('type',a))
        class Locator:
            def select_option(self,**kw): events.append(('select',kw))
        class Page:
            mouse=Mouse();keyboard=Keyboard()
            def evaluate(self,*a): pass
            def locator(self,selector): events.append(('selector',selector));return Locator()
        page=Page()
        class Session:
            def send(self,*a): return {'targetInfo':{'targetId':'target'}}
            def detach(self): events.append(('detach',))
        class Context:
            pages=[page]
            def new_cdp_session(self,p): return Session()
        class Chromium:
            def connect_over_cdp(self,url): events.append(('attach',url));return types.SimpleNamespace(contexts=[Context()])
        class PW:
            chromium=Chromium()
            def stop(self): events.append(('client-stop',))
        fakepw=types.ModuleType('playwright.sync_api');fakepw.sync_playwright=lambda:types.SimpleNamespace(start=lambda:PW())
        fakehuman=types.ModuleType('cloakbrowser.human')
        def patch_page(p,cfg): events.append(('patch',cfg)); p._original=object()
        fakehuman.patch_page=patch_page;fakehuman.resolve_config=lambda x:x
        modules={'playwright':types.ModuleType('playwright'),'playwright.sync_api':fakepw,
                 'cloakbrowser':types.ModuleType('cloakbrowser'),'cloakbrowser.human':fakehuman}
        with patch.dict(sys.modules,modules), patch('swift.cloak.require_session',return_value='http://127.0.0.1:9242'):
            human_input.perform('target',[('click',1,2),('press','Enter'),('type','x'),('move',3,4),('wheel',0,5),('select','[data-safe]','v')])
        self.assertLess(events.index(('patch','default')),events.index(('click',(1,2))))
        self.assertIn(('select',{'value':'v'}),events);self.assertEqual(events[-1],('client-stop',))
        self.assertFalse(any(e[0]=='launch' for e in events))

    def test_refuses_when_human_patch_not_observable(self):
        class Page: pass
        class Session:
            def send(self,*a):return {'targetInfo':{'targetId':'target'}}
            def detach(self):pass
        class Context:
            pages=[Page()]
            def new_cdp_session(self,p):return Session()
        class PW:
            chromium=types.SimpleNamespace(connect_over_cdp=lambda _:types.SimpleNamespace(contexts=[Context()]))
            def stop(self):pass
        fakepw=types.ModuleType('playwright.sync_api');fakepw.sync_playwright=lambda:types.SimpleNamespace(start=lambda:PW())
        fakehuman=types.ModuleType('cloakbrowser.human');fakehuman.patch_page=lambda *a:None;fakehuman.resolve_config=lambda x:x
        modules={'playwright':types.ModuleType('playwright'),'playwright.sync_api':fakepw,
                 'cloakbrowser':types.ModuleType('cloakbrowser'),'cloakbrowser.human':fakehuman}
        with patch.dict(sys.modules,modules),patch('swift.cloak.require_session',return_value='http://127.0.0.1:9242'):
            with self.assertRaisesRegex(RuntimeError,'could not be verified'):human_input.perform('target',[('click',1,2)])

if __name__=='__main__':unittest.main()
