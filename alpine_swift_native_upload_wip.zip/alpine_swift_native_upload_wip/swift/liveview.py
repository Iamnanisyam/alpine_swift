"""Live view: watch running tasks, see each decision, pause / step / resume / stop / take over.

Served on 127.0.0.1 only (reach it through an SSH tunnel), with a per-process token in the URL and a
Host/Origin check against DNS rebinding. Frames come from CDP ``Page.startScreencast`` on a separate
CDP connection to the same Chrome, run only while a viewer is connected, and are never stored.
Take-over input is sent only while the task is in take-over mode; the agent waits until hand-back.
"""

from __future__ import annotations

import asyncio
import base64
import json
import secrets
import threading
from http import HTTPStatus
from pathlib import Path
from typing import Optional

from . import redact
from .transport import CDPError, DirectCDP

STATIC = Path(__file__).with_name("liveview.html")


class LiveView:
    def __init__(self, cdp_url: str, port: int = 8766, host: str = "127.0.0.1"):
        if host not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("The live view binds to loopback only.")
        self.cdp_url, self.port, self.host = cdp_url, port, host
        self.token = secrets.token_urlsafe(16)
        self.tasks: dict[str, dict] = {}
        self.viewers: set = set()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._cdp: Optional[DirectCDP] = None
        self._sessions: dict[str, str] = {}  # target_id -> our session
        self._streaming: set[str] = set()
        self._lock = threading.Lock()
        self._conn_lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()

    # ------------------------------------------------------------ lifecycle

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}/?token={self.token}"

    def start(self) -> "LiveView":
        self._thread = threading.Thread(target=self._serve, name="swift-liveview", daemon=True)
        self._thread.start()
        self._ready.wait(10)
        return self

    def _serve(self) -> None:
        from websockets.asyncio.server import serve

        async def main():
            self._loop = asyncio.get_running_loop()
            async with serve(self._ws_handler, self.host, self.port, process_request=self._http,
                             max_size=2 ** 20):
                self._ready.set()
                await asyncio.Future()

        try:
            asyncio.run(main())
        except Exception:
            self._ready.set()

    def _cdp_conn(self) -> DirectCDP:
        # One connection for all screencasts; streams start from several threads at once.
        with self._conn_lock:
            if self._cdp is None or self._cdp._closed:
                self._cdp = DirectCDP(self.cdp_url)
                self._cdp.add_listener(self._on_cdp)
                self._sessions.clear()
                self._streaming.clear()
            return self._cdp

    # ------------------------------------------------------------ task registry (called by controller)

    def register(self, task_id: str, target_id: str, control, trace, goal: str) -> str:
        with self._lock:
            self.tasks[task_id] = {"task_id": task_id, "goal": goal[:300], "tabs": [target_id], "active": target_id,
                                   "control": control, "status": "running", "events": [], "last": {}}
        trace.subscribe(self._on_trace)
        self._broadcast({"type": "tasks", "tasks": self.task_list()})
        if self.viewers:
            self._submit(self._start_stream, task_id)
        return f"{self.url}#task={task_id}"

    def add_tab(self, task_id: str, target_id: str) -> None:
        with self._lock:
            t = self.tasks.get(task_id)
            if t:
                old = t["active"]
                t["tabs"].append(target_id)
                t["active"] = target_id
        if t and self.viewers:
            self._submit(self._stop_stream_target, old)
            self._submit(self._start_stream, task_id)

    def finish(self, task_id: str, verified: bool) -> None:
        with self._lock:
            t = self.tasks.get(task_id)
            if t:
                t["status"] = "verified" if verified else "finished"
                target = t["active"]
        if t:
            self._submit(self._stop_stream_target, target)
            self._broadcast({"type": "tasks", "tasks": self.task_list()})

    def task_list(self) -> list[dict]:
        with self._lock:
            return [{k: v for k, v in t.items() if k not in ("control", "events")} |
                    {"control_state": t["control"].state, "paused": t["control"].paused,
                     "takeover": t["control"].takeover} for t in self.tasks.values()]

    def _on_trace(self, task_id: str, event: dict) -> None:
        event = redact.scrub(event)
        with self._lock:
            t = self.tasks.get(task_id)
            if not t:
                return
            t["events"] = (t["events"] + [event])[-200:]
            if event.get("kind") == "decision":
                t["last"] = event
        self._broadcast({"type": "event", "task": task_id, "event": event})

    # ------------------------------------------------------------ screencast

    def _submit(self, fn, *args) -> None:
        threading.Thread(target=self._safe, args=(fn, *args), daemon=True).start()

    @staticmethod
    def _safe(fn, *args):
        try:
            fn(*args)
        except Exception:
            pass

    def _session(self, target_id: str) -> str:
        with self._conn_lock:
            cdp = self._cdp_conn()
            if target_id not in self._sessions:
                self._sessions[target_id] = cdp.attach(target_id)
            return self._sessions[target_id]

    def _start_stream(self, task_id: str) -> None:
        with self._conn_lock:
            t = self.tasks.get(task_id)
            if not t or t["status"] != "running":
                return
            target = t["active"]
            if target in self._streaming:
                return
            sid = self._session(target)
            self._cdp_conn().call("Page.startScreencast", {"format": "jpeg", "quality": 60, "maxWidth": 960,
                                                           "maxHeight": 600, "everyNthFrame": 1}, session_id=sid)
            self._streaming.add(target)

    def _stop_stream_target(self, target_id: str) -> None:
        if target_id in self._streaming and target_id in self._sessions:
            self._streaming.discard(target_id)
            try:
                self._cdp_conn().call("Page.stopScreencast", session_id=self._sessions[target_id])
            except (CDPError, TimeoutError):
                pass

    def _stop_all(self) -> None:
        for target in list(self._streaming):
            self._stop_stream_target(target)

    def _on_cdp(self, msg: dict) -> None:
        if msg.get("method") != "Page.screencastFrame":
            return
        sid, params = msg.get("sessionId"), msg.get("params", {})
        target = next((t for t, s in self._sessions.items() if s == sid), None)
        # This runs on the CDP reader thread: acknowledge without waiting for a reply.
        self._cdp.send("Page.screencastFrameAck", {"sessionId": params.get("sessionId")}, session_id=sid)
        task = next((tid for tid, t in self.tasks.items() if t["active"] == target), None)
        if task:
            # Frames go straight to connected viewers and are never written anywhere.
            self._broadcast({"type": "frame", "task": task, "data": params.get("data"),
                             "meta": {k: params.get("metadata", {}).get(k) for k in ("deviceWidth", "deviceHeight")}})

    # ------------------------------------------------------------ web

    def _allowed(self, request) -> bool:
        host = request.headers.get("Host", "")
        origin = request.headers.get("Origin")
        ok_hosts = {f"127.0.0.1:{self.port}", f"localhost:{self.port}", f"[::1]:{self.port}"}
        if host not in ok_hosts:
            return False
        if origin and origin.replace("http://", "") not in ok_hosts:
            return False
        return True

    def _http(self, connection, request):
        from websockets.http11 import Response
        from websockets.datastructures import Headers

        if not self._allowed(request):
            return Response(HTTPStatus.FORBIDDEN, "Forbidden", Headers(), b"forbidden\n")
        path, _, query = request.path.partition("?")
        token = dict(p.split("=", 1) for p in query.split("&") if "=" in p).get("token")
        if token != self.token:
            return Response(HTTPStatus.FORBIDDEN, "Forbidden", Headers(), b"missing or wrong token\n")
        if path == "/ws":
            return None  # proceed with the WebSocket handshake
        if path in ("/", "/index.html"):
            body = STATIC.read_bytes()
            return Response(HTTPStatus.OK, "OK", Headers({"Content-Type": "text/html; charset=utf-8",
                                                          "Cache-Control": "no-store",
                                                          "Content-Security-Policy": "default-src 'self'; img-src data:; "
                                                          "script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                                                          "connect-src ws://127.0.0.1:* ws://localhost:*"}), body)
        return Response(HTTPStatus.NOT_FOUND, "Not Found", Headers(), b"not found\n")

    def _broadcast(self, msg: dict) -> None:
        if not self.viewers or self._loop is None:
            return
        data = json.dumps(msg, default=str)
        for ws in list(self.viewers):
            asyncio.run_coroutine_threadsafe(self._send(ws, data), self._loop)

    @staticmethod
    async def _send(ws, data):
        try:
            await ws.send(data)
        except Exception:
            pass

    async def _ws_handler(self, ws):
        self.viewers.add(ws)
        await ws.send(json.dumps({"type": "tasks", "tasks": self.task_list()}, default=str))
        for tid, t in list(self.tasks.items()):
            await ws.send(json.dumps({"type": "history", "task": tid, "events": t["events"][-100:]}, default=str))
            if t["status"] == "running":
                self._submit(self._start_stream, tid)
        try:
            async for raw in ws:
                try:
                    await asyncio.get_running_loop().run_in_executor(None, self.command, json.loads(raw))
                except Exception as exc:
                    await ws.send(json.dumps({"type": "error", "error": str(exc)[:200]}))
        finally:
            self.viewers.discard(ws)
            if not self.viewers:
                self._submit(self._stop_all)  # watching costs nothing when nobody watches

    # ------------------------------------------------------------ commands

    def command(self, msg: dict) -> dict:
        task = self.tasks.get(str(msg.get("task", "")))
        if not task:
            raise ValueError("unknown task")
        cmd = msg.get("cmd")
        control = task["control"]
        if cmd in ("pause", "step", "resume", "stop", "takeover", "handback"):
            control.set(cmd)
            self._broadcast({"type": "tasks", "tasks": self.task_list()})
            return {"ok": True}
        if cmd in ("click", "type", "key"):
            if not control.takeover:
                raise PermissionError("Take over the task before sending input.")
            from .human_input import perform
            if cmd == 'click':
                steps = [('click', float(msg['x']), float(msg['y']))]
            elif cmd == 'type':
                steps = [('type', str(msg.get('text', ''))[:500])]
            else:
                key = str(msg.get('key', ''))
                if key not in ('Enter', 'Tab', 'Backspace', 'Escape'):
                    raise ValueError('Unsupported key')
                steps = [('press', key)]
            perform(task['active'], steps)
            return {'ok': True, 'target': task['active']}
        raise ValueError("unknown command")


def frame_to_png(data_b64: str) -> bytes:
    return base64.b64decode(data_b64)
