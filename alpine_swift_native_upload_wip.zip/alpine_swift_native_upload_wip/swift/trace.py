"""Per-run trace: timings, decisions, actions. Everything is scrubbed before it is written.

Screenshots are written only when requested and only after sensitive fields are covered
(``Page.cover_sensitive``); live-view frames are never stored.
"""

from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Any, Optional

from . import redact
from .config import data_dir


class Trace:
    def __init__(self, task_id: str, root: Optional[Path] = None):
        self.task_id = task_id
        self.dir = (root or data_dir() / "traces") / task_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.started = time.perf_counter()
        self.events: list[dict] = []
        self.timings: dict[str, float] = {}
        self._lock = threading.Lock()
        self._listeners: list = []
        self._file = open(self.dir / "trace.jsonl", "a", encoding="utf-8")

    def elapsed_ms(self) -> int:
        return round((time.perf_counter() - self.started) * 1000)

    def subscribe(self, fn) -> None:
        self._listeners.append(fn)

    def unsubscribe(self, fn) -> None:
        if fn in self._listeners:
            self._listeners.remove(fn)

    def log(self, event_kind: str, /, **data: Any) -> dict:
        # The event kind is positional-only so a data field called ``kind`` (an action's kind) cannot clash.
        data = {("action_kind" if k == "kind" else k): v for k, v in data.items()}
        event = redact.scrub({"t_ms": self.elapsed_ms(), "kind": event_kind, **data})
        with self._lock:
            self.events.append(event)
            self._file.write(json.dumps(event, default=str) + "\n")
            self._file.flush()
        for fn in list(self._listeners):
            try:
                fn(self.task_id, event)
            except Exception:
                pass
        return event

    def time(self, name: str, ms: float) -> None:
        with self._lock:
            self.timings[name] = round(self.timings.get(name, 0) + ms, 1)

    def screenshot(self, name: str, data_b64: str) -> None:
        import base64

        (self.dir / f"{name}.jpg").write_bytes(base64.b64decode(data_b64))

    def close(self) -> None:
        with self._lock:
            if not self._file.closed:
                (self.dir / "timings.json").write_text(json.dumps(self.timings, indent=1))
                self._file.close()
