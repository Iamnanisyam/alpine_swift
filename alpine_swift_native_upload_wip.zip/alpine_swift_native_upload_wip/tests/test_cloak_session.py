"""Regression coverage for single-session policy; never launches a real browser."""
import json
import os
import sys
import types

import pytest

from conftest import FakeCDP
from swift import chrome, cloak, config
from swift.sessions import TabRegistry
from swift.transport import CDPError, _TabMixin


def recorded_session(tmp_path, monkeypatch):
    config.configure({'chrome': {'profile_dir': str(tmp_path), 'port': 9242}})
    record = {'backend': 'cloakbrowser', 'profile': str(tmp_path), 'service_pid': os.getpid(), 'ws': 'ws://one'}
    (tmp_path / 'swift-cloak.json').write_text(json.dumps(record))
    monkeypatch.setattr(chrome, 'version_info', lambda *a, **k: {'webSocketDebuggerUrl': 'ws://one'})
    return record


def test_attach_requires_exact_recorded_browser(tmp_path, monkeypatch):
    recorded_session(tmp_path, monkeypatch)
    assert cloak.require_session() == 'http://127.0.0.1:9242'
    monkeypatch.setattr(chrome, 'version_info', lambda *a, **k: {'webSocketDebuggerUrl': 'ws://stock-chrome'})
    with pytest.raises(RuntimeError, match='identity changed'):
        cloak.require_session()


def test_missing_service_never_launches(tmp_path, monkeypatch):
    config.configure({'chrome': {'profile_dir': str(tmp_path)}})
    monkeypatch.setattr('subprocess.Popen', lambda *a, **k: pytest.fail('browser launched'))
    with pytest.raises(RuntimeError, match='no Chrome fallback'):
        chrome.ensure_chrome()


def test_endpoint_override_cannot_select_another_browser(tmp_path, monkeypatch):
    recorded_session(tmp_path, monkeypatch)
    with pytest.raises(RuntimeError, match='Only the shared'):
        cloak.require_session('http://127.0.0.1:9222')


def test_stale_service_record_is_rejected(tmp_path, monkeypatch):
    recorded_session(tmp_path, monkeypatch)
    monkeypatch.setattr(chrome, 'pid_alive', lambda pid: False)
    with pytest.raises(RuntimeError, match='unavailable'):
        cloak.require_session()


def test_service_lock_excludes_second_launcher(tmp_path):
    config.configure({'chrome': {'profile_dir': str(tmp_path)}})
    with cloak.file_lock('swift-service.lock', blocking=False):
        with pytest.raises(RuntimeError, match='already running'):
            with cloak.file_lock('swift-service.lock', blocking=False):
                pytest.fail('second owner admitted')


def test_occupied_port_cannot_launch_cloak(tmp_path, monkeypatch):
    config.configure({'chrome': {'profile_dir': str(tmp_path)}})
    monkeypatch.setattr(chrome, 'version_info', lambda *a: {'Browser': 'Chrome'})
    monkeypatch.setitem(sys.modules, 'cloakbrowser', types.SimpleNamespace(
        launch_persistent_context=lambda *a, **k: pytest.fail('second browser launched')))
    with pytest.raises(RuntimeError, match='occupied'):
        cloak.serve()


def test_task_proxy_cannot_split_profile():
    cdp = FakeCDP()
    with pytest.raises(CDPError, match='per-task proxies'):
        TabRegistry(cdp).start('amazon', proxy={'server': 'http://proxy'})
    assert not cdp.methods('Target.createBrowserContext')


def test_transport_opens_tab_in_existing_default_context():
    class Transport(_TabMixin, FakeCDP):
        def __init__(self):
            super().__init__()
            self._owned_sessions = set()
    cdp = Transport()
    cdp.new_tab('https://example.test')
    params = cdp.methods('Target.createTarget')[0][1]
    assert params['newWindow'] is False
    assert 'browserContextId' not in params
    with pytest.raises(CDPError, match='default profile'):
        cdp.new_tab(context_id='isolated')


def test_runtime_never_bootstraps_hermes_browser(monkeypatch):
    from swift.runtime import Runtime
    r = Runtime.__new__(Runtime)
    r.cdp_url = 'http://127.0.0.1:9242'
    r.transport_kind = 'hermes'
    captured = []
    monkeypatch.setattr(cloak, 'require_session', lambda url: url)
    monkeypatch.setattr('swift.runtime.HarnessCDP', lambda *a, **k: captured.append((a, k)))
    r._cdp_for('amazon')
    assert captured == [(('http://127.0.0.1:9242',), {'prefer_harness': False})]


def test_launcher_forces_headed_even_if_config_requests_headless(monkeypatch):
    from swift import platform
    config.configure({'chrome': {'headless': True}})
    monkeypatch.setattr(platform, 'is_root', lambda: False)
    monkeypatch.setattr(platform, 'desktop_session', lambda: True)
    monkeypatch.setattr(cloak, 'secret', lambda name: 'http://127.0.0.1:8080' if name == 'CLOAK_PROXY_URL' else '')
    opts = cloak.launch_options()
    assert opts['headless'] is False
    assert opts['humanize'] is True and opts['geoip'] is True
