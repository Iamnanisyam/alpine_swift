"""Client-side rate budget for the Mercury API, shared by every task in the process.

Inception documents per-minute limits per account (docs.inceptionlabs.ai/get-started/rate-limits): Free 1,000
requests, 1M input and 100k output tokens; Pay As You Go 3,000, 3M and 300k. Measured on the key used here
(2026-10-26): it refused the 101st request inside half a minute ("Rate limit reached: too many requests per
minute") at 4 requests a second, while 2 a second ran for a whole minute without a refusal; so its real limit
is about 100 a minute, a tenth of the documented Free tier. Forty parallel requests reserving 4,000 output tokens
each drew 19 refusals as well. 429 replies carry no Retry-After.

So the budget does not trust the documented numbers alone:

- It counts, over a sliding minute, finished requests at their real usage plus requests in flight at their
  ``max_tokens`` reservation, and refused requests as requests. A call starts only while every count stays under
  the cap; otherwise it waits in line (``mercury.queue_wait_s``) instead of failing.
- On a refusal it **learns** the server's real cap: the requests the server had accepted from us in that minute
  (and, when large, the output reserved in flight), times 0.9, but never below half the cap in force, because a
  minute partly used by someone else on the same key (Hermes's own chat, a restarted session) undercounts; repeated
  refusals converge on the real cap. ``python -m swift.doctor --measure-mercury`` measures it directly. Learned
  caps are saved in the plugin's data directory, so the next session (and ``parallel_tasks: auto``) starts from
  them; after 5 minutes without a refusal they rise 25% toward the documented limits again.
- A refusal also pauses new calls for a second.
"""

from __future__ import annotations

import collections
import itertools
import json
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

# Per-minute limits by tier (docs, 2026-10). "enterprise" is custom: give mercury.limits explicitly.
TIERS = {
    "free": {"requests": 1000, "input_tokens": 1_000_000, "output_tokens": 100_000},
    "payg": {"requests": 3000, "input_tokens": 3_000_000, "output_tokens": 300_000},
}
WINDOW_S = 60.0
LEARN_FACTOR = 0.9
RELAX_AFTER_S, RELAX_STEP = 300.0, 1.25
MIN_LEARNED = {"requests": 10, "input_tokens": 20_000, "output_tokens": 5_000}


class RateBudgetTimeout(TimeoutError):
    """The call could not start within its queue time without exceeding the account's limits."""


def estimate_tokens(text: str) -> int:
    """A cheap upper-ish estimate (about 3.5 characters per token for English and JSON)."""
    return int(len(text) / 3.5) + 16


@dataclass
class Grant:
    gid: int
    input_tokens: int
    output_tokens: int
    started: float


class RateBudget:
    def __init__(self, requests: int, input_tokens: int, output_tokens: int, safety: float = 0.8,
                 clock=time.monotonic, learned: Optional[dict] = None,
                 on_learn: Optional[Callable[[dict], None]] = None):
        self.limits = {"requests": int(requests), "input_tokens": int(input_tokens),
                       "output_tokens": int(output_tokens)}
        self.safety = float(safety)
        self.learned: dict[str, int] = {k: int(v) for k, v in (learned or {}).items() if k in self.limits and v}
        self._on_learn = on_learn
        self._clock = clock
        self._last_429: Optional[float] = None
        self._last_relax = clock()
        self.throttle_log: list[dict] = []
        self._done: collections.deque = collections.deque()  # (t, input, output, accepted)
        self._inflight: dict[int, Grant] = {}
        self._ids = itertools.count(1)
        self._cv = threading.Condition()
        self._pause_until = 0.0
        self.stats = {"granted": 0, "waited": 0, "wait_ms": 0, "throttled": 0, "timeouts": 0,
                      "requests": 0, "input_tokens": 0, "output_tokens": 0, "max_inflight": 0}

    # ------------------------------------------------------------ caps

    def caps(self) -> dict:
        """What a call may use per minute: ``safety`` of the documented limit, or the learned server cap."""
        out = {}
        for k, v in self.limits.items():
            cap = v * self.safety
            if k in self.learned:
                cap = min(cap, self.learned[k])
            out[k] = cap
        return out

    def _relax(self, now: float) -> None:
        quiet_since = self._last_429 if self._last_429 is not None else self._last_relax
        if self.learned and now - max(quiet_since, self._last_relax) >= RELAX_AFTER_S:
            self._last_relax = now
            for k in list(self.learned):
                self.learned[k] = int(self.learned[k] * RELAX_STEP)
                if self.learned[k] >= self.limits[k] * self.safety:
                    del self.learned[k]
            self._save()

    def _save(self) -> None:
        if self._on_learn is not None:
            try:
                self._on_learn(dict(self.learned))
            except Exception:
                pass

    # ------------------------------------------------------------ accounting

    def _expire(self, now: float) -> None:
        while self._done and now - self._done[0][0] >= WINDOW_S:
            self._done.popleft()

    def usage(self) -> dict:
        """Current minute: finished requests at real usage plus in-flight reservations."""
        with self._cv:
            self._expire(self._clock())
            return self._usage()

    def _usage(self) -> dict:
        return {"requests": len(self._done) + len(self._inflight),
                "input_tokens": sum(d[1] for d in self._done) + sum(g.input_tokens for g in self._inflight.values()),
                "output_tokens": sum(d[2] for d in self._done) + sum(g.output_tokens for g in self._inflight.values())}

    def _fits(self, inp: int, out: int) -> bool:
        if not self._inflight and not self._done:
            return True  # an idle budget always admits one call, however large
        used, cap = self._usage(), self.caps()
        return (used["requests"] + 1 <= cap["requests"] and used["input_tokens"] + inp <= cap["input_tokens"]
                and used["output_tokens"] + out <= cap["output_tokens"])

    def _next_free(self, now: float) -> float:
        """Seconds until the oldest finished request leaves the window (in-flight ones end on release)."""
        if self._done:
            return max(0.01, min(1.0, WINDOW_S - (now - self._done[0][0])))
        return 0.25

    # ------------------------------------------------------------ API

    def acquire(self, input_tokens: int, output_tokens: int, timeout: float) -> Grant:
        deadline = self._clock() + max(0.0, timeout)
        started = self._clock()
        waited = False
        with self._cv:
            while True:
                now = self._clock()
                self._expire(now)
                self._relax(now)
                if now >= self._pause_until and self._fits(input_tokens, output_tokens):
                    g = Grant(next(self._ids), int(input_tokens), int(output_tokens), now)
                    self._inflight[g.gid] = g
                    self.stats["granted"] += 1
                    self.stats["max_inflight"] = max(self.stats["max_inflight"], len(self._inflight))
                    if waited:
                        self.stats["waited"] += 1
                        self.stats["wait_ms"] += round((now - started) * 1000)
                    return g
                if now >= deadline:
                    self.stats["timeouts"] += 1
                    raise RateBudgetTimeout("the Mercury rate budget is full; the call could not start in time")
                waited = True
                wake = min(deadline, max(self._pause_until, now + self._next_free(now)))
                self._cv.wait(max(0.01, wake - now))

    def note_external(self, accepted: int) -> None:
        """Requests sent outside the budget on this key just now (the doctor's probe): count them in the window
        so the next calls wait for that minute to clear."""
        with self._cv:
            now = self._clock()
            for _ in range(max(0, int(accepted))):
                self._done.append((now, 0, 0, True))
            self._cv.notify_all()

    def release(self, grant: Grant, *, input_tokens: Optional[int] = None, output_tokens: Optional[int] = None,
                status: int = 200) -> None:
        """Replace the reservation by real usage (when the reply reported it). A 429 teaches the real cap."""
        with self._cv:
            g = self._inflight.pop(grant.gid, None)
            if g is None:
                return
            now = self._clock()
            inp = g.input_tokens if input_tokens is None else int(input_tokens)
            # A refused or failed request still counts as a request; its output reservation is returned.
            out = 0 if status >= 400 else (g.output_tokens if output_tokens is None else int(output_tokens))
            if status == 429:
                used = self._usage()  # what we had counted in this minute when the server refused
                accepted = sum(1 for d in self._done if d[3]) + len(self._inflight)  # requests it had let through
                inflight_out = sum(x.output_tokens for x in self._inflight.values()) + g.output_tokens
                self.throttle_log.append({"used": used, "accepted": accepted, "inflight": len(self._inflight) + 1,
                                          "inflight_output": inflight_out, "caps": self.caps()})
                del self.throttle_log[:-20]
                learned = dict(self.learned)
                cap_now = self.caps()
                # The server's cap is about what it accepted from us this minute. When that was little, the
                # minute was used by someone else on the same key (Hermes's chat, a probe): one refusal then at
                # most halves the cap, and repeated refusals converge on the real one.
                learned["requests"] = max(MIN_LEARNED["requests"], int(accepted * LEARN_FACTOR),
                                          int(cap_now["requests"] * 0.5))
                if inflight_out >= 0.3 * self.limits["output_tokens"]:
                    learned["output_tokens"] = max(MIN_LEARNED["output_tokens"], int(inflight_out * LEARN_FACTOR),
                                                   int(cap_now["output_tokens"] * 0.5))
                for k, v in learned.items():
                    if v < self.caps()[k]:
                        self.learned[k] = v
                self._last_429 = now
                self.stats["throttled"] += 1
                self._pause_until = max(self._pause_until, now + 1.0)
                self._save()
            self._done.append((now, inp, out, status != 429))
            self.stats["requests"] += 1
            self.stats["input_tokens"] += inp
            self.stats["output_tokens"] += out
            self._cv.notify_all()


# ---------------------------------------------------------------- process-wide budgets

_BUDGETS: dict[str, RateBudget] = {}
_LOCK = threading.Lock()


def _store_path() -> Optional[Path]:
    try:
        from .config import data_dir

        return data_dir() / "mercury-limits.json"
    except Exception:
        return None


def _load_learned(key: str) -> dict:
    path = _store_path()
    try:
        return dict((json.loads(path.read_text()) or {}).get(key, {}).get("learned", {})) if path else {}
    except (OSError, ValueError, AttributeError):
        return {}


def _save_learned(key: str, learned: dict) -> None:
    path = _store_path()
    if not path:
        return
    try:
        data = json.loads(path.read_text()) if path.exists() else {}
    except (OSError, ValueError):
        data = {}
    data[key] = {"learned": learned, "updated": time.strftime("%Y-%m-%d %H:%M:%S %Z")}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1))
    tmp.replace(path)


def budget_for(key: str, limits: dict, safety: float = 0.8) -> RateBudget:
    """One budget per account (base URL + key name) for the whole process, seeded with learned caps."""
    with _LOCK:
        b = _BUDGETS.get(key)
        if b is None:
            b = _BUDGETS[key] = RateBudget(limits["requests"], limits["input_tokens"], limits["output_tokens"],
                                           safety, learned=_load_learned(key),
                                           on_learn=lambda learned, key=key: _save_learned(key, learned))
        return b


def limits_from(cfg: dict) -> dict:
    """``mercury.limits`` when given, else the tier's documented limits (default: free)."""
    tier = str(cfg.get("tier", "free")).lower()
    base = dict(TIERS.get(tier, TIERS["free"]))
    for k, v in (cfg.get("limits") or {}).items():
        if k in base and v:
            base[k] = int(v)
    return base


def effective_caps(key: str, cfg: dict) -> dict:
    """Per-minute caps the next call would see: the running budget's, else documented × safety capped by what
    an earlier session learned (``mercury-limits.json``)."""
    with _LOCK:
        b = _BUDGETS.get(key)
    if b is not None:
        return b.caps()
    limits, safety = limits_from(cfg), float(cfg.get("safety", 0.8))
    learned = _load_learned(key)
    return {k: min(v * safety, learned.get(k, float("inf"))) for k, v in limits.items()}


def reset() -> None:
    with _LOCK:
        _BUDGETS.clear()


def report() -> dict:
    """Per account: cumulative usage, caps in force, and how often calls waited or were refused."""
    with _LOCK:
        return {key.split("|")[0]: {**b.stats, "caps": {k: round(v) for k, v in b.caps().items()},
                                    "learned": dict(b.learned), "limits": b.limits, "safety": b.safety,
                                    "last_refusals": b.throttle_log[-3:]}
                for key, b in _BUDGETS.items()}


def probe(m: dict, post: Callable[[dict], int], *, rate: float = 4.0, max_requests: int = 240,
          sleep=time.sleep, clock=time.monotonic) -> dict:
    """Send tiny requests at ``rate`` a second until the server refuses one (or ``max_requests``): the count it
    accepted in the last minute is its real request limit. ``post(body) -> status``. Used by the doctor."""
    sent: collections.deque = collections.deque()
    t0 = clock()
    body = {"model": m["model"], "max_tokens": 5, "messages": [{"role": "user", "content": "Say OK"}],
            **({"reasoning_effort": "instant"} if m.get("reasoning_effort") else {}),
            **({"temperature": m["temperature"]} if "temperature" in m else {})}
    for i in range(max_requests):
        status = post(body)
        now = clock()
        sent.append(now)
        while sent and now - sent[0] > WINDOW_S:
            sent.popleft()
        if status == 429:
            return {"refused_after": len(sent) - 1, "seconds": round(now - t0, 1),
                    "requests_per_minute": max(MIN_LEARNED["requests"], len(sent) - 1)}
        if status >= 400:
            return {"error": f"HTTP {status}", "sent": i + 1}
        sleep(max(0.0, (i + 1) / rate - (clock() - t0)))
    return {"refused_after": None, "seconds": round(clock() - t0, 1), "requests_per_minute_at_least": len(sent)}
