#!/usr/bin/env bash
# Install the shared Cloak service on Ubuntu/Debian as the Hermes user.
# --server uses Xvfb; desktop installs a user service. --dry-run prints changes.
# Existing Chrome profiles are left untouched; log in once in the new Cloak profile.
set -euo pipefail

MODE="" SERVICE=0 DRY=0 YES=0 PORT=9242 SOURCE=""
RUN_USER="$(id -un)"
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

usage() { echo "Usage: $0 [--server|--desktop] [--dry-run] [--yes] [--port N] [--source URL]"; exit "${1:-0}"; }
while [ $# -gt 0 ]; do
  case "$1" in
    --desktop) MODE=desktop ;;
    --server) MODE=server ;;
    --service) SERVICE=1 ;;
    --dry-run) DRY=1 ;;
    --yes|-y) YES=1 ;;
    --port) PORT="${2:?--port needs a number}"; shift ;;
    --source) SOURCE="${2:?--source needs a git URL or owner/repo}"; shift ;;
    -h|--help) usage 0 ;;
    *) echo "unknown option: $1" >&2; usage 2 ;;
  esac
  shift
done

say() { printf '\033[1m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[33m!   %s\033[0m\n' "$*" >&2; }
die() { printf '\033[31mx   %s\033[0m\n' "$*" >&2; exit 1; }
run() { if [ "$DRY" = 1 ]; then printf '    would run: %s\n' "$*"; else "$@"; fi; }

[ "$DRY" = 1 ] || [ "$(id -u)" -ne 0 ] || die "Run this as the user who runs Hermes, not as root (it uses sudo where needed)."
case "$PORT" in ''|*[!0-9]*) die "--port must be a number" ;; esac
((10#$PORT >= 1024 && 10#$PORT <= 65535)) || die "--port must be between 1024 and 65535"

# ---------------------------------------------------------------- the machine
# shellcheck source=/dev/null
. /etc/os-release 2>/dev/null || true
if [ "${ID:-}" != "ubuntu" ] && [ "${ID:-}" != "debian" ]; then
  case " ${ID_LIKE:-} " in
    *" ubuntu "*|*" debian "*) warn "Not Ubuntu (${PRETTY_NAME:-unknown}); Debian-based, continuing." ;;
    *) [ "$DRY" = 1 ] || die "This installer is for Ubuntu (found ${PRETTY_NAME:-unknown}). Install CloakBrowser and the plugin by hand (README)."
       warn "Not Ubuntu (${PRETTY_NAME:-unknown}): dry run only." ;;
  esac
fi
if [ -z "$MODE" ]; then
  if [ -n "${XDG_CURRENT_DESKTOP:-}${WAYLAND_DISPLAY:-}${DISPLAY:-}" ]; then MODE=desktop; else MODE=server; fi
fi
say "hermes-swift on ${PRETTY_NAME:-this machine} ($MODE)"
if command -v dpkg >/dev/null 2>&1; then
  arch="$(dpkg --print-architecture)"
  case "$arch" in amd64|arm64) ;; *) die "Unsupported architecture: $arch" ;; esac
fi

HERMES="$(command -v hermes || true)"
[ -n "$HERMES" ] || [ "$DRY" = 1 ] || die "Hermes is not installed or not on PATH. Install Hermes first, run 'hermes setup', then this."
HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
ENV_FILE="$HERMES_HOME/.env"
if [ -n "$HERMES" ]; then ENV_FILE="$("$HERMES" config env-path 2>/dev/null | tail -n1 || echo "$ENV_FILE")"; fi
PLUGIN_DIR="$HERMES_HOME/plugins/hermes-swift"

# ---------------------------------------------------------------- 1. Cloak runtime prerequisites
run sudo apt-get install -y python3-venv xvfb xauth git

# ---------------------------------------------------------------- 2. keys
mkdir_env() { run mkdir -p "$(dirname "$ENV_FILE")"; [ "$DRY" = 1 ] || { touch "$ENV_FILE"; chmod 600 "$ENV_FILE"; }; }
mkdir_env
for key in TYPESAFE_API_KEY INCEPTION_API_KEY; do
  if [ -f "$ENV_FILE" ] && grep -q "^${key}=." "$ENV_FILE"; then
    say "$key: already in $ENV_FILE"
  elif [ "$YES" = 1 ] || [ "$DRY" = 1 ]; then
    warn "$key is missing from $ENV_FILE: add it before using browse()"
  else
    read -r -s -p "    $key (input hidden): " value; echo
    [ -n "$value" ] || die "$key is required."
    printf '%s=%s\n' "$key" "$value" >> "$ENV_FILE"
    unset value
  fi
done

# ---------------------------------------------------------------- 3. the plugin, through Hermes
REF=""
if [ -z "$SOURCE" ]; then
  if REF="$(git -C "$here" rev-parse HEAD 2>/dev/null)"; then
    git -C "$here" diff --quiet HEAD 2>/dev/null \
      || warn "This checkout has uncommitted changes; Hermes installs the committed ${REF:0:12}."
    SOURCE="file://$here"
  else
    # A downloaded ZIP must install its own files, never silently fetch the older remote repo.
    run git -C "$here" init -q
    run git -C "$here" add .
    run git -C "$here" -c user.name=AlpineSwift -c user.email=local@alpine-swift.invalid commit -qm "Install downloaded Alpine Swift release"
    if [ "$DRY" = 0 ]; then REF="$(git -C "$here" rev-parse HEAD)"; fi
    SOURCE="file://$here"
  fi
fi
say "Installing the plugin with Hermes's installer from $SOURCE${REF:+ at ${REF:0:12}}"
args=(plugins install "$SOURCE" --enable --yes-deps)
if [ -n "$REF" ]; then args+=(--ref "$REF"); fi
if [ -d "$PLUGIN_DIR" ]; then args+=(--force); fi
run "${HERMES:-hermes}" "${args[@]}"

# ---------------------------------------------------------------- 4. Hermes config
say "Pointing Hermes's browser and the plugin at 127.0.0.1:$PORT"
run "${HERMES:-hermes}" config set browser.cloud_provider local
run "${HERMES:-hermes}" config set browser.use_real_profile false
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.chrome.mode cloak
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.chrome.profile_dir "$HOME/.local/share/hermes-cloak"
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.task_contexts default
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.proxy.enabled false
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.chrome.headless false
run "${HERMES:-hermes}" config set browser.cdp_url "http://127.0.0.1:$PORT"
run "${HERMES:-hermes}" config set plugins.entries.hermes-swift.settings.chrome.port "$PORT"

# ---------------------------------------------------------------- 5. launcher venv (units, doctor)
if ! python3 -m venv --help >/dev/null 2>&1; then
  run sudo apt-get install -y python3-venv
fi
run python3 -m venv "$PLUGIN_DIR/.venv"
run "$PLUGIN_DIR/.venv/bin/pip" install -q -r "$PLUGIN_DIR/requirements-runtime.txt"
# Shared native libraries only; this does not install a Chromium browser.
run "$PLUGIN_DIR/.venv/bin/python" -m playwright install-deps chromium

if [ "$MODE" = server ]; then
  say "Installing the systemd unit hermes-chrome.service for $RUN_USER"
  unit="$(sed -e "s#User=hermes#User=$RUN_USER#" -e "s#/home/hermes#$HOME#g" "$here/deploy/hermes-chrome.service")"
  if [ "$DRY" = 1 ]; then printf '    would write /etc/systemd/system/hermes-chrome.service\n'
  else printf '%s\n' "$unit" | sudo tee /etc/systemd/system/hermes-chrome.service >/dev/null; fi
  run sudo systemctl daemon-reload
  run sudo systemctl enable hermes-chrome
  run sudo systemctl restart hermes-chrome
else
  say "Installing the systemd user unit (Cloak starts when you log in)"
  run mkdir -p "$HOME/.config/systemd/user"
  run cp "$here/deploy/hermes-chrome.user.service" "$HOME/.config/systemd/user/hermes-chrome.service"
  run systemctl --user daemon-reload
  run systemctl --user enable hermes-chrome
  run systemctl --user restart hermes-chrome

fi

# ---------------------------------------------------------------- 6. check
say "Checking"
if [ "$DRY" = 1 ]; then
  printf '    would run: %s\n' "(cd $PLUGIN_DIR && HERMES_HOME=$HERMES_HOME .venv/bin/python -m swift.doctor --online)"
else
  (cd "$PLUGIN_DIR" && HERMES_HOME="$HERMES_HOME" .venv/bin/python -m swift.doctor --online) || {
    warn "The doctor found problems; each line above says how to fix it."; exit 1; }
fi
say "Done. Restart Hermes so it loads the plugin."
if [ "$MODE" = desktop ]; then
  echo "    To watch tasks: open http://127.0.0.1:8766 (live view), or set"
  echo "    plugins.entries.hermes-swift.settings.chrome.headless to false for visible Cloak windows."
fi
