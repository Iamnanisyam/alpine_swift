(() => {
  const visible = e => {
    const r=e.getBoundingClientRect(), s=getComputedStyle(e);
    if (r.width<12 || r.height<12 || r.right<=0 || r.bottom<=0 || r.left>=innerWidth || r.top>=innerHeight ||
        s.display==='none' || s.visibility==='hidden' || Number(s.opacity)===0 || e.closest('[aria-hidden="true"],[inert]')) return false;
    const x=Math.min(innerWidth-1, Math.max(0, r.left+r.width/2));
    const y=Math.min(innerHeight-1, Math.max(0, r.top+r.height/2));
    const hit=document.elementFromPoint(x,y);
    return !!hit && (e===hit || e.contains(hit));
  };
  const modal = e => !!e.closest('[role="dialog"],[aria-modal="true"],dialog[open]');
  const fields = [...document.querySelectorAll('input[autocomplete="one-time-code"],input[name*="otp" i],input[id*="otp" i],input[aria-label*="verification code" i],input[name*="verification_code" i]')];
  const otp = fields.some(e => visible(e) && !e.disabled && !e.readOnly &&
    (document.activeElement===e || modal(e) || (e.required && !!e.form)));
  const frames=[...document.querySelectorAll('iframe')];
  const challenge = frames.some(e => {
    if (!visible(e)) return false;
    const info=[e.src,e.title,e.getAttribute('aria-label')].join(' ').toLowerCase();
    // A visible anchor/badge, hidden widget or non-interactive Turnstile alone
    // is not a challenge. Only an on-screen challenge frame in a modal or a
    // substantial interactive challenge area is evidence of an active handoff.
    const interactive=/recaptcha.*(bframe|challenge)|hcaptcha.*(challenge|frame=challenge)|captcha.*challenge|security challenge/.test(info);
    const r=e.getBoundingClientRect();
    return interactive && (modal(e) || (r.width>=220 && r.height>=160));
  });
  const custom=[...document.querySelectorAll('[role="dialog"],[aria-modal="true"],dialog[open]')].some(e => {
    if (!visible(e)) return false;
    const text=(e.innerText||'').slice(0,1200).toLowerCase();
    return /verify (you are|you.re) human|complete (the )?(captcha|challenge)|select all images|enter (the )?one.time (code|password)/.test(text);
  });
  return otp || challenge || custom;
})()
