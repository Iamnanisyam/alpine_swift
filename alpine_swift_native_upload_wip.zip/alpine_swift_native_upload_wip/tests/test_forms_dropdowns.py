"""Form filling and dropdown matching contracts (offline)."""

import pytest

from swift import dropdowns, forms


@pytest.mark.parametrize("wanted,label", [
    ("Karnataka", "Karnataka"), ("karnataka ", "Karnataka"), ("Tamil  Nadu", "Tamil Nadu"),
    ("TN", "Tamil Nadu"), ("Bangalore Urban", "Bengaluru Urban"), ("Data Sci", "Data Science"),
    ("São Paulo", "Sao Paulo"),
])
def test_code_first_matching(wanted, label):
    options = [{"label": "Select state", "value": ""}, {"label": "Kerala", "value": "kerala"},
               {"label": "Karnataka", "value": "karnataka"}, {"label": "Tamil Nadu", "value": "tamil-nadu"},
               {"label": "Bengaluru Urban", "value": "bu"}, {"label": "Data Science", "value": "ds"},
               {"label": "Sao Paulo", "value": "sp"}]
    tier, hits = dropdowns.match(options, wanted)
    assert [h["label"] for h in hits] == [label], tier


def test_placeholder_and_disabled_options_never_match():
    options = [{"label": "Select", "value": ""}, {"label": "Male", "value": "M", "disabled": True}]
    assert dropdowns.match(options, "Select")[1] == []
    assert dropdowns.match(options, "Male")[1] == []


def test_ambiguous_match_reports_several_hits():
    options = [{"label": "Civil Engineering", "value": "c"}, {"label": "Chemical Engineering", "value": "ch"}]
    tier, hits = dropdowns.match(options, "Engineering")
    assert len(hits) == 2  # the caller asks Jev only now


@pytest.mark.parametrize("desc,value,out,err", [
    ({"class": "phone", "type": "tel"}, "+91 98765 43210", "9876543210", None),
    ({"class": "phone", "type": "tel"}, "12345", None, "not a 10-digit mobile number"),
    ({"class": "pincode"}, "560 001", "560001", None),
    ({"class": "pincode"}, "060001", None, "not a 6-digit PIN code"),
    ({"class": "email", "type": "email"}, "asha@example.in", "asha@example.in", None),
    ({"class": "email", "type": "email"}, "asha@", None, "not an email address"),
    ({"type": "date"}, "14 February 1999", "1999-02-14", None),
    ({"class": "dob", "type": "text", "placeholder": "DD/MM/YYYY"}, "1999-02-14", "14/02/1999", None),
    ({"maxlength": 5}, "toolong", None, "longer than 5 characters"),
    ({"pattern": "[A-Z]{3}"}, "abc", None, "does not match the field's pattern"),
])
def test_validators(desc, value, out, err):
    assert forms.validate(desc, value) == (out, err)


@pytest.mark.parametrize("desc,cls", [
    ({"label": "Email *", "type": "email"}, "email"), ({"autocomplete": "postal-code", "label": "Code"}, "pincode"),
    ({"label": "Mobile number"}, "phone"), ({"label": "Full name"}, "full_name"),
    ({"label": "District *"}, "district"), ({"label": "Address line 1 *"}, "address_line1"),
    ({"label": "Promo code"}, None),
])
def test_classify(desc, cls):
    assert forms.classify(desc) == cls


def test_goal_literals_and_spans():
    goal = "Register Asha Verma (asha@example.in, mobile 98765 43210) in Bengaluru, PIN 560001."
    lit = forms.goal_literals(goal)
    assert lit == {"email": "asha@example.in", "phone": "9876543210", "pincode": "560001"}
    spans = forms.goal_spans("Find and open the Wikipedia article about Gödel’s incompleteness theorems.")
    assert "Gödel’s incompleteness theorems" in spans


def obs_form():
    a = lambda **k: {"form": 1, "role": "textbox", "kind": "fill", **k}  # noqa: E731
    return {"actions": [
        a(id="e1", node=1, label="Full name *", value="", field={"type": "text", "required": True}),
        a(id="e2", node=1, label="Open Full name *", value="", kind="click"),
        a(id="e3", node=2, label="Password", value="", sensitive="password", field={"type": "password"}),
        {"id": "e4", "node": 3, "form": 1, "role": "combobox", "kind": "select", "label": "Gender → Female",
         "value": "F", "current_value": "Select gender", "field": {"type": "select-one", "required": True}},
        {"id": "e5", "node": 4, "form": 1, "role": "button", "kind": "click", "label": "Submit"},
        {"id": "e6", "node": 9, "form": 2, "role": "textbox", "kind": "fill", "label": "Search", "value": ""},
    ], "disabled_fields": [{"node": 5, "form": 1, "label": "District", "field": {"type": "select-one",
                                                                                 "required": True}}]}


def test_collect_takes_the_whole_form_and_only_that_form():
    fields = forms.collect(obs_form(), {"node": 1, "form": 1})
    kinds = {f.desc["label"]: (f.kind, f.sensitive, f.dependent) for f in fields}
    assert kinds == {"Full name *": ("text", None, False), "Password": ("text", "password", False),
                     "Gender": ("native_select", None, False), "District": ("native_select", None, True)}
    assert [f.desc["label"] for f in fields][-1] == "District"  # dependent dropdowns last


class StubModel:
    def __init__(self, values):
        self.values, self.requests = values, []

    def available(self):
        return True

    def fill(self, fields, context):
        self.requests.append((fields, context))
        return {k: self.values.get(v["label"]) for k, v in fields.items()}


class StubPage:
    def __init__(self):
        self.typed = {}

    def fill_node(self, node, text, *, per_key=False, secret=False):
        if not secret and node == 2:
            raise AssertionError("password typed without the secret path")
        self.typed[node] = text
        return True

    def read_value(self, node):
        return self.typed.get(node, "")

    def evaluate(self, expr):
        return "https://site.test/"

    def observe(self):
        return obs_form()

    def focus_node(self, node):
        return True


def test_secrets_never_reach_the_text_model_and_missing_values_are_reported(monkeypatch):
    model = StubModel({"Full name *": "Asha Verma"})
    filler = forms.FormFiller(textmodel=model)
    monkeypatch.setattr(forms.dropdowns, "wait_options", lambda *a, **k: [])
    monkeypatch.setattr(forms.dropdowns, "choose_native", lambda *a, **k: {"ok": False, "error": "no option"})
    page = StubPage()
    record = filler.fill_form(page, obs_form(), {"node": 1, "form": 1}, goal="Register Asha Verma")
    sent = model.requests[0][0]
    assert all(v["label"] != "Password" for v in sent.values())
    assert page.typed == {1: "Asha Verma"}
    assert "Full name *" in record["filled"] and "Gender" in record["missing"]
    assert record["secret_fills"][0]["label"] == "Password" and record["secret_fills"][0]["skipped"]


def test_required_secret_without_a_source_goes_to_the_user():
    o = obs_form()
    o["actions"][2]["field"]["required"] = True
    filler = forms.FormFiller(textmodel=StubModel({}))
    record = filler.fill_form(StubPage(), o, {"node": 1, "form": 1}, goal="x")
    assert record["needs_user"] and "vault" in record["needs_user"]


def test_no_value_for_the_chosen_field_is_not_reported_as_filled():
    filler = forms.FormFiller(textmodel=StubModel({}))
    o = {"actions": [{"id": "e1", "node": 7, "role": "searchbox", "kind": "fill", "label": "Search", "value": "",
                      "field": {"type": "search"}}], "disabled_fields": []}
    record = filler.fill_form(StubPage(), o, {"node": 7}, goal="Do something")
    assert record.get("needs_user") and not record["filled"]
