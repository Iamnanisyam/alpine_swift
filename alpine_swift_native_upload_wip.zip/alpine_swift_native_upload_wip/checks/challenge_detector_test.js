const fs = require('fs'), vm = require('vm'), assert = require('assert');
const source = fs.readFileSync('swift/challenge.js', 'utf8');
function element(opts = {}) {
  const e = {src:opts.src||'', title:opts.title||'', value:opts.value||'', disabled:false, readOnly:false,
    required:!!opts.required, form:opts.form?{}:null, innerText:opts.text||'',
    getAttribute: () => '', closest: selector => selector.includes('dialog') && opts.modal ? {} : null,
    getBoundingClientRect: () => ({left:0,top:0,right:opts.w||300,bottom:opts.h||200,width:opts.w||300,height:opts.h||200}),
    contains: other => other===e};
  return e;
}
function detect({fields=[],frames=[],dialogs=[],active=null,hit=null}={}) {
  const all=[...fields,...frames,...dialogs];
  const document={activeElement:active, elementFromPoint:()=>hit || all[0] || null,
    querySelectorAll: selector => selector==='iframe' ? frames : selector.startsWith('input') ? fields : dialogs};
  return vm.runInNewContext(source,{document,innerWidth:1280,innerHeight:800,
    getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})});
}
const anchor=element({src:'https://google.test/recaptcha/api2/anchor'});
assert.strictEqual(detect({frames:[anchor]}),false, 'a visible provider anchor alone is not a challenge');
const challenge=element({src:'https://google.test/recaptcha/api2/bframe'});
assert.strictEqual(detect({frames:[challenge]}),true, 'a visible substantial interactive challenge is detected');
const cover=element();
assert.strictEqual(detect({frames:[challenge],hit:cover}),false, 'an occluded challenge is not in front');
const otp=element({required:true,form:true});
assert.strictEqual(detect({fields:[otp]}),true, 'a visible required OTP field is detected');
otp.value='123456';
assert.strictEqual(detect({fields:[otp]}),true, 'a visible OTP stays active until the user submits it');
const modal=element({modal:true,text:'Verify you are human'});
assert.strictEqual(detect({dialogs:[modal]}),true,'a visible custom challenge modal is detected');
console.log('Challenge detector scenarios passed');
