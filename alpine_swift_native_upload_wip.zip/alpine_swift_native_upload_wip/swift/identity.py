"""Encrypted store for identity numbers (Aadhaar, PAN, passport, ...), each bound to a domain allowlist.

Hermes's vault has no kind for these and a hand-installed plugin cannot register a login backend, so
values live in a Fernet-encrypted file under the plugin data dir (mode 0600). Values are typed into the
page by code and never returned to the model, a tool result, a log or a trace.

Key: ``HERMES_SWIFT_IDENTITY_KEY`` (a Fernet key) from ``~/.hermes/.env``, else a key file created
next to the store with mode 0600.
"""

from __future__ import annotations

import json
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urlsplit

from . import redact
from .config import data_dir, secret

# ---------------------------------------------------------------- validators

_D = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
      [3, 4, 0, 1, 2, 8, 9, 5, 6, 7], [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
      [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3], [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
      [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]]
_P = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
      [8, 9, 1, 6, 0, 4, 3, 5, 2, 7], [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
      [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]]


def verhoeff_valid(number: str) -> bool:
    if not number.isdigit():
        return False
    c = 0
    for i, digit in enumerate(reversed(number)):
        c = _D[c][_P[i % 8][int(digit)]]
    return c == 0


def aadhaar_valid(value: str) -> bool:
    digits = re.sub(r"[\s-]", "", value)
    return bool(re.fullmatch(r"[2-9]\d{11}", digits)) and verhoeff_valid(digits)


def pan_valid(value: str) -> bool:
    # 5 letters (4th is the holder type), 4 digits, 1 letter.
    return bool(re.fullmatch(r"[A-Z]{3}[ABCFGHLJPT][A-Z]\d{4}[A-Z]", value.strip().upper()))


def pin_valid(value: str) -> bool:
    return bool(re.fullmatch(r"[1-9]\d{5}", value.strip()))


def passport_valid(value: str) -> bool:
    return bool(re.fullmatch(r"[A-Z][1-9]\d{5}[1-9]", value.strip().upper()))


VALIDATORS = {"aadhaar": aadhaar_valid, "pan": pan_valid, "passport": passport_valid, "pin": pin_valid}


def normalise_value(kind: str, value: str) -> str:
    if kind == "aadhaar":
        return re.sub(r"[\s-]", "", value)
    if kind in ("pan", "passport"):
        return value.strip().upper()
    return value.strip()


def mask(value: str) -> str:
    return ("•" * max(0, len(value) - 4)) + value[-4:] if len(value) > 4 else "••••"


def host_allowed(url: str, domains: list[str]) -> bool:
    """Exact host or a subdomain of an allowlisted domain; https only (http only for localhost)."""
    parts = urlsplit(url)
    host = (parts.hostname or "").lower().rstrip(".")
    if not host:
        return False
    if parts.scheme != "https" and not (parts.scheme == "http" and host in ("localhost", "127.0.0.1")):
        return False
    for d in domains:
        d = d.lower().strip().lstrip(".").rstrip(".")
        if d and (host == d or host.endswith("." + d)):
            return True
    return False


# ---------------------------------------------------------------- store


class IdentityError(RuntimeError):
    pass


class IdentityStore:
    def __init__(self, path: Optional[Path] = None, key: Optional[bytes] = None):
        self.path = Path(path) if path else data_dir() / "identity.enc"
        self._key = key
        self._lock = threading.Lock()

    def _fernet(self):
        from cryptography.fernet import Fernet

        key = self._key or secret("HERMES_SWIFT_IDENTITY_KEY").encode() or None
        if not key:
            keyfile = self.path.with_suffix(".key")
            if keyfile.exists():
                key = keyfile.read_bytes().strip()
            else:
                key = Fernet.generate_key()
                fd = os.open(keyfile, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(fd, "wb") as f:
                    f.write(key)
        return Fernet(key)

    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        items = json.loads(self._fernet().decrypt(self.path.read_bytes()))
        for item in items:
            redact.register(item["value"])
        return items

    def _save(self, items: list[dict]) -> None:
        blob = self._fernet().encrypt(json.dumps(items).encode())
        tmp = self.path.with_suffix(".tmp")
        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "wb") as f:
            f.write(blob)
        os.replace(tmp, self.path)
        os.chmod(self.path, 0o600)

    def add(self, kind: str, value: str, domains: list[str], label: str = "") -> dict:
        kind = kind.lower()
        value = normalise_value(kind, value)
        check = VALIDATORS.get(kind)
        if check and not check(value):
            raise IdentityError(f"{kind} value failed validation")
        if not domains:
            raise IdentityError("an identity item needs at least one allowed domain")
        redact.register(value)
        with self._lock:
            items = self._load()
            item = {"id": "id_" + secrets.token_hex(4), "kind": kind, "label": label or kind.upper(),
                    "value": value, "domains": [d.lower().strip() for d in domains], "created": int(time.time())}
            items.append(item)
            self._save(items)
        return self._public(item)

    def remove(self, item_id: str) -> bool:
        with self._lock:
            items = self._load()
            kept = [i for i in items if i["id"] != item_id]
            self._save(kept)
            return len(kept) != len(items)

    @staticmethod
    def _public(item: dict) -> dict:
        return {"id": item["id"], "kind": item["kind"], "label": item["label"], "masked": mask(item["value"]),
                "domains": item["domains"]}

    def list(self) -> list[dict]:
        with self._lock:
            return [self._public(i) for i in self._load()]

    def find(self, kind: str, url: str) -> Optional[dict]:
        """Public view of the first item of ``kind`` allowed on ``url``."""
        for item in self.list():
            if item["kind"] == kind and host_allowed(url, item["domains"]):
                return item
        return None

    def fill(self, page, url: str, node: int, item_id: str, maxlength: Optional[int] = None) -> dict:
        """Type the value into one observed field, only on an allowed domain. Never returns the value."""
        with self._lock:
            item = next((i for i in self._load() if i["id"] == item_id), None)
        if item is None:
            raise IdentityError("unknown identity item")
        # Re-read the page's URL right before the write: the domain check must hold at the moment of typing.
        live_url = page.evaluate("location.href") or url
        if not host_allowed(live_url, item["domains"]):
            raise IdentityError(f"{item['kind']} is not allowed on this site")
        redact.register(item["value"])
        value = item["value"]
        if maxlength and len(value) > int(maxlength):
            raise IdentityError("field is shorter than the stored value")
        ok = page.fill_node(node, value, secret=True) and page.has_value(node)
        return {"ok": bool(ok), "item": self._public(item)}


def detect_kind(action: dict) -> Optional[str]:
    """Which identity kind a field asks for, from its label and attributes. A field that only mentions the
    document ("Name as on Aadhaar", "Address as per passport") asks for something else and gets None."""
    f = action.get("field") or {}
    text = " ".join(str(x or "") for x in (action.get("label"), f.get("name"), f.get("placeholder"),
                                           f.get("label_text"))).lower()
    other = re.search(r"\b(name|address|date|email|phone|mobile|father|mother|dob)\b", text)
    asks_number = re.search(r"\b(number|no\.?|num|id|uid|digits?)\b|x{4}|\d{4}", text)
    if other and not asks_number:
        return None
    if re.search(r"aadha?ar|\buid\b", text):
        return "aadhaar"
    if re.search(r"\bpan\b|permanent account", text):
        return "pan"
    if "passport" in text:
        return "passport"
    if "voter" in text:
        return "voter_id"
    return None


# ---------------------------------------------------------------- CLI (run on the server, never by the model)

USAGE = """python -m swift.identity list
python -m swift.identity add <kind> --domains uidai.gov.in,example.gov.in [--label "My Aadhaar"]
python -m swift.identity remove <id>

kind: aadhaar | pan | passport | voter_id | <other>. The value is read from a hidden prompt, never from the
command line (shell history and the process list would keep it)."""


def main(argv: Optional[list[str]] = None) -> int:
    import argparse
    import getpass
    import sys

    ap = argparse.ArgumentParser(prog="python -m swift.identity", usage=USAGE)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    add = sub.add_parser("add")
    add.add_argument("kind")
    add.add_argument("--domains", required=True, help="comma-separated hosts the value may be typed on")
    add.add_argument("--label", default="")
    rm = sub.add_parser("remove")
    rm.add_argument("id")
    args = ap.parse_args(argv)
    store = IdentityStore()
    if args.cmd == "list":
        print(json.dumps(store.list(), indent=1, ensure_ascii=False))
        return 0
    if args.cmd == "remove":
        print("removed" if store.remove(args.id) else "no such item")
        return 0
    value = getpass.getpass(f"{args.kind} value (hidden): ")
    try:
        item = store.add(args.kind, value, [d for d in args.domains.split(",") if d.strip()], label=args.label)
    except IdentityError as exc:
        print(f"refused: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(item, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
