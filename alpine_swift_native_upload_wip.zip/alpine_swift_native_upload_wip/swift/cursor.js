(() => {
  if (window.__swiftCursor) return;
  const host = document.createElement('div');
  host.setAttribute('aria-hidden', 'true');
  host.style.cssText = 'position:fixed;left:0;top:0;z-index:2147483647;pointer-events:none;';
  const root = host.attachShadow({mode:'closed'});
  const badge = document.createElement('span');
  badge.style.cssText = 'position:fixed;display:none;pointer-events:none;padding:3px 6px;border-radius:5px;background:#171b23;color:white;font:12px sans-serif;white-space:nowrap;';
  root.appendChild(badge);
  const mount = () => { if (!host.isConnected && document.documentElement) document.documentElement.appendChild(host); };
  if (document.documentElement) mount();
  else document.addEventListener('DOMContentLoaded', mount, {once:true});
  let x=0,y=0;
  document.addEventListener('mousemove', e => {x=e.clientX;y=e.clientY;badge.style.left=Math.max(0,Math.min(x+14,innerWidth-160))+'px';badge.style.top=Math.max(0,Math.min(y+16,innerHeight-30))+'px'}, {passive:true,capture:true});
  window.__swiftCursor = (action, result) => {badge.textContent = String(action).slice(0,24)+' · '+String(result).slice(0,10);badge.style.left=Math.max(0,Math.min(x+14,innerWidth-160))+'px';badge.style.top=Math.max(0,Math.min(y+16,innerHeight-30))+'px';badge.style.display='block'};
})();
