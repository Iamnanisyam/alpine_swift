"""Offline contracts. Browser behavior and real vault compatibility need live tests."""
import contextlib
import os
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from swift import config, human_input, redact
from swift.page import Page, ActionRefused
from swift.vaultfill import VaultFill
from swift.loop import Control, FastLoop, LoopContext, Subgoal

class Inputs(unittest.TestCase):
    def test_picker_uses_adapter_and_upload_is_not_faked(self):
        page=Page.__new__(Page); seen=[]
        page._resolve_in_view=lambda *a:{'x':10,'y':10}
        page._node_input=lambda *a,**k:seen.append((a,k))
        page.read_value=lambda _: '2026-10-28'
        self.assertTrue(page.set_value_native(4,'2026-10-28'))
        with tempfile.NamedTemporaryFile() as f:
            with self.assertRaisesRegex(ActionRefused, 'Native file chooser'):
                page.set_files(5,[f.name])
        self.assertEqual(seen[0][0],(4,'fill','2026-10-28'))

    def test_adapter_bound_fill(self):
        events=[]
        class Locator:
            def fill(self,value): events.append(('fill',value))
            def set_input_files(self,paths): events.append(('upload',paths))
        class FakePage:
            url='https://example.test/account'; frames=[]
            def locator(self,s): return Locator()
            def evaluate(self,*a): pass
        @contextlib.contextmanager
        def fake(_): yield FakePage()
        with patch('swift.human_input.patched_page',fake):
            human_input.perform('t',[('fill_bound','#x','mysecret','https://example.test')])
            with self.assertRaises(RuntimeError):
                human_input.perform('t',[('fill_bound','#x','mysecret','https://other.test')])
        self.assertEqual(events,[('fill','mysecret')])

class Vault(unittest.TestCase):
    def test_bound_login_filled_locally_and_secret_redacted(self):
        events=[]; meta=types.SimpleNamespace(kind='login')
        class Backend:
            needs_unlock=False
            def get_meta(self,h): return meta
            def fill_context(self): return contextlib.nullcontext()
            def resolve_password(self,h): events.append('resolve'); return 's3cret!'
        fakebackend=types.ModuleType('agent.vault_backends');fakebackend.backend_for_handle=lambda _:Backend()
        fakeagent=types.ModuleType('agent');fakeredact=types.ModuleType('agent.redact');fakeredact.register_vault_redaction_value=lambda v:events.append('redaction')
        fakecontext=types.ModuleType('tools.browser_vault_context');fakecontext.saved_origins=lambda m:['https://example.test'];fakecontext.snapshot_refusal=lambda *a:None
        classifier=types.ModuleType('agent.vault_login_classifier')
        classifier.LoginControl=types.SimpleNamespace(from_dict=lambda x:x)
        classifier.classify_login_control=lambda x:types.SimpleNamespace(token='current-password')
        classifier.classify_checkout_control=lambda x:None;classifier.select_checkout_fills=lambda *a:[]
        store=types.ModuleType('agent.vault_store');store.PAYMENT_FIELDS={};store.ADDRESS_FIELDS={}
        modules={'agent':fakeagent,'agent.vault_backends':fakebackend,'agent.redact':fakeredact,
                 'agent.vault_login_classifier':classifier,'agent.vault_store':store,
                 'tools':types.ModuleType('tools'),'tools.browser_vault_context':fakecontext}
        class PageStub:
            def evaluate(self,_):return 'https://example.test/login'
            def vault_descriptor(self,node): return {'type':'password'}
            def fill_vault_value(self,node,value,origin,**kwargs):
                self.assertions=(node,value,origin);events.append('fill');return True
        page=PageStub()
        def dispatch(name,args):
            self.assertEqual(args['action'],'list')
            return {'items':[{'kind':'login','handle':'h','origin':'https://example.test'}]}
        redact.clear()
        with patch.dict(sys.modules,modules):
            out=VaultFill(dispatch).fill('login',page,{'url':'https://example.test/login'},7)
        self.assertTrue(out['success']);self.assertEqual(events,['resolve','redaction','fill'])
        self.assertEqual(page.assertions,(7,'s3cret!','https://example.test'))
        self.assertNotIn('s3cret!',repr(out));self.assertNotIn('s3cret!',redact.scrub_text('s3cret!'))
        redact.clear()

    def test_approved_payment_uses_classified_field_and_adapter(self):
        events=[]; meta=types.SimpleNamespace(kind='payment',label='card')
        class Backend:
            needs_unlock=False
            def get_meta(self,h):return meta
            def fill_context(self):return contextlib.nullcontext()
            def resolve_secret(self,h):events.append('resolve');return {'number':'4111111111111111'}
        backend=types.ModuleType('agent.vault_backends');backend.backend_for_handle=lambda _:Backend()
        ar=types.ModuleType('agent.redact');ar.register_vault_redaction_value=lambda _:events.append('redact')
        classifier=types.ModuleType('agent.vault_login_classifier')
        classifier.LoginControl=types.SimpleNamespace(from_dict=lambda x:x)
        classifier.classify_login_control=lambda x:None
        classifier.classify_checkout_control=lambda x:types.SimpleNamespace(token='cc-number')
        classifier.select_checkout_fills=lambda c,v,t:[{'value':v['number']}]
        store=types.ModuleType('agent.vault_store');store.PAYMENT_FIELDS={};store.ADDRESS_FIELDS={}
        vc=types.ModuleType('tools.browser_vault_context');vc.saved_origins=lambda _:['https://example.test'];vc.snapshot_refusal=lambda *a:None
        vt=types.ModuleType('tools.browser_vault_tool');vt._confirm_payment_fill=lambda *a:events.append('consent') or True
        modules={'agent':types.ModuleType('agent'),'agent.vault_backends':backend,'agent.redact':ar,
                 'agent.vault_login_classifier':classifier,'agent.vault_store':store,'tools':types.ModuleType('tools'),
                 'tools.browser_vault_context':vc,'tools.browser_vault_tool':vt}
        class P:
            def vault_descriptor(self,_):return {'type':'text'}
            def evaluate(self,_):return 'https://example.test/form'
            def fill_vault_value(self,node,value,origin,**kw):events.append(('adapter',kw['expected']));return True
        vf=VaultFill(lambda *_:{'items':[{'kind':'payment','handle':'h','origin':'https://example.test'}]})
        with patch.dict(sys.modules,modules):out=vf.fill('payment',P(),{'url':'https://example.test/form'},7)
        self.assertTrue(out['success']);self.assertEqual(events,['consent','resolve','redact',('adapter','card')])
        self.assertNotIn('4111111111111111',repr(out));redact.clear()

    def test_payment_decline_never_resolves_secret(self):
        meta=types.SimpleNamespace(kind='payment',label='card')
        class Backend:
            needs_unlock=False
            def get_meta(self,h):return meta
            def resolve_secret(self,h):raise AssertionError('Must not access declined payment')
        backend=types.ModuleType('agent.vault_backends');backend.backend_for_handle=lambda _:Backend()
        ar=types.ModuleType('agent.redact');ar.register_vault_redaction_value=lambda _:None
        classifier=types.ModuleType('agent.vault_login_classifier')
        classifier.LoginControl=types.SimpleNamespace(from_dict=lambda x:x)
        classifier.classify_login_control=lambda x:None
        classifier.classify_checkout_control=lambda x:types.SimpleNamespace(token='cc-number')
        classifier.select_checkout_fills=lambda *a:[]
        store=types.ModuleType('agent.vault_store');store.PAYMENT_FIELDS={};store.ADDRESS_FIELDS={}
        vc=types.ModuleType('tools.browser_vault_context');vc.saved_origins=lambda _:['https://example.test'];vc.snapshot_refusal=lambda *a:None
        vt=types.ModuleType('tools.browser_vault_tool');vt._confirm_payment_fill=lambda *a:False
        modules={'agent':types.ModuleType('agent'),'agent.vault_backends':backend,'agent.redact':ar,
                 'agent.vault_login_classifier':classifier,'agent.vault_store':store,'tools':types.ModuleType('tools'),
                 'tools.browser_vault_context':vc,'tools.browser_vault_tool':vt}
        page=types.SimpleNamespace(vault_descriptor=lambda _: {'type':'text'})
        vf=VaultFill(lambda *_:{'items':[{'kind':'payment','handle':'h','origin':'https://example.test'}]})
        with patch.dict(sys.modules,modules):out=vf.fill('payment',page,{'url':'https://example.test'},7)
        self.assertEqual(out['error_type'],'payment_declined')

    def test_origin_mismatch_refuses_before_secret_resolution(self):
        meta=types.SimpleNamespace(kind='login')
        class Backend:
            needs_unlock=False
            def get_meta(self,h):return meta
            def resolve_password(self,h):raise AssertionError('secret must not be accessed')
        fakebackend=types.ModuleType('agent.vault_backends');fakebackend.backend_for_handle=lambda _:Backend()
        fakeredact=types.ModuleType('agent.redact');fakeredact.register_vault_redaction_value=lambda _:None
        fakecontext=types.ModuleType('tools.browser_vault_context');fakecontext.saved_origins=lambda _:['https://other.test'];fakecontext.snapshot_refusal=lambda *a:None
        classifier=types.ModuleType('agent.vault_login_classifier')
        classifier.LoginControl=types.SimpleNamespace(from_dict=lambda x:x)
        classifier.classify_login_control=lambda x:None;classifier.classify_checkout_control=lambda x:None
        classifier.select_checkout_fills=lambda *a:[]
        store=types.ModuleType('agent.vault_store');store.PAYMENT_FIELDS={};store.ADDRESS_FIELDS={}
        modules={'agent':types.ModuleType('agent'),'agent.vault_backends':fakebackend,'agent.redact':fakeredact,
                 'agent.vault_login_classifier':classifier,'agent.vault_store':store,
                 'tools':types.ModuleType('tools'),'tools.browser_vault_context':fakecontext}
        vf=VaultFill(lambda *_:{'items':[{'kind':'login','handle':'h','origin':'https://example.test'}]})
        with patch.dict(sys.modules,modules):out=vf.fill('login',object(),{'url':'https://example.test'},7)
        self.assertEqual(out['error_type'],'origin_mismatch')

class Challenge(unittest.TestCase):
    def test_configured_irreversible_policy_keeps_payment_review(self):
        class Trace:
            def log(self,*a,**k):pass
        config.configure({'irreversible_policy':'auto_after_checks'})
        loop=FastLoop(LoopContext(page=object(),jev=None,goal='x',trace=Trace(),control=Control()),Subgoal('x',{'title_contains':'done'},'reversible'))
        def decision(label):
            return {'action':{'kind':'click','role':'button','label':label},'operation':'CLICK',
                    'jev_risk':'irreversible','code_risk':'irreversible','confidence':1.0,'target_confidence':1.0,'agree':True}
        with patch('swift.loop.predicates.form_ready',return_value=True):
            self.assertTrue(loop._gate(decision('Submit'),{'actions':[]})[0])
            self.assertFalse(loop._gate(decision('Pay now'),{'actions':[]})[0])
        config.configure({})

    def test_timeout_is_bounded_and_no_action_is_replayed(self):
        config.configure({'challenge_timeout_s':1})
        class Trace:
            def log(self,*a,**k):pass
        class P:
            def observe(self):return {'marker':['x'],'tab_id':'same'}
            def challenge_visible(self):return True
        loop=FastLoop(LoopContext(page=P(),jev=None,goal='x',trace=Trace(),control=Control()),Subgoal('x',{},'reversible'))
        with patch('swift.loop.time.monotonic',side_effect=[0,0,0,2]),patch('swift.loop.time.sleep'):
            self.assertIsNone(loop.wait_for_challenge({'tab_id':'same'},'otp'))
        config.configure({})

if __name__=='__main__':unittest.main()
