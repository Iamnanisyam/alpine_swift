"""Offline test helpers: no network, no API keys, no browser."""

from __future__ import annotations

import os
import socket
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from swift import config, redact  # noqa: E402
from swift.page import fingerprint  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated(tmp_path, monkeypatch):
    """Each test gets its own data dir, default settings and no secrets in the environment."""
    monkeypatch.setenv("HERMES_SWIFT_DATA_DIR", str(tmp_path / "data"))
    for key in ("TYPESAFE_API_KEY", "INCEPTION_API_KEY", "PROXY_SERVER", "HERMES_SWIFT_IDENTITY_KEY", "CHROME_PATH",
                "BROWSER_CDP_URL", "DISPLAY", "WAYLAND_DISPLAY", "XDG_SESSION_TYPE"):
        monkeypatch.delenv(key, raising=False)
    config.configure({})
    redact.clear()
    yield
    redact.clear()


@pytest.fixture(autouse=True)
def _no_network(monkeypatch):
    """Unit tests must never open a socket."""
    def guard(*_a, **_k):
        raise RuntimeError("network access in a unit test")

    monkeypatch.setattr(socket.socket, "connect", guard)
    monkeypatch.setattr(socket, "create_connection", guard)


def choice(ids, selected, confidence=1.0):
    ids = list(ids)
    return {"type": "choice", "choice": selected, "confidence": confidence,
            "probabilities": {i: float(i == selected) for i in ids}}


def noul(value):
    return {"type": "noul", "noul": value}


def make_page(actions=None, url="https://example.test/", text="Search", tab="T1"):
    state = {
        "url": url, "title": "Search", "text": text, "scroll": {"y": 0}, "w": 1280, "h": 800,
        "actions": actions if actions is not None else [
            {"id": "e1", "kind": "fill", "label": "Search", "role": "textbox", "value": "", "node": 10, "form": 1,
             "field": {"type": "search", "name": "q"}},
            {"id": "e2", "kind": "click", "label": "Open Search", "role": "textbox", "value": "", "node": 10, "form": 1},
            {"id": "e3", "kind": "click", "label": "Go", "role": "button", "value": "", "node": 20, "form": 1},
            {"id": "wait", "kind": "wait", "label": "Wait"},
        ],
        "marker": ["m", url, text], "page_key": ["k"], "guards": {"10": ["g10"], "20": ["g20"]},
        "tab_id": tab,
    }
    state["fingerprint"] = fingerprint(state)
    return state


def answers_for(body, operation="CLICK", target="2", done=0.0, blocker="none", risk="read_only",
                confidence=1.0, target_confidence=1.0):
    """Build a valid System One reply for a step request built by jev.build_questions."""
    q = body["questions"]
    out = {"operation": choice(q["operation"]["criteria"], operation, confidence)}
    for key, spec in q.items():
        if key.endswith("_target"):
            ids = list(spec["criteria"])
            pick = target if target in ids else ids[0]
            out[key] = choice(ids, pick, target_confidence)
    if "subgoal_done" in q:
        out.update(subgoal_done=noul(done), last_action_worked=noul(0.9), still_loading=noul(0.05),
                   blocker_present=choice(q["blocker_present"]["criteria"], blocker),
                   risk_level=choice(q["risk_level"]["criteria"], risk))
    return {"model": "jev-1.14.0", "answers": out, "usage": {}}


class FakeCDP:
    """Records CDP calls. ``Runtime.evaluate`` answers come from ``evaluate(expression)``."""

    def __init__(self, evaluate=None):
        self.calls: list[tuple] = []
        self._evaluate = evaluate or (lambda expr: None)
        self.closed_tabs: list[str] = []
        self._n = 0
        self.targets: list[dict] = []

    def call(self, method, params=None, session_id=None, timeout=5.0):
        params = params or {}
        self.calls.append((method, params, session_id))
        if method == "Runtime.evaluate":
            value = self._evaluate(params.get("expression", ""))
            if isinstance(value, Exception):
                return {"exceptionDetails": {"text": str(value)}}
            return {"result": {"value": value}}
        if method == "Target.createTarget":
            self._n += 1
            return {"targetId": f"T{self._n}"}
        if method == "Target.attachToTarget":
            return {"sessionId": f"S-{params['targetId']}"}
        if method == "Target.getTargets":
            return {"targetInfos": self.targets}
        if method == "Target.createBrowserContext":
            return {"browserContextId": "CTX1"}
        return {}

    def attach(self, target_id):
        return self.call("Target.attachToTarget", {"targetId": target_id})["sessionId"]

    def new_tab(self, url="about:blank", context_id=None):
        from swift.transport import TabRef

        tid = self.call("Target.createTarget", {"url": url})["targetId"]
        return TabRef(tid, self.attach(tid), context_id)

    def close_tab(self, tab):
        self.closed_tabs.append(tab.target_id)

    def events(self):
        return []

    def methods(self, name):
        return [c for c in self.calls if c[0] == name]


@pytest.fixture
def no_env_keys():
    return {k: os.environ.get(k) for k in ("TYPESAFE_API_KEY",)}
