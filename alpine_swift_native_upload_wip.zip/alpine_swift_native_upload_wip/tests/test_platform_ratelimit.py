"""Offline contracts for the Mercury rate budget, automatic parallelism and Ubuntu desktop/server detection."""

import threading
import time

import pytest

from swift import config, platform, ratelimit


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


def test_budget_admits_until_the_reserved_output_would_pass_the_safe_limit():
    clock = Clock()
    b = ratelimit.RateBudget(requests=1000, input_tokens=1_000_000, output_tokens=10_000, safety=0.8, clock=clock)
    grants = [b.acquire(100, 2000, timeout=0) for _ in range(4)]  # 8,000 reserved = the safe 80%
    with pytest.raises(ratelimit.RateBudgetTimeout):
        b.acquire(100, 2000, timeout=0)
    # Real usage replaces the reservation: four small answers free nearly all of it.
    for g in grants:
        b.release(g, input_tokens=100, output_tokens=150)
    assert b.usage()["output_tokens"] == 600
    b.acquire(100, 2000, timeout=0)


def test_budget_window_slides_and_counts_requests():
    clock = Clock()
    b = ratelimit.RateBudget(requests=10, input_tokens=10**9, output_tokens=10**9, safety=0.5, clock=clock)
    for _ in range(5):
        b.release(b.acquire(1, 1, timeout=0))
    with pytest.raises(ratelimit.RateBudgetTimeout):
        b.acquire(1, 1, timeout=0)  # 5 requests = 50% of 10
    clock.t += 61
    b.release(b.acquire(1, 1, timeout=0))  # the minute has passed
    assert b.stats["requests"] == 6


def test_a_429_pauses_new_calls_for_a_second():
    clock = Clock()
    b = ratelimit.RateBudget(requests=1000, input_tokens=10**9, output_tokens=10**9, clock=clock)
    b.release(b.acquire(1, 1, timeout=0), status=429)
    # Nothing accepted from us this minute: someone else used it. One refusal at most halves the cap.
    assert b.stats["throttled"] == 1 and b.learned["requests"] == 400
    with pytest.raises(ratelimit.RateBudgetTimeout):
        b.acquire(1, 1, timeout=0)  # paused for a second after a 429
    clock.t += 1.1
    b.release(b.acquire(1, 1, timeout=0))


def test_an_idle_budget_always_admits_one_call_however_large():
    b = ratelimit.RateBudget(requests=1000, input_tokens=100, output_tokens=100)
    g = b.acquire(5000, 5000, timeout=0)
    b.release(g)


def test_waiters_start_as_budget_frees():
    b = ratelimit.RateBudget(requests=1000, input_tokens=10**9, output_tokens=1000, safety=1.0)
    g = b.acquire(1, 1000, timeout=0)
    got = []
    t = threading.Thread(target=lambda: got.append(b.acquire(1, 900, timeout=5)))
    t.start()
    time.sleep(0.1)
    assert not got  # 1,000 reserved in flight: no room for 900 more
    b.release(g, output_tokens=10)  # the first call used 10 of its 1,000: 10 + 900 fits
    t.join(2)
    assert got and b.stats["waited"] == 1


def test_tier_limits_follow_the_docs_and_can_be_overridden():
    assert ratelimit.limits_from({}) == {"requests": 1000, "input_tokens": 1_000_000, "output_tokens": 100_000}
    assert ratelimit.limits_from({"tier": "payg"})["output_tokens"] == 300_000
    assert ratelimit.limits_from({"tier": "enterprise", "limits": {"requests": 9000}})["requests"] == 9000


@pytest.fixture(autouse=True)
def _no_learned_caps(monkeypatch):
    # Caps learned by real sessions live in the data dir; these tests use the documented limits only.
    monkeypatch.setattr(ratelimit, "_load_learned", lambda key: {})
    monkeypatch.setattr(ratelimit, "_save_learned", lambda key, learned: None)
    ratelimit.reset()
    yield
    ratelimit.reset()


@pytest.mark.parametrize("cpus,mem,tier,expected", [
    (2, 8.0, "free", 1),      # a small desktop: cores decide
    (4, 16.0, "free", 3),
    (8, 3.0, "free", 3),      # little free memory decides
    (16, 64.0, "free", 11),   # a big machine on the documented free tier: output tokens decide (80k / 7k)
    (32, 128.0, "payg", 12),  # never more than MAX_AUTO
])
def test_auto_parallelism_is_the_smallest_ceiling(cpus, mem, tier, expected):
    config.configure({"mercury": {"tier": tier}})
    try:
        c = platform.ceilings(cpus=cpus, mem_gb=mem)
        assert min(c.values()) == expected
    finally:
        config.configure({})


def test_explicit_parallel_tasks_wins():
    assert platform.parallel_tasks(4) == 4
    assert platform.parallel_tasks("3") == 3
    assert platform.parallel_tasks("auto") >= 1


@pytest.mark.parametrize("setting,env,headless", [
    (True, {}, True), (False, {"DISPLAY": ":0"}, False), ("false", {}, False),
    ("auto", {"WAYLAND_DISPLAY": "wayland-0"}, False), ("auto", {"DISPLAY": ":1"}, False), ("auto", {}, True),
])
def test_headless_setting_for_desktop_and_server(setting, env, headless):
    assert platform.headless_wanted(setting, env) is headless


def test_desktop_session_kinds():
    assert platform.desktop_session({"WAYLAND_DISPLAY": "wayland-0", "DISPLAY": ":0"}) == "wayland"
    assert platform.desktop_session({"DISPLAY": ":0"}) == "x11"
    assert platform.desktop_session({"XDG_SESSION_TYPE": "tty"}) == ""


def test_os_release_parsing(tmp_path):
    p = tmp_path / "os-release"
    p.write_text('NAME="Ubuntu"\nVERSION_ID="24.04"\nID=ubuntu\nPRETTY_NAME="Ubuntu 24.04.1 LTS"\n')
    rel = platform.os_release(str(p))
    assert rel["ID"] == "ubuntu" and rel["VERSION_ID"] == "24.04"


def test_refusals_converge_on_the_real_request_cap_and_it_is_saved():
    clock = Clock()
    saved = []
    b = ratelimit.RateBudget(requests=1000, input_tokens=10**9, output_tokens=10**9, safety=0.8, clock=clock,
                             on_learn=saved.append)
    seen, refusals = [], []
    for minute in range(5):  # a server that accepts 100 requests a minute and refuses the 101st
        accepted, before = 0, b.stats["throttled"]
        start = clock.t
        while clock.t - start < 60:
            try:
                g = b.acquire(10, 10, timeout=0)
            except ratelimit.RateBudgetTimeout:
                clock.t += 0.2
                continue
            refused = accepted >= 100
            b.release(g, status=429 if refused else 200)
            accepted += not refused
            clock.t += 0.2
        clock.t += 60  # let the window clear before the next minute
        seen.append(b.caps()["requests"])
        refusals.append(b.stats["throttled"] - before)
    # Each refusal at most halves the cap (800 → 400 → 200 → 100 within the first minute), then the server's own
    # limit is learned (100 accepted × 0.9) and the refusals stop.
    assert seen[0] <= 100 and 90 <= seen[-1] <= 100 and refusals[-1] == 0
    assert saved[-1]["requests"] == seen[-1]
    assert b.throttle_log[0]["accepted"] == 100


def test_external_requests_count_in_the_window():
    clock = Clock()
    b = ratelimit.RateBudget(requests=100, input_tokens=10**9, output_tokens=10**9, safety=1.0, clock=clock)
    b.note_external(100)
    with pytest.raises(ratelimit.RateBudgetTimeout):
        b.acquire(1, 1, timeout=0)
    clock.t += 61
    b.release(b.acquire(1, 1, timeout=0))


def test_learned_caps_relax_after_quiet_time_and_go_away():
    clock = Clock()
    b = ratelimit.RateBudget(requests=1000, input_tokens=10**9, output_tokens=10**9, safety=0.8, clock=clock,
                             learned={"requests": 700})
    assert b.caps()["requests"] == 700
    clock.t += 301
    b.release(b.acquire(1, 1, timeout=0))
    assert "requests" not in b.learned  # 700 × 1.25 passes 800: back at the documented limit × safety
    assert b.caps()["requests"] == 800


def test_auto_parallelism_follows_a_learned_cap(monkeypatch):
    monkeypatch.setattr(platform, "mercury_caps", lambda: {"requests": 90, "input_tokens": 800_000,
                                                           "output_tokens": 80_000})
    c = platform.ceilings(cpus=16, mem_gb=64.0)
    assert c["mercury"] == 3 and min(c.values()) == 3


def test_memory_ceiling_counts_running_tasks_once():
    c0 = platform.ceilings(cpus=64, mem_gb=1.5 + 0.45 * 4 + 0.01, running=0)
    c4 = platform.ceilings(cpus=64, mem_gb=1.5, running=4)  # four tasks started and used their memory
    assert c0["memory"] == 4 and c4["memory"] == 4


def test_probe_finds_the_request_limit():
    calls = []
    clock = Clock()

    def post(body):
        calls.append(body)
        clock.t += 0.25
        return 429 if len(calls) > 100 else 200

    out = ratelimit.probe({"model": "mercury-3", "reasoning_effort": "instant"}, post, rate=4, sleep=lambda s: None,
                          clock=clock)
    assert out["requests_per_minute"] == 100 and calls[0]["max_tokens"] == 5


def test_slots_follow_a_changing_cap():
    from swift.controller import _Slots

    cap = {"n": 2}
    s = _Slots(lambda running: cap["n"])
    assert s.acquire(0) and s.acquire(0)
    assert not s.acquire(0)  # two running, cap 2
    cap["n"] = 3
    assert s.acquire(0)
    s.release()
    assert s.active == 2


def test_an_account_problem_is_reported_as_provider_unavailable():
    from swift import jev
    from swift.controller import Controller

    class DeadJev(jev.JevClient):
        def ask(self, *a, **k):
            raise jev.JevUnavailable("TypeSafe returned HTTP 402: Your organization has no available TypeSafe API "
                                     "credits; no action executed.")

    class Tabs:
        def start(self, task_id, goal):
            from swift.sessions import TaskTabs
            return TaskTabs(task_id)

        def new_tab(self, task_id):
            raise jev.JevUnavailable("TypeSafe returned HTTP 402: no available TypeSafe API credits")

        def finish(self, task_id, verified):
            pass

    ctl = Controller(cdp_factory=lambda t: None, jev=DeadJev(post=lambda b: {}))
    ctl._transports["default"] = (None, Tabs())
    config.configure({"planner": "never"})
    try:
        r = ctl.browse("open example.com", "https://example.com", {"url_contains": "example"})
    finally:
        config.configure({})
    assert r["verified"] is False
    assert r["blockers"][0]["type"] == "provider_unavailable" and "credits" in r["blockers"][0]["detail"]
