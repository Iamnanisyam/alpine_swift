"""Check that this machine can run hermes-swift, and say how to fix what is missing (Ubuntu desktop or server).

    python -m swift.doctor                    # local checks only
    python -m swift.doctor --online           # also one tiny Mercury 3 call and one tiny Jev call (uses both keys)
    python -m swift.doctor --measure-mercury  # find this Mercury key's real request limit (about a minute) and
                                              # save it, so parallel_tasks: auto uses it from then on
    python -m swift.doctor --json

Reads the plugin's settings from Hermes's config (``$HERMES_HOME/config.yaml``, default ``~/.hermes``). Exit code 1
when a check fails. Never prints a key.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

OK, WARN, FAIL = "ok", "warn", "fail"


def hermes_home() -> Path:
    return Path(os.environ.get("HERMES_HOME") or "~/.hermes").expanduser()


def hermes_config(path: Optional[Path] = None) -> dict:
    path = path or Path(os.environ.get("HERMES_CONFIG") or hermes_home() / "config.yaml").expanduser()
    try:
        import yaml

        return yaml.safe_load(path.read_text()) or {}
    except Exception:
        return {}


def load_env_file(path: Path) -> None:
    """Hermes keeps keys in ~/.hermes/.env; outside Hermes the doctor reads them from there (never printed)."""
    try:
        for line in path.read_text().splitlines():
            k, _, v = line.strip().partition("=")
            if k and v and not k.startswith("#"):
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except OSError:
        pass


def measure_mercury(model: dict) -> dict:
    """Find this key's real request limit with tiny requests (5 output tokens each, about 100-240 of them, so it
    can take a minute), then teach it to the rate budget, which saves it for later sessions."""
    import httpx

    from . import ratelimit
    from .config import secret, settings
    from .textmodel import _budget_for

    key = secret(model.get("key_env", ""))
    url = model["base_url"].rstrip("/") + "/chat/completions"
    with httpx.Client(http2=True, timeout=20) as client:
        def post(body):
            return client.post(url, json=body, headers={"Authorization": f"Bearer {key}"}).status_code

        result = ratelimit.probe(model, post, rate=float(settings().get("mercury.probe_rate", 4)))
    rpm = result.get("requests_per_minute")
    budget = _budget_for(model)
    budget.note_external(result.get("refused_after") or result.get("requests_per_minute_at_least") or 0)
    if rpm:
        with budget._cv:
            budget.learned["requests"] = max(ratelimit.MIN_LEARNED["requests"], int(rpm * ratelimit.LEARN_FACTOR))
            budget._save()
    return result


def checks(online: bool = False, measure: bool = False) -> list[dict]:
    from . import platform as plat
    from . import ratelimit
    from .config import configure, secret, settings

    cfg = hermes_config()
    configure(((cfg.get("plugins") or {}).get("entries") or {}).get("hermes-swift", {}).get("settings") or {})
    load_env_file(hermes_home() / ".env")
    out: list[dict] = []

    def add(name, status, detail, fix=""):
        out.append({"check": name, "status": status, "detail": detail, **({"fix": fix} if fix else {})})

    # ---- machine
    s = plat.summary()
    add("system", OK if s["ubuntu"] else WARN, f"{s['os']}, {s['kind']} ({s['session']} session), {s['cpus']} cores, "
        f"{s['available_memory_gb']} GB available",
        "" if s["ubuntu"] else "Tested for Ubuntu 22.04 and 24.04; other Linux distributions should work but are untested")
    if s["root"]:
        add("user", FAIL, "running as root", "Run Hermes as your normal user (desktop) or a dedicated user (server)")
    else:
        add("user", OK, f"uid {os.getuid()}" if hasattr(os, "getuid") else "not root")
    add("parallel tasks", OK, f"{s['parallel_tasks']} at once (setting: {settings().get('parallel_tasks', 'auto')}; "
        f"ceilings {s['parallel_ceilings']})")

    # ---- The one externally managed Cloak session
    from .cloak import require_session

    c = settings().get("chrome", {})
    port = int(c.get("port") or 9242)
    try:
        add("cloak", OK, require_session())
    except RuntimeError as exc:
        add("cloak", FAIL, str(exc), "Start python -m swift.cloak serve (under Xvfb on a server)")

    # ---- Hermes
    browser_url = str((cfg.get("browser") or {}).get("cdp_url") or "")
    want = f"http://127.0.0.1:{port}"
    if not cfg:
        add("hermes config", WARN, f"no readable {hermes_home() / 'config.yaml'}", "Run `hermes setup` first")
    elif browser_url.rstrip("/") != want:
        add("hermes browser.cdp_url", FAIL, f"is {browser_url or 'unset'}; Hermes and the plugin must share {want}",
            f"In {hermes_home() / 'config.yaml'}: browser: {{cdp_url: {want}}}")
    else:
        add("hermes browser.cdp_url", OK, want)
    enabled = ((cfg.get("plugins") or {}).get("enabled") or []) if cfg else []
    if cfg:
        add("plugin enabled", OK if "hermes-swift" in enabled else FAIL, ", ".join(enabled) or "none",
            "" if "hermes-swift" in enabled else "hermes plugins enable hermes-swift")
    plugin_dir = hermes_home() / "plugins" / "hermes-swift"
    add("plugin installed", OK if (plugin_dir / "plugin.yaml").exists() else WARN, str(plugin_dir),
        "" if (plugin_dir / "plugin.yaml").exists() else "deploy/install-ubuntu.sh links this checkout there")

    # ---- keys and models
    for key in ("TYPESAFE_API_KEY", "INCEPTION_API_KEY"):
        add(key, OK if secret(key) else FAIL, "set" if secret(key) else "missing",
            "" if secret(key) else f"Add {key}=... to {hermes_home() / '.env'} (chmod 600)")
    models = {m.get("model") for m in (settings().get("text_models") or []) + (settings().get("planner_models") or [])}
    add("models", OK if models == {"mercury-3"} else WARN, ", ".join(sorted(m for m in models if m)) or "none",
        "" if models == {"mercury-3"} else "The defaults use Mercury 3 only")
    m = settings().get("mercury", {}) or {}
    caps = {k: int(v) for k, v in plat.mercury_caps().items()}
    add("mercury budget", OK, f"tier {m.get('tier', 'free')} (documented {ratelimit.limits_from(m)} a minute); "
        f"caps in force {caps}" + ("" if caps.get("requests", 0) < 0.8 * ratelimit.limits_from(m)["requests"]
                                   else f", {int(float(m.get('safety', 0.8)) * 100)}% of documented"),
        "" if measure else "python -m swift.doctor --measure-mercury finds this key's real request limit")

    if online:
        if secret("INCEPTION_API_KEY"):
            try:
                from .textmodel import TextModel

                started = time.perf_counter()
                tm = TextModel()
                reply = tm.plan("Return JSON {\"ok\": true}.", {"ping": 1}, {"type": "object", "required": ["ok"]},
                                timeout=10, fast=True, max_tokens=50)
                add("mercury 3", OK if reply.get("ok") else WARN, f"answered in {time.perf_counter() - started:.2f} s")
            except Exception as exc:
                add("mercury 3", FAIL, str(exc)[:200], "Check INCEPTION_API_KEY and https://platform.inceptionlabs.ai")
        if secret("TYPESAFE_API_KEY"):
            try:
                from .jev import JevClient

                started = time.perf_counter()
                p = JevClient().noul({"page": {"text": "Hello"}}, "Does the page say hello?")
                add("jev", OK, f"answered in {time.perf_counter() - started:.2f} s (p={p:.2f})")
            except Exception as exc:
                add("jev", FAIL, str(exc)[:200], "Check TYPESAFE_API_KEY")
    # Last: the measurement uses up this key's minute (other Mercury calls right after it wait for the next).
    if measure and secret("INCEPTION_API_KEY"):
        model = (settings().get("text_models") or [{}])[0]
        result = measure_mercury(model)
        if "requests_per_minute" in result:
            add("mercury limit", OK, f"refused after {result['refused_after']} requests in {result['seconds']} s: "
                f"about {result['requests_per_minute']} a minute; saved, so parallel_tasks: auto now allows "
                f"{plat.parallel_tasks('auto')}")
        elif result.get("error"):
            add("mercury limit", FAIL, result["error"])
        else:
            add("mercury limit", OK, f"no refusal at {result.get('requests_per_minute_at_least')} requests a minute")
    return out


def main(argv: Optional[list[str]] = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        results = checks(online="--online" in argv, measure="--measure-mercury" in argv)
    except Exception as exc:  # the doctor itself must never crash without a message
        print(f"doctor failed: {exc.__class__.__name__}: {exc}")
        return 1
    if "--json" in argv:
        print(json.dumps(results, indent=1))
    else:
        mark = {OK: "✓", WARN: "!", FAIL: "✗"}
        for r in results:
            print(f"{mark[r['status']]} {r['check']}: {r['detail']}")
            if r.get("fix"):
                print(f"    fix: {r['fix']}")
    return 1 if any(r["status"] == FAIL for r in results) else 0


if __name__ == "__main__":
    sys.exit(main())
