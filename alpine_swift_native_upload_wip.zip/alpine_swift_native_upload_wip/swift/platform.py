"""Host information and the existing Mercury-aware task capacity calculation.

The model rate-budget calculation is preserved. Runtime currently serializes
browser tasks to protect input focus in the single persistent Cloak profile.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Optional

from . import ratelimit
from .config import settings

MAX_AUTO = 12
PER_TASK_MIN = {"requests": 30, "input_tokens": 25_000, "output_tokens": 7_000}  # one busy task slot, per minute
RESERVE_GB, PER_TASK_GB = 1.5, 0.45


def os_release(path: str = "/etc/os-release") -> dict:
    out: dict = {}
    try:
        for line in Path(path).read_text().splitlines():
            k, _, v = line.partition("=")
            if k:
                out[k] = v.strip().strip('"')
    except OSError:
        pass
    return out


def desktop_session(env: Optional[dict] = None) -> str:
    """'wayland', 'x11' or '' (no graphical session: a server, SSH or a system service)."""
    env = os.environ if env is None else env
    if env.get("WAYLAND_DISPLAY"):
        return "wayland"
    if env.get("DISPLAY"):
        return "x11"
    kind = (env.get("XDG_SESSION_TYPE") or "").lower()
    return kind if kind in ("wayland", "x11") else ""


def available_memory_gb(meminfo: str = "/proc/meminfo") -> Optional[float]:
    try:
        for line in Path(meminfo).read_text().splitlines():
            if line.startswith("MemAvailable:"):
                return int(line.split()[1]) / 1024 / 1024
    except (OSError, ValueError, IndexError):
        pass
    return None


def cpu_count() -> int:
    try:
        return len(os.sched_getaffinity(0))  # the cores this process may use (containers, taskset)
    except (AttributeError, OSError):
        return os.cpu_count() or 1


def mercury_caps() -> dict:
    """Per-minute caps for the first text model's account: documented × safety, lowered by what the budget
    learned from refusals (this session or an earlier one)."""
    mcfg = settings().get("mercury", {}) or {}
    m = (settings().get("text_models") or [{}])[0]
    return ratelimit.effective_caps(f"{m.get('base_url', '')}|{m.get('key_env', '')}", mcfg)


def ceilings(cpus: Optional[int] = None, mem_gb: Optional[float] = None, limits: Optional[dict] = None,
             safety: Optional[float] = None, running: int = 0) -> dict:
    cpus = cpu_count() if cpus is None else cpus
    mem_gb = available_memory_gb() if mem_gb is None else mem_gb
    mcfg = settings().get("mercury", {}) or {}
    safety = float(mcfg.get("safety", 0.8)) if safety is None else safety
    out = {"cores": max(1, cpus - 1)}
    if mem_gb is not None:
        # Running tasks already hold their memory: the ceiling is those plus what the rest can still hold.
        out["memory"] = max(1, running + int(max(0.0, mem_gb - RESERVE_GB) / PER_TASK_GB))
    caps = mercury_caps() if limits is None else {k: v * safety for k, v in limits.items()}
    out["mercury"] = max(1, int(min(caps[k] / PER_TASK_MIN[k] for k in PER_TASK_MIN)))
    out["max_auto"] = MAX_AUTO
    return out


def parallel_tasks(value=None, running: int = 0) -> int:
    """``parallel_tasks`` as a number: an explicit setting wins; ``auto`` (default) is the smallest ceiling.
    ``running``: tasks already started (their memory is already in use)."""
    value = settings().get("parallel_tasks", "auto") if value is None else value
    if str(value).strip().lower() != "auto":
        try:
            return max(1, int(value))
        except (TypeError, ValueError):
            pass
    return max(1, min(ceilings(running=running).values()))


def headless_wanted(setting=None, env: Optional[dict] = None) -> bool:
    """``chrome.headless``: true/false, or ``auto`` = visible windows only when a desktop session is present."""
    setting = settings().get("chrome.headless", True) if setting is None else setting
    if isinstance(setting, str) and setting.strip().lower() == "auto":
        return not desktop_session(env)
    if isinstance(setting, str):
        return setting.strip().lower() not in ("false", "no", "0", "off")
    return bool(setting)


def is_root() -> bool:
    return hasattr(os, "geteuid") and os.geteuid() == 0


def summary() -> dict:
    rel = os_release()
    return {"os": rel.get("PRETTY_NAME") or sys.platform, "ubuntu": rel.get("ID") == "ubuntu",
            "version": rel.get("VERSION_ID", ""), "session": desktop_session() or "none",
            "kind": "desktop" if desktop_session() else "server", "root": is_root(), "cpus": cpu_count(),
            "available_memory_gb": round(available_memory_gb() or 0, 1),
            "parallel_ceilings": ceilings(), "parallel_tasks": parallel_tasks()}
