"""Answer validation, the one-request fan-out, and the shuffled-order check."""

import random

import pytest

from conftest import answers_for, choice, make_page, noul
from swift import jev


@pytest.mark.parametrize("mutation", ["unknown", "nan", "missing", "extra", "negative", "non_max", "confidence",
                                      "sum", "string", "none"])
def test_invalid_choice_is_rejected(mutation):
    a = choice(["a", "b"], "a")
    if mutation == "unknown":
        a["choice"] = "invented"
    elif mutation == "nan":
        a["probabilities"]["a"] = float("nan")
    elif mutation == "missing":
        del a["probabilities"]["b"]
    elif mutation == "extra":
        a["probabilities"]["c"] = 0.0
    elif mutation == "negative":
        a["probabilities"]["b"] = -1
    elif mutation == "non_max":
        a["choice"] = "b"
    elif mutation == "confidence":
        a["confidence"] = 5
    elif mutation == "sum":
        a["probabilities"] = {"a": 0.9, "b": 0.9}
    elif mutation == "string":
        a["probabilities"]["a"] = "1"
    else:
        a = None
    with pytest.raises(jev.InvalidAnswer):
        jev.validate_choice(a, {"a", "b"})


@pytest.mark.parametrize("value", [1.5, -0.1, float("inf"), "0.9", None])
def test_invalid_noul_is_rejected(value):
    with pytest.raises(jev.InvalidAnswer):
        jev.validate_noul({"noul": value})


def test_valid_noul():
    assert jev.validate_noul(noul(0.98)) == 0.98


def test_one_index_per_node_with_operation_specific_targets():
    elements, targets, controls = jev.action_space(make_page()["actions"])
    assert len(elements) == 2
    assert elements[0]["operations"] == ["TYPE_TEXT", "CLICK"]
    assert targets["TYPE_TEXT"]["1"]["id"] == "e1"
    assert targets["CLICK"]["1"]["id"] == "e2"
    assert targets["CLICK"]["2"]["id"] == "e3"
    assert "WAIT" in controls


def test_every_question_is_one_request():
    calls = []

    def post(body):
        calls.append(body)
        return answers_for(body, "CLICK", "2")

    client = jev.JevClient(post=post)
    d = jev.decide(client, make_page(), "Search for books", "Find a book", [])
    assert len(calls) == 1
    q = set(calls[0]["questions"])
    assert {"operation", "click_target", "type_text_target", "subgoal_done", "last_action_worked",
            "still_loading", "blocker_present", "risk_level"} <= q
    assert calls[0]["model"] == "jev-1.14.0"
    assert d["choice"] == "e3" and d["operation"] == "CLICK" and d["agree"] is None


def test_unused_target_head_cannot_cause_an_action():
    def post(body):
        reply = answers_for(body, "CLICK", "2")
        reply["answers"]["type_text_target"] = {"choice": "invented"}
        return reply

    d = jev.decide(jev.JevClient(post=post), make_page(), "s", "g", [])
    assert d["choice"] == "e3"


def test_invalid_selected_head_executes_nothing():
    def post(body):
        reply = answers_for(body, "CLICK", "2")
        reply["answers"]["click_target"] = choice(["1", "2", "999"], "999")
        return reply

    with pytest.raises(jev.InvalidAnswer):
        jev.decide(jev.JevClient(post=post), make_page(), "s", "g", [])


def test_missing_answers_are_invalid():
    with pytest.raises(jev.InvalidAnswer):
        jev.JevClient(post=lambda body: {"model": "jev-1.14.0"}).ask({}, {})


def test_shuffled_check_sends_twin_with_reordered_options_and_agrees():
    bodies = []

    def post(body):
        bodies.append(body)
        return answers_for(body, "CLICK", "2")

    client = jev.JevClient(post=post)
    d = jev.decide(client, make_page(), "s", "g", [], shuffled_check=True, seed=3)
    assert len(bodies) == 2
    assert d["agree"] is True
    twin = next(b for b in bodies if "subgoal_done" not in b["questions"])
    live = next(b for b in bodies if "subgoal_done" in b["questions"])
    assert set(twin["questions"]["operation"]["criteria"]) == set(live["questions"]["operation"]["criteria"])


def test_shuffled_check_disagreement_is_reported():
    def post(body):
        target = "2" if "subgoal_done" in body["questions"] else "1"
        return answers_for(body, "CLICK", target)

    d = jev.decide(jev.JevClient(post=post), make_page(), "s", "g", [], shuffled_check=True, seed=1)
    assert d["agree"] is False


def test_shuffle_really_reorders():
    page = make_page()
    _, _, _, ops, _ = jev.build_questions(page, "s", "g")
    orders = {tuple(jev.build_questions(page, "s", "g", shuffle=random.Random(i))[3]) for i in range(12)}
    assert len(orders) > 1 and all(set(o) == set(ops) for o in orders)


@pytest.mark.parametrize("label,kind,role,risk", [
    ("Place order", "click", "button", "irreversible"),
    ("Submit registration", "click", "button", "irreversible"),
    ("Pay ₹499", "click", "button", "irreversible"),
    ("Search", "fill", "textbox", "reversible"),
    ("Free cancellation", "click", "checkbox", "reversible"),
    ("Next page", "click", "link", "read_only"),
])
def test_code_risk_floor(label, kind, role, risk):
    assert jev.code_risk({"label": label, "kind": kind, "role": role}) == risk


def test_code_risk_raises_a_low_jev_risk():
    page = make_page([{"id": "e1", "kind": "click", "label": "Place order", "role": "button", "node": 5},
                      {"id": "wait", "kind": "wait", "label": "Wait"}])
    d = jev.decide(jev.JevClient(post=lambda b: answers_for(b, "CLICK", "1", risk="read_only")), page, "s", "g", [])
    assert d["jev_risk"] == "read_only" and d["risk"] == "irreversible"


def test_priority_gate_admits_live_before_speculative():
    import threading
    import time

    gate = jev._PriorityGate(1)
    order = []
    gate.acquire(0)

    def worker(p, name):
        gate.acquire(p)
        order.append(name)
        time.sleep(0.01)
        gate.release()

    threads = [threading.Thread(target=worker, args=(2, "spec")), threading.Thread(target=worker, args=(1, "check")),
               threading.Thread(target=worker, args=(0, "live"))]
    for t in threads:
        t.start()
        time.sleep(0.05)
    gate.release()
    for t in threads:
        t.join(2)
    assert order == ["live", "check", "spec"]


def test_missing_key_executes_nothing():
    with pytest.raises(jev.JevUnavailable):
        jev.JevClient(api_key="").ask({}, {"q": {"type": "noul", "instructions": "x"}})


def test_secrets_are_scrubbed_from_jev_state():
    from swift import redact

    redact.register("999941057058")
    seen = []
    jev.JevClient(post=lambda body: seen.append(body) or {"answers": {"q": noul(0.1)}}).noul(
        {"page": {"text": "Aadhaar 9999 4105 7058 on file"}}, "Is it?")
    assert "4105" not in str(seen[0]["state"])
