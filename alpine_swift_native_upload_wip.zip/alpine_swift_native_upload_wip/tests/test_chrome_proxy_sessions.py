"""URL safety, task ownership, and identity CLI contracts (offline)."""
import pytest
from conftest import FakeCDP
from swift import config, urlsafety
from swift.sessions import TabRegistry, mask_account, site_of

@pytest.mark.parametrize("url,ok", [
    ("https://example.com/", True), ("http://169.254.169.254/latest/meta-data", False),
    ("http://127.0.0.1:9222/json", False), ("http://localhost:8766/", False), ("http://10.0.0.5/", False),
    ("file:///etc/passwd", False), ("javascript:alert(1)", False), ("about:blank", True),
])
def test_private_and_odd_urls_refused(url, ok):
    assert (urlsafety.check(url, resolve=False) is None) is ok


def test_private_urls_allowed_only_by_setting():
    config.configure({"allow_private_urls": True})
    assert urlsafety.check("http://127.0.0.1:8080/form.html", resolve=False) is None
    assert urlsafety.check("file:///etc/passwd", resolve=False) is not None


def test_task_owns_only_its_tabs_and_adopts_its_popups():
    cdp = FakeCDP()
    reg = TabRegistry(cdp, mode="default")
    reg.start("a")
    reg.start("b")
    ta, tb = reg.new_tab("a"), reg.new_tab("b")
    cdp.targets = [{"targetId": ta.target_id, "type": "page"}, {"targetId": tb.target_id, "type": "page"},
                   {"targetId": "P1", "type": "page", "openerId": ta.target_id},
                   {"targetId": "P2", "type": "page", "openerId": "P1"},
                   {"targetId": "X", "type": "page", "openerId": "someone-else"}]
    adopted = reg.adopt_popups("a")
    assert {t.target_id for t in adopted} == {"P1", "P2"}
    assert reg.owns("a", "P2") and not reg.owns("b", "P1") and reg.owner("X") is None


def test_verified_success_closes_tabs_failure_keeps_them_for_ttl():
    cdp = FakeCDP()
    reg = TabRegistry(cdp, mode="default")
    reg.start("ok")
    reg.start("bad")
    reg.new_tab("ok")
    bad_tab = reg.new_tab("bad")
    cdp.targets = [{"targetId": bad_tab.target_id, "type": "page"}]
    reg.finish("ok", verified=True)
    reg.finish("bad", verified=False)
    assert reg.tasks["ok"].status == "closed" and not reg.tasks["ok"].tabs
    assert reg.tasks["bad"].status == "failed_kept" and reg.tasks["bad"].tabs
    assert reg.sweep(ttl_minutes=30) == []
    cdp.targets = []
    assert reg.sweep(ttl_minutes=0) == ["bad"]


def test_context_mode_is_rejected_without_creating_a_browser_context():
    cdp = FakeCDP()
    reg = TabRegistry(cdp, mode="context")
    with pytest.raises(RuntimeError, match="shared|isolated"):
        reg.start("a")
    assert not cdp.methods("Target.createBrowserContext")


def test_account_masking_and_site_keys():
    assert mask_account("asha@example.in") == "a•••@example.in"
    assert site_of("https://www.irctc.co.in/nget") == "irctc.co.in"


def test_identity_cli_reads_value_from_hidden_prompt(monkeypatch, capsys):
    from swift import identity

    monkeypatch.setattr("getpass.getpass", lambda prompt="": "9999 4105 7058")
    assert identity.main(["add", "aadhaar", "--domains", "uidai.gov.in"]) == 0
    out = capsys.readouterr().out
    assert "7058" in out and "999941057058" not in out
    assert identity.main(["list"]) == 0
    assert "999941057058" not in capsys.readouterr().out
