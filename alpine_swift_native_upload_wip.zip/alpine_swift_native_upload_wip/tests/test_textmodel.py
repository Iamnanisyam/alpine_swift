"""Text-model contract: exact keys, fallback order, hedging, no secrets in requests (offline)."""

import json
import time

import pytest

from swift import redact
from swift.textmodel import TextModel, TextModelError, check_schema, validate_reply

MODELS = [{"model": "m1", "base_url": "https://a.invalid/v1", "key_env": "X", "response_format": "json_schema"},
          {"model": "m2", "base_url": "https://b.invalid/v1", "key_env": "Y"}]


def reply(obj):
    return {"choices": [{"message": {"content": json.dumps(obj)}}]}


def test_exact_keys_required():
    assert validate_reply({"1": "a", "2": None}, ["1", "2"]) == {"1": "a", "2": None}
    for bad in ({"1": "a"}, {"1": "a", "2": None, "3": "x"}, {"1": 5, "2": None}, ["a"], None):
        with pytest.raises(TextModelError):
            validate_reply(bad, ["1", "2"])


def test_first_model_wins_and_schema_is_strict():
    bodies = []

    def post(m, body):
        bodies.append((m["model"], body))
        return reply({"1": "Lisbon"})

    tm = TextModel(models=MODELS, post=post)
    assert tm.fill({"1": {"label": "Destination"}}, {"goal": "Lisbon"}) == {"1": "Lisbon"}
    assert bodies[0][0] == "m1"
    fmt = bodies[0][1]["response_format"]
    assert fmt["type"] == "json_schema" and fmt["json_schema"]["strict"] is True
    assert fmt["json_schema"]["schema"]["required"] == ["1"]


def test_wrong_keys_fall_back_to_next_model():
    def post(m, body):
        return reply({"9": "x"}) if m["model"] == "m1" else reply({"1": "Lisbon"})

    tm = TextModel(models=MODELS, post=post)
    assert tm.fill({"1": {"label": "Destination"}}, {}) == {"1": "Lisbon"}
    assert [c["ok"] for c in tm.calls] == [False, True]


def test_all_models_failing_raises_and_types_nothing():
    tm = TextModel(models=MODELS, post=lambda m, b: reply({"bad": 1}))
    with pytest.raises(TextModelError):
        tm.fill({"1": {"label": "x"}}, {})


def test_slow_first_model_is_hedged(monkeypatch):
    from swift import config

    config.configure({"text_hedge_s": 0.05})

    def post(m, body):
        if m["model"] == "m1":
            time.sleep(0.5)
            return reply({"1": "slow"})
        return reply({"1": "fast"})

    tm = TextModel(models=MODELS, post=post)
    started = time.perf_counter()
    out = tm.fill({"1": {"label": "x"}}, {})
    # The preferred model still wins when it answers validly; hedging only starts the second one early.
    assert out == {"1": "slow"}
    assert time.perf_counter() - started < 1.9  # well under the 2 s per-model timeout, with room for a loaded CI host


def test_failed_first_model_returns_second_without_waiting_for_timeout():
    from swift import config

    config.configure({"text_hedge_s": 0.05})

    def post(m, body):
        if m["model"] == "m1":
            raise TextModelError("HTTP 500")
        return reply({"1": "ok"})

    assert TextModel(models=MODELS, post=post).fill({"1": {"label": "x"}}, {}) == {"1": "ok"}


def test_registered_secrets_never_reach_the_model():
    redact.register("ABCDE1234F")
    seen = []
    tm = TextModel(models=MODELS[:1], post=lambda m, b: seen.append(b) or reply({"1": None}))
    tm.fill({"1": {"label": "Name"}}, {"goal": "my PAN is ABCDE1234F", "page": {"text": "PAN ABCDE1234F"}})
    assert "ABCDE1234F" not in json.dumps(seen)


class _Result:
    parsed, provider, model, text = {"ok": "yes"}, "custom", "some-model", ""


class _LLM:
    def __init__(self):
        self.calls = 0

    def complete_structured(self, **kw):
        self.calls += 1
        return _Result()


def test_mercury_is_the_only_model_unless_hermes_fallback_is_enabled():
    from swift import config

    planner = [{"model": "mercury-3", "key_env": "", "base_url": "x"}]
    llm = _LLM()
    config.configure({})  # default hermes_model: off
    tm = TextModel(models=[], planner_models=planner, llm=llm, post=lambda m, b: reply({"ok": "mercury"}))
    assert tm.plan("sys", {"q": 1}, {"type": "object", "required": ["ok"]}) == {"ok": "mercury"}
    assert llm.calls == 0 and tm.calls[-1]["model"] == "mercury-3"

    failing = TextModel(models=[], planner_models=planner, llm=llm, post=lambda m, b: reply({}))
    with pytest.raises(TextModelError):
        failing.plan("sys", {"q": 1}, {"type": "object", "required": ["ok"]})
    assert llm.calls == 0  # off: never Hermes's model, even when Mercury fails

    config.configure({"hermes_model": "fallback"})
    try:
        with pytest.raises(TextModelError):
            failing.plan("sys", {"q": 1}, {"type": "object", "required": ["ok"]})
        assert llm.calls == 0
    finally:
        config.configure({})


def test_defaults_name_mercury_3_only():
    from swift import config

    config.configure({})
    names = {m["model"] for m in config.settings().get("text_models") + config.settings().get("planner_models")}
    assert names == {"mercury-3"}
    assert all("inceptionlabs.ai" in m["base_url"] for m in config.settings().get("text_models"))


def test_plan_caps_the_output_it_reserves():
    bodies = []
    tm = TextModel(models=[], planner_models=[{"model": "mercury-3", "key_env": "", "base_url": "x",
                                               "max_tokens": 1500, "reasoning_effort": "low"}],
                   post=lambda m, b: bodies.append(b) or reply({"ok": "1"}))
    tm.plan("sys", {}, {"type": "object"}, max_tokens=500, fast=True)
    assert bodies[-1]["max_tokens"] == 500 and bodies[-1]["reasoning_effort"] == "instant"
    tm.plan("sys", {}, {"type": "object"})
    assert bodies[-1]["max_tokens"] == 1500 and bodies[-1]["reasoning_effort"] == "low"


def test_planner_output_is_schema_checked():
    schema = {"type": "object", "required": ["subgoals"],
              "properties": {"subgoals": {"type": "array", "minItems": 1, "items": {"type": "object",
                                          "required": ["risk"], "properties": {"risk": {"enum": ["a", "b"]}}}}}}
    check_schema({"subgoals": [{"risk": "a"}]}, schema)
    for bad in ({}, {"subgoals": []}, {"subgoals": [{"risk": "z"}]}, {"subgoals": "x"}):
        with pytest.raises(TextModelError):
            check_schema(bad, schema)
