# Production readiness review — work in progress

Do not deploy this archive as production-ready. It is a partially hardened copy of the supplied project, not a completed implementation of the requested architecture.

## Changes in this copy

- `swift/cloak.py`: always passes `headless=False`; requires a display; checks `/json/version` and fails closed unless Chromium reports major version 155 or later. The existing persistent profile and stable seed are retained.
- `tests/test_cloak_session.py`: adds a regression test for forced headed launch and humanize/geoip options. The test suite was not run in this environment because pytest is unavailable.
- No tools, schemas, or code paths were removed in this partial pass. They should be removed only along with their callers and tests during the architecture migration.

## Release blockers

1. `swift/page.py` and `swift/mouse.py` send CDP input directly. Cloak's `humanize=True` patches the launcher-side Playwright wrapper; it does not humanize those direct CDP events. Replace all action input paths with the documented Cloak patched Playwright connection or execute through the owning patched context. Verify click, typing, select and scroll on the actual connected pages. Remove the custom mouse after all consumers are migrated.
2. The current implementation uses its own Jev loop; browser-use is an optional fallback, not the primary CDP integration. Reconcile the action executor and remove unused tools, schemas, forms, fallback paths and associated tests only after tracing dependencies. Existing risk checks and secrets handling must not silently disappear.
3. CAPTCHA/OTP handling returns control rather than automatically monitoring and resuming. Implement a pause state with same-page observation and safe re-observation after manual resolution; do not replay a pending action. Prove on a real challenge and OTP fixture in the same profile.
4. No cursor action/result label is implemented. Inject a non-interactive, `pointer-events:none` overlay on every page and frame where supported. Ensure it updates from the actual executor, does not expose entered text or secrets, and is excluded from snapshots and screenshots sent to models. The system cursor must also be visible in the VNC server; DOM injection alone cannot guarantee a native cursor.
5. Jev operation/target heads are combined in `swift/jev.py`, but this project also makes extra risk, planning, review and other model calls. Mercury is used for more than TYPE_TEXT. Images and Box are not wired. TypeSafe documents Images/Box as experimental; do not blindly click model-generated coordinates. Preserve observed-node, freshness, occlusion, and independent outcome checks.
6. The supplied installer requires a proxy and sets up its existing live-view approach; inspect it before use. A proper VNC/noVNC deployment, authentication, binding, and firewall need separate verification. Exposing CDP or VNC publicly is unsafe.
7. Verify the installed Cloak wrapper and Pro license deliver Chromium 155+, proxy geo-location, stable profile, and real humanized input. The new version check is not proof of a genuine Cloak binary or complete stealth. Test real devices and target sites; no detection or speed guarantee is possible.
8. Run the complete offline tests and then end-to-end tests with a real display, VNC, browser, and both model credentials. Exercise restart persistence, second-launch exclusion, many tabs, stale targets, disconnects, prompt injection, privacy, CAPTCHA/OTP pause/resume, malformed model responses, and failed outcomes. Benchmark against a fixed baseline.

## Existing wiring and setup

The original defaults use `https://api.inceptionlabs.ai/v1`, model `mercury-3`, and `INCEPTION_API_KEY` in `swift/config.py`. They are configurable and not forced. The TypeSafe endpoint is `https://api.typesafe.ai/v1/systemone`, default model `jev-1.14.0`, key `TYPESAFE_API_KEY`. Jev validates the response before execution. Actual model availability, context length, schema support, and parallel tool calls have not been verified against either account. The 1M context length is a model/provider property, not an argument to the chat completions API.

On an Ubuntu machine with Python and a display, to run offline validation without starting a browser:

```bash
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-dev.txt
python -m pytest tests -q
python -m pyflakes swift tests __init__.py
node --check swift/snapshot.js
bash -n deploy/install-ubuntu.sh
```

Read `CLOAK_SETUP.md` and the installer before attempting a live deployment. Existing setup uses one mandatory static proxy and a non-root user. The new 155 check requires a compatible licensed binary. No secrets are included.

Upstream references:
- https://github.com/CloakHQ/CloakBrowser
- https://github.com/CloakHQ/CloakBrowser/releases
- https://github.com/CloakHQ/CloakBrowser-Agent
- https://github.com/browser-use/jev-ultrafast
- https://www.inceptionlabs.ai/blog/introducing-mercury-3
