"""Logins, cards and addresses through Hermes's own ``browser_vault`` tool, on the same task.

Hermes binds every item to its exact origin, asks the user to confirm each card fill, refuses card fills
in headless sessions, and registers filled values with its redaction boundary. Nothing here patches
around that; we only choose a handle and dispatch ``fill``. Hermes points its supervisor's one page session
at the first tab on the item's origin that holds the form (``focus_page``) and then runs the fill there. That
session is shared by every browse() task of the Hermes task, so fills are serialised across ALL origins
(measured: two parallel fills on different sites raced, and Hermes's own origin re-check refused one with
"navigated away from the bound origin ... now on <the other site>"; nothing was written). Afterwards we
confirm that *our* tab's field received a value (without reading it).
"""

from __future__ import annotations

import json
import threading
from typing import Any, Callable, Optional
from urllib.parse import urlsplit

_FILL_LOCK = threading.Lock()  # one supervisor page session per Hermes task: one fill at a time (module doc)
KIND_FOR_SENSITIVE = {"password": "login", "card": "payment"}


class VaultError(RuntimeError):
    pass


def origin_of(url: str) -> str:
    p = urlsplit(url)
    default = {"http": 80, "https": 443}.get(p.scheme)
    port = f":{p.port}" if p.port and p.port != default else ""
    return f"{p.scheme}://{(p.hostname or '').lower()}{port}"


class VaultFill:
    def __init__(self, dispatch: Optional[Callable[[str, dict], Any]],
                 before_fill: Optional[Callable[[str, str], list]] = None):
        self.dispatch = dispatch
        # (origin, our tab id) -> closes other tabs of ours that would take the fill (see TabRegistry)
        self.before_fill = before_fill

    def _call(self, args: dict) -> dict:
        if self.dispatch is None:
            raise VaultError("Hermes's browser_vault is only available inside Hermes")
        raw = self.dispatch("browser_vault", args)
        try:
            return json.loads(raw) if isinstance(raw, str) else dict(raw or {})
        except (ValueError, TypeError):
            return {"success": False, "error": "unreadable browser_vault reply"}

    def list(self) -> list[dict]:
        reply = self._call({"action": "list"})
        items = reply.get("items") or reply.get("handles") or reply.get("logins") or []
        return [i for i in items if isinstance(i, dict)]

    def login_identifier(self, url: str) -> Optional[str]:
        """The saved login's identifier (username or email) for this origin. Hermes lists it as non-secret
        metadata for the agent to type itself; the password is filled only by ``fill``."""
        origin = origin_of(url)
        for item in self.list():
            origins = item.get("allowed_origins") or ([item["origin"]] if item.get("origin") else [])
            if item.get("kind") == "login" and origin in origins and item.get("identifier"):
                return str(item["identifier"])
        return None

    def handle_for(self, kind: str, url: str) -> Optional[str]:
        origin = origin_of(url)
        for item in self.list():
            if item.get("kind") != kind or not item.get("available", True):
                continue
            origins = item.get("allowed_origins") or ([item["origin"]] if item.get("origin") else [])
            if origin in origins:
                return item.get("handle")
        return None

    def fill(self, kind: str, page, obs: dict, probe_node: Optional[int] = None) -> dict:
        """Resolve an origin-bound login locally; input uses the plugin's patched page.

        Payment remains guarded by Hermes approval and is not inferred from a
        free-form field label. No secret is returned through tool dispatch.
        """
        from . import redact
        if kind not in ('login', 'payment', 'address'):
            return {'success': False, 'error': 'Unsupported vault item kind'}
        if type(probe_node) is not int:
            return {'success': False, 'error': 'An observed password field is required'}
        origin = origin_of(obs.get('url', ''))
        handle = self.handle_for(kind, obs.get('url', ''))
        if not handle:
            return {'success': False, 'needs_user': 'No origin-bound login is available'}
        try:
            from agent.vault_backends import backend_for_handle
            from agent.redact import register_vault_redaction_value
            from agent.vault_login_classifier import (LoginControl, classify_login_control,
                                                       classify_checkout_control, select_checkout_fills)
            from agent.vault_store import PAYMENT_FIELDS, ADDRESS_FIELDS
            from tools.browser_vault_context import saved_origins, snapshot_refusal
            backend = backend_for_handle(handle)
            if backend is None:
                return {'success': False, 'needs_user': 'Vault backend is unavailable'}
            if backend.needs_unlock and not backend.is_unlocked():
                return {'success': False, 'needs_user': 'Unlock the vault before filling'}
            meta = backend.get_meta(handle)
            if meta is None or meta.kind != kind or origin not in saved_origins(meta):
                return {'success': False, 'error_type': 'origin_mismatch', 'error': 'Vault item is not bound to this origin'}
            descriptor = page.vault_descriptor(probe_node)
            if not descriptor:
                return {'success': False, 'error': 'Observed field is unavailable'}
            control = LoginControl.from_dict(descriptor)
            classified = classify_login_control(control) if kind == 'login' else classify_checkout_control(control)
            if not classified or (kind == 'login' and classified.token != 'current-password'):
                return {'success': False, 'error': 'Observed field is not a supported vault target'}
            if kind == 'payment':
                from tools.browser_vault_tool import _confirm_payment_fill
                if not _confirm_payment_fill(meta.label, origin):
                    return {'success': False, 'stop': 'payment_declined', 'error_type': 'payment_declined'}
            with _FILL_LOCK, backend.fill_context():
                refusal = snapshot_refusal(backend, handle, meta, origin)
                if refusal:
                    return {'success': False, 'error': 'Vault item changed before filling'}
                if origin_of(page.evaluate('location.href') or '') != origin:
                    return {'success': False, 'error_type': 'origin_changed', 'error': 'Page origin changed before filling'}
                if kind == 'login':
                    value = backend.resolve_password(handle)
                else:
                    values = backend.resolve_secret(handle)
                    fills = select_checkout_fills([classified], values,
                                                  PAYMENT_FIELDS if kind == 'payment' else ADDRESS_FIELDS)
                    value = fills[0].get('value') if len(fills) == 1 else None
                if not isinstance(value, str) or not value:
                    return {'success': False, 'error': 'Vault returned no usable value for this field'}
                redact.register(value)
                register_vault_redaction_value(value)
                # Recheck origin inside the adapter; a navigation discards the tag.
                ok = page.fill_vault_value(probe_node, value, origin,
                                           expected='password' if kind == 'login' else 'card' if kind == 'payment' else 'address')
                return {'success': bool(ok), 'filled_fields': int(bool(ok)), 'kind': kind, 'origin': origin}
        except ImportError:
            return {'success': False, 'needs_user': 'Hermes vault backend is unavailable'}
        except Exception:
            # Backend and Playwright errors may contain secret values. Never echo them.
            return {'success': False, 'error': 'Vault fill failed; no details were logged'}


def payment_declined(text: str) -> bool:
    t = (text or "").lower()
    return any(p in t for p in ("payment declined", "card declined", "transaction declined", "payment failed",
                                "transaction failed", "insufficient funds"))
