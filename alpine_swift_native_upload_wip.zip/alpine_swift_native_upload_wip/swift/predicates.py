"""Code-checkable success predicates. A subgoal is verified only when its predicate passes.

    {"url_contains": "...", "url_matches": "regex", "text_visible": ["..."], "text_absent": ["..."],
     "fields": {"label substring": "expected value"}, "title_contains": "..."}

All present keys must pass. An empty predicate never passes: Jev's DONE alone never counts.
"""

from __future__ import annotations

import re
import unicodedata
from datetime import datetime
from typing import Any, Optional
from urllib.parse import unquote

KEYS = ("url_contains", "url_matches", "text_visible", "text_absent", "fields", "title_contains")
TRUE_WORDS = {"true", "checked", "on", "yes", "enabled", "selected", "ticked", "1"}
FALSE_WORDS = {"false", "unchecked", "off", "no", "disabled", "unselected", "unticked", "0"}
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%m/%d/%Y", "%d %b %Y", "%d %B %Y", "%B %d, %Y",
                "%b %d, %Y", "%d %B, %Y")


def norm(s: Any) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.replace("’", "'").replace("‘", "'").replace("“", '"').replace("”", '"')
    return re.sub(r"\s+", " ", s).strip().casefold()


def clean(pred: Optional[dict]) -> dict:
    """Keep only known keys with usable values (planner output is untrusted)."""
    out: dict = {}
    for key in KEYS:
        value = (pred or {}).get(key)
        if value in (None, "", [], {}):
            continue
        if key in ("text_visible", "text_absent"):
            value = [str(v) for v in (value if isinstance(value, list) else [value]) if str(v).strip()][:10]
            if not value:
                continue
        elif key == "fields":
            if not isinstance(value, dict):
                continue
            value = {str(k): str(v) for k, v in list(value.items())[:20] if str(k).strip()}
            if not value:
                continue
        elif key == "url_matches":
            try:
                re.compile(str(value))
            except re.error:
                continue
            value = str(value)[:300]
        else:
            value = str(value)[:300]
        out[key] = value
    return out


def full_text(page_obj) -> str:
    """The whole document's visible text (the snapshot only carries the viewport)."""
    try:
        return page_obj.evaluate("document.body ? document.body.innerText.slice(0, 200000) : ''") or ""
    except Exception:
        return ""


def field_values(page_obj, obs: dict) -> dict[str, str]:
    """Label → committed value for every field in the snapshot (sensitive values stay masked)."""
    out: dict[str, str] = {}
    seen = set()
    for a in obs.get("actions", []):
        if a.get("kind") not in ("fill", "select", "click") or a.get("node") in seen:
            continue
        if a.get("kind") == "click" and a.get("role") not in ("combobox", "checkbox", "radio", "switch"):
            continue
        seen.add(a["node"])
        label = a["label"].split(" → ")[0]
        if label.startswith("Open "):
            label = label[5:]
        value = a.get("current_value") if a.get("kind") == "select" else a.get("value")
        if a.get("role") in ("checkbox", "radio", "switch"):
            value = a.get("checked", "")
        if a.get("sensitive"):
            value = "[masked]" if value else ""
        out[label] = "" if value is None else str(value)
    return out


def selected_options(obs: dict) -> set[str]:
    """Normalised labels of the options currently chosen in dropdowns (native and custom)."""
    chosen = set()
    for a in obs.get("actions", []):
        if a.get("kind") == "select" and a.get("selected_value") and a.get("current_value"):
            chosen.add(norm(a["current_value"]))
        elif a.get("role") == "combobox" and a.get("kind") == "click" and a.get("value"):
            chosen.add(norm(a["value"]))
    return chosen


def known_labels(obs: dict) -> set[str]:
    """Every control label and option label on the page (to tell a wrong check from an unmet one)."""
    out = set()
    for a in obs.get("actions", []):
        label = a.get("label", "")
        for part in label.split(" → "):
            out.add(norm(part[5:] if part.startswith("Open ") else part))
    for d in obs.get("disabled_fields", []):
        out.add(norm(d.get("label")))
    return {x for x in out if x}


def unknown_field_checks(pred: Optional[dict], obs: dict) -> list[str]:
    """``fields`` labels in ``pred`` that match no control or option on the page."""
    labels = known_labels(obs)
    return [k for k in (clean(pred).get("fields") or {}) if not any(norm(k) in lab for lab in labels)]


def _as_bool(s: str) -> Optional[str]:
    if s in TRUE_WORDS:
        return "true"
    if s in FALSE_WORDS:
        return "false"
    return None


def _as_date(s: str) -> Optional[str]:
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(s.strip(), fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def same_value(want: str, got: str) -> bool:
    """Expected vs committed value, tolerant of formatting (masks, dates, checkbox words)."""
    w, g = norm(want), norm(got)
    if w == g or (w and w in g):
        return True
    if _as_bool(w) is not None and _as_bool(w) == _as_bool(g):
        return True
    wd, gd = re.sub(r"\D", "", w), re.sub(r"\D", "", g)
    if len(wd) >= 6 and wd == gd and len(re.sub(r"[\d\s()+\-./]", "", w)) == 0:
        return True
    if (dw := _as_date(want)) and dw == _as_date(got):
        return True
    return False


def _urls(url: str) -> list[str]:
    return [url, unquote(url)]


def check(pred: Optional[dict], obs: dict, page_obj=None) -> dict:
    """Return {"passed": bool, "failed": [...], "checked": [...]}"""
    pred = clean(pred)
    failed, checked = [], []
    if not pred:
        return {"passed": False, "failed": ["no predicate"], "checked": []}
    url = obs.get("url", "")
    if "url_contains" in pred:
        checked.append("url_contains")
        if not any(norm(pred["url_contains"]) in norm(u) for u in _urls(url)):
            failed.append("url_contains")
    if "url_matches" in pred:
        checked.append("url_matches")
        if not any(re.search(pred["url_matches"], u) for u in _urls(url)):
            failed.append("url_matches")
    if "title_contains" in pred:
        checked.append("title_contains")
        if norm(pred["title_contains"]) not in norm(obs.get("title")):
            failed.append("title_contains")
    if "text_visible" in pred or "text_absent" in pred:
        text = norm(obs.get("text", ""))
        whole = None
        for item in pred.get("text_visible", []):
            checked.append(f"text_visible:{item}")
            if norm(item) in text:
                continue
            if whole is None:
                whole = norm(full_text(page_obj)) if page_obj is not None else ""
            if norm(item) not in whole:
                failed.append(f"text_visible:{item}")
        for item in pred.get("text_absent", []):
            checked.append(f"text_absent:{item}")
            if whole is None:
                whole = norm(full_text(page_obj)) if page_obj is not None else text
            if norm(item) in whole or norm(item) in text:
                failed.append(f"text_absent:{item}")
    if "fields" in pred:
        values = {norm(k): v for k, v in field_values(page_obj, obs).items()}
        chosen = None
        for label, expected in pred["fields"].items():
            checked.append(f"field:{label}")
            hits = [v for k, v in values.items() if norm(label) in k]
            if any(same_value(expected, v) for v in hits):
                continue
            # {"Design": "true"}: an option named exactly "Design" is the current choice of a dropdown.
            if _as_bool(norm(expected)) == "true":
                chosen = selected_options(obs) if chosen is None else chosen
                if norm(label) in chosen:
                    continue
            failed.append(f"field:{label}")
    return {"passed": not failed, "failed": failed, "checked": checked}


def items(pred: Optional[dict]) -> list[tuple]:
    """A predicate as independent, hashable checks."""
    out = []
    for key, value in clean(pred).items():
        if key in ("text_visible", "text_absent"):
            out += [(key, v) for v in value]
        elif key == "fields":
            out += [(key, (k, v)) for k, v in value.items()]
        else:
            out.append((key, value))
    return out


def from_items(checks: list[tuple]) -> dict:
    pred: dict = {}
    for key, value in checks:
        if key in ("text_visible", "text_absent"):
            pred.setdefault(key, [])
            if value not in pred[key]:
                pred[key].append(value)
        elif key == "fields":
            pred.setdefault("fields", {})[value[0]] = value[1]
        else:
            pred[key] = value
    return pred


def merge(base: Optional[dict], override: Optional[dict]) -> dict:
    """Union of two predicates; for single-valued keys ``override`` wins."""
    over = clean(override)
    kept = [c for c in items(base) if not (c[0] in over and c[0] not in ("text_visible", "text_absent", "fields"))
            and not (c[0] == "fields" and c[1][0] in over.get("fields", {}))]
    return from_items(kept + items(over))


def discriminative(pred: Optional[dict], obs: dict, page_obj=None) -> dict:
    """Only the checks that are still false on ``obs``: a check that already passes proves nothing."""
    return from_items([c for c in items(pred) if not check(from_items([c]), obs, page_obj)["passed"]])


def ground(pred: Optional[dict], *sources: Any) -> dict:
    """Keep only planner checks whose text comes from what the user gave (goal, start URL, criteria).
    A planner that guesses page wording ("Count: 3" for a page that says "Clicked 3 times") would otherwise
    block a finished step forever. Field labels are kept: they are checked against the page's own labels."""
    corpus = norm(" ".join(str(s) for s in sources if s))
    kept = []
    for key, value in items(pred):
        if key in ("text_visible", "text_absent", "title_contains", "url_contains"):
            if norm(value) and norm(value) in corpus:
                kept.append((key, value))
        elif key == "url_matches":
            kept.append((key, value)) if norm(value) in corpus else None
        elif key == "fields":
            label, expected = value
            if _as_bool(norm(expected)) is not None or norm(expected) in corpus:
                kept.append((key, value))
    return from_items(kept)


def form_ready(obs: dict, action: Optional[dict]) -> bool:
    """For irreversible steps: every required field in the target's form has a value."""
    if not action:
        return False
    form = action.get("form")
    for a in obs.get("actions", []):
        if form is not None and a.get("form") != form:
            continue
        f = a.get("field") or {}
        if not f.get("required"):
            continue
        value = a.get("selected_value") if "selected_value" in a else a.get("value")
        if f.get("type") in ("checkbox", "radio"):
            value = "" if a.get("checked") in ("false", False, None) else "x"
        if not value:
            return False
    for d in obs.get("disabled_fields", []):
        if (form is None or d.get("form") == form) and (d.get("field") or {}).get("required"):
            return False  # a required dependent dropdown is still disabled
    return True
