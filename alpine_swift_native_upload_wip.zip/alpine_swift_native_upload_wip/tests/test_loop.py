"""Consume-once, stale retries, gates, predicates and the three-no-change stop (all offline)."""

import pytest

from conftest import answers_for, make_page
from swift import jev, loop
from swift.page import StalePage


class FakePage:
    """A scripted page: observations come from a list; act() can raise StalePage on demand."""

    def __init__(self, observations, stale_acts=0, fresh=True):
        self.observations = list(observations)
        self.current = self.observations[0]
        self.acted = []
        self.stale_acts = stale_acts
        self.fresh_value = fresh
        self.tab_id = self.current["tab_id"]
        self.cdp = None

    def observe(self, screenshot=False):
        if len(self.observations) > 1:
            self.current = self.observations.pop(0)
        else:
            self.current = self.observations[0]
        return self.current

    def fresh(self, page, action=None):
        return self.fresh_value and page.get("tab_id") == self.tab_id

    def act(self, action, page, text=None, secret=False):
        if self.stale_acts:
            self.stale_acts -= 1
            raise StalePage("changed")
        self.acted.append(action["id"])
        return {"executed": action["id"]}

    def evaluate(self, expr):
        return self.current.get("text", "")

    def reattach(self):
        pass


def ctx_for(page, post, **kw):
    return loop.LoopContext(page=page, jev=jev.JevClient(post=post), goal="Find a book", trace=None, **kw)


def test_verified_only_by_predicate_and_done_alone_never_counts():
    obs = make_page()
    page = FakePage([obs])
    ctx = ctx_for(page, lambda b: answers_for(b, "DONE"))
    result = loop.FastLoop(ctx, loop.Subgoal("open results", {"text_visible": ["Results for"]})).run()
    assert result.status == loop.BLOCKED and not result.verified
    assert "success check failed" in result.reason
    assert page.acted == []


def test_predicate_passing_verifies_without_any_action():
    page = FakePage([make_page(text="Results for books")])
    ctx = ctx_for(page, lambda b: pytest.fail("no model call needed"))
    result = loop.FastLoop(ctx, loop.Subgoal("s", {"text_visible": ["results for"]})).run()
    assert result.verified and result.status == loop.DONE


def test_three_no_change_actions_stop_the_loop():
    obs = make_page()
    page = FakePage([obs])
    ctx = ctx_for(page, lambda b: answers_for(b, "CLICK", "2"))
    result = loop.FastLoop(ctx, loop.Subgoal("s", {"text_visible": ["never"]})).run()
    assert result.status == loop.BLOCKED and "three consecutive" in result.reason
    assert page.acted == ["e3", "e3", "e3"]


def test_waits_do_not_count_towards_the_no_change_stop():
    ctx = ctx_for(FakePage([make_page()]), lambda b: answers_for(b))
    ctx.history = [{"page_changed": False, "kind": "wait"}] * 3
    assert loop.FastLoop(ctx, loop.Subgoal("s", {"url_contains": "/never-here"})).no_change_stop() is None


def test_stale_page_retries_without_acting_twice():
    first, second = make_page(), make_page(text="Search results loading")
    page = FakePage([first, first, second, second], stale_acts=1)
    calls = []

    def post(body):
        calls.append(body)
        return answers_for(body, "CLICK", "2")

    ctx = ctx_for(page, post, max_steps=2)
    loop.FastLoop(ctx, loop.Subgoal("s", {"text_visible": ["never"]})).run()
    # First decision hit a stale page: nothing executed, a fresh decision was made, then one click.
    assert page.acted.count("e3") <= 1 + (len(calls) - 2)
    assert len(calls) >= 2


def test_consume_once_execute_clears_the_decision():
    page = FakePage([make_page()])
    fl = loop.FastLoop(ctx_for(page, lambda b: answers_for(b, "CLICK", "2")), loop.Subgoal("s", {"url_contains": "/never-here"}))
    d = jev.decide(fl.ctx.jev, page.current, "s", "g", [])
    fl.decision = d
    fl.execute(d, page.current)
    assert fl.decision is None and page.acted == ["e3"]


def test_read_only_low_confidence_reasks_then_hands_to_planner():
    def post(body):
        target = "2" if "subgoal_done" in body["questions"] else "1"
        return answers_for(body, "CLICK", target, confidence=0.3)

    page = FakePage([make_page()])
    result = loop.FastLoop(ctx_for(page, post), loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.LOW_CONFIDENCE and page.acted == []


def test_read_only_low_confidence_acts_when_reask_agrees():
    page = FakePage([make_page()])
    ctx = ctx_for(page, lambda b: answers_for(b, "CLICK", "2", confidence=0.3), max_steps=1)
    loop.FastLoop(ctx, loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert page.acted == ["e3"]


REV_ACTIONS = [{"id": "e1", "kind": "click", "label": "Free cancellation", "role": "checkbox", "node": 3,
                "checked": "false"}, {"id": "e2", "kind": "click", "label": "Pool", "role": "checkbox", "node": 4,
                                      "checked": "false"}, {"id": "wait", "kind": "wait", "label": "Wait"}]


def test_reversible_low_target_confidence_never_acts():
    page = FakePage([make_page(REV_ACTIONS)])
    post = lambda b: answers_for(b, "CLICK", "1", confidence=0.9, target_confidence=0.6, risk="reversible")  # noqa
    result = loop.FastLoop(ctx_for(page, post), loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.LOW_CONFIDENCE and page.acted == []


def test_reversible_disagreeing_shuffled_twin_never_acts():
    def post(body):
        target = "1" if "subgoal_done" in body["questions"] else "2"
        return answers_for(body, "CLICK", target, risk="reversible")

    page = FakePage([make_page(REV_ACTIONS)])
    result = loop.FastLoop(ctx_for(page, post), loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.LOW_CONFIDENCE and page.acted == []


def test_reversible_split_operation_acts_only_after_reask_agrees():
    # Operation 0.45 (two valid orderings), target certain, twins agree: the tuned re-ask path acts once.
    page = FakePage([make_page(REV_ACTIONS)])
    post = lambda b: answers_for(b, "CLICK", "1", confidence=0.45, risk="reversible")  # noqa: E731
    loop.FastLoop(ctx_for(page, post, max_steps=1), loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert page.acted == ["e1"]


def test_reversible_operation_below_tuned_floor_never_acts():
    page = FakePage([make_page(REV_ACTIONS)])
    post = lambda b: answers_for(b, "CLICK", "1", confidence=0.3, risk="reversible")  # noqa: E731
    result = loop.FastLoop(ctx_for(page, post), loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.LOW_CONFIDENCE and page.acted == []


def test_irreversible_never_runs_without_review():
    actions = [{"id": "e1", "kind": "click", "label": "Place order", "role": "button", "node": 3},
               {"id": "wait", "kind": "wait", "label": "Wait"}]
    page = FakePage([make_page(actions)])
    result = loop.FastLoop(ctx_for(page, lambda b: answers_for(b, "CLICK", "1", risk="irreversible")),
                           loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.NEEDS_REVIEW and page.acted == [] and result.pending


def test_irreversible_with_unfilled_required_field_is_not_ready():
    actions = [{"id": "e1", "kind": "fill", "label": "Email", "role": "textbox", "node": 2, "value": "", "form": 1,
                "field": {"required": True, "type": "email"}},
               {"id": "e2", "kind": "click", "label": "Submit", "role": "button", "node": 3, "form": 1},
               {"id": "wait", "kind": "wait", "label": "Wait"}]
    page = FakePage([make_page(actions)])
    result = loop.FastLoop(ctx_for(page, lambda b: answers_for(b, "CLICK", "2", risk="irreversible")),
                           loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.LOW_CONFIDENCE and "ready predicate" in result.reason


def test_risk_ceiling_read_only_refuses_state_changes():
    actions = [{"id": "e1", "kind": "click", "label": "Free cancellation", "role": "checkbox", "node": 3},
               {"id": "wait", "kind": "wait", "label": "Wait"}]
    page = FakePage([make_page(actions)])
    ctx = ctx_for(page, lambda b: answers_for(b, "CLICK", "1", risk="reversible"), risk_ceiling="read_only")
    result = loop.FastLoop(ctx, loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.BLOCKED and page.acted == []


def test_captcha_goes_to_the_user():
    page = FakePage([make_page()])
    result = loop.FastLoop(ctx_for(page, lambda b: answers_for(b, "BLOCKED", blocker="captcha")),
                           loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.NEEDS_USER and result.blocker == "captcha"


def test_invalid_answer_executes_nothing_and_counts_a_step():
    page = FakePage([make_page()])
    result = loop.FastLoop(ctx_for(page, lambda b: {"model": "jev-1.14.0", "answers": {}}, max_steps=2),
                           loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.BUDGET and page.acted == []


def test_stop_control_ends_the_loop_before_acting():
    page = FakePage([make_page()])
    ctx = ctx_for(page, lambda b: answers_for(b, "CLICK", "2"))
    ctx.control.set("stop")
    result = loop.FastLoop(ctx, loop.Subgoal("s", {"url_contains": "/never-here"})).run()
    assert result.status == loop.STOPPED and page.acted == []


def test_step_mode_allows_exactly_one_action():
    import threading

    page = FakePage([make_page()])
    ctx = ctx_for(page, lambda b: answers_for(b, "CLICK", "2"))
    ctx.control.set("pause")
    ctx.control.set("step")
    t = threading.Thread(target=loop.FastLoop(ctx, loop.Subgoal("s", {"url_contains": "/never-here"})).run, daemon=True)
    t.start()
    t.join(1.0)
    assert page.acted == ["e3"]
    ctx.control.set("stop")
    t.join(2)
