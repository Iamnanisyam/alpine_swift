"""URL safety: the plugin drives a browser on the server, so it refuses private and internal addresses
(cloud metadata, the VPS's own services, the debugging port) unless ``allow_private_urls`` is set, the same
policy Hermes applies to its own browser tool."""

from __future__ import annotations

import ipaddress
import socket
from typing import Optional
from urllib.parse import urlsplit

from .config import settings

SCHEMES = ("http", "https")


def _private(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    return (addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved or addr.is_multicast
            or addr.is_unspecified)


def check(url: str, *, resolve: bool = True) -> Optional[str]:
    """None when the URL may be opened, else the reason it may not."""
    parts = urlsplit(url or "")
    if parts.scheme in ("about", "data") and url.startswith(("about:blank", "data:text/html")):
        return None
    if parts.scheme not in SCHEMES:
        return f"scheme {parts.scheme or '(none)'!r} is not allowed"
    host = (parts.hostname or "").strip("[]").lower()
    if not host:
        return "URL has no host"
    if settings().get("allow_private_urls", False):
        return None
    if host in ("localhost", "localhost.localdomain") or host.endswith(".localhost") or host.endswith(".internal"):
        return f"{host} is a private or internal address"
    try:
        if _private(host):
            return f"{host} is a private or internal address"
        return None  # a public IP literal
    except ValueError:
        pass
    if not resolve:
        return None
    try:
        infos = socket.getaddrinfo(host, parts.port or (443 if parts.scheme == "https" else 80),
                                   proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        return None  # the browser will show its own error page
    for info in infos:
        if _private(info[4][0]):
            return f"{host} resolves to a private or internal address"
    return None
