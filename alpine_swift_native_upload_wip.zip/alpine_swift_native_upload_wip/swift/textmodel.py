"""Mercury 3, the plugin's only model: field values (``reasoning_effort: instant``), and the planner, the
irreversible-step reviewer and tiebreaks.

Field values: JSON only, a short timeout per call, and the reply's keys must equal the requested field
indices exactly (each a string or null), otherwise it is rejected. Callers never pass password, card or ID
values; ``redact.scrub`` runs on every request as a second line of defence.

Every call to the Mercury API passes the process-wide rate budget (``swift/ratelimit.py``): parallel tasks wait
for budget instead of drawing HTTP 429. Hermes's own model (``ctx.llm``) is used only when ``hermes_model`` is
``fallback`` and Mercury failed.
"""

from __future__ import annotations

import json
import time
from typing import Any, Callable, Optional

from . import ratelimit, redact
from .config import secret, settings
from .questions import TEXT_FORM


class TextModelError(RuntimeError):
    pass


def validate_reply(obj: Any, keys: list[str], max_len: int = 2000) -> dict[str, Optional[str]]:
    if not isinstance(obj, dict) or set(obj) != set(keys):
        raise TextModelError("reply keys do not match the requested fields")
    out: dict[str, Optional[str]] = {}
    for k in keys:
        v = obj[k]
        if v is None:
            out[k] = None
        elif isinstance(v, str) and len(v) <= max_len:
            out[k] = v.strip() or None
        else:
            raise TextModelError(f"field {k} is not a string or null")
    return out


def check_schema(obj: Any, schema: dict, path: str = "$") -> None:
    """A small JSON-schema subset (type, required, properties, items, enum, min/maxItems) for planner output."""
    types = schema.get("type")
    if types:
        allowed = types if isinstance(types, list) else [types]
        py = {"object": dict, "array": list, "string": str, "boolean": bool, "null": type(None),
              "number": (int, float), "integer": int}
        if not any(isinstance(obj, py[t]) and not (t in ("number", "integer") and isinstance(obj, bool))
                   for t in allowed if t in py):
            raise TextModelError(f"{path}: expected {allowed}")
    if "enum" in schema and obj not in schema["enum"]:
        raise TextModelError(f"{path}: not one of {schema['enum']}")
    if isinstance(obj, dict):
        for key in schema.get("required", []):
            if key not in obj:
                raise TextModelError(f"{path}: missing {key}")
        for key, sub in schema.get("properties", {}).items():
            if key in obj:
                check_schema(obj[key], sub, f"{path}.{key}")
    if isinstance(obj, list):
        if len(obj) < schema.get("minItems", 0) or len(obj) > schema.get("maxItems", 10 ** 9):
            raise TextModelError(f"{path}: wrong number of items")
        for i, item in enumerate(obj):
            check_schema(item, schema.get("items", {}), f"{path}[{i}]")


def _budget_for(m: dict) -> ratelimit.RateBudget:
    cfg = settings().get("mercury", {}) or {}
    key = f"{m.get('base_url', '')}|{m.get('key_env', '')}"
    return ratelimit.budget_for(key, ratelimit.limits_from(cfg), float(cfg.get("safety", 0.8)))


class TextModel:
    def __init__(self, models: Optional[list[dict]] = None, timeout: Optional[float] = None,
                 llm: Any = None, post: Optional[Callable[[dict, dict], dict]] = None,
                 planner_models: Optional[list[dict]] = None):
        cfg = settings()
        self.models = models if models is not None else list(cfg.get("text_models", []))
        self.planner_models = planner_models if planner_models is not None else list(cfg.get("planner_models", []))
        self.timeout = float(timeout or cfg.get("text_timeout_s", 3.0))
        self.llm = llm  # Hermes ctx.llm: used only with hermes_model: fallback
        self._post = post
        # One connection per purpose: a slow planner call must never queue a field-value call (seen in M1:
        # sharing one HTTP/2 connection made a 0.35 s fill take 2.6 s).
        self._clients: dict[str, Any] = {}
        self._pool = None
        self.calls: list[dict] = []

    @property
    def hermes_fallback(self) -> bool:
        # The browse path uses Mercury only; the host LLM is never a fallback.
        return False

    def available(self) -> bool:
        return bool(self._post is not None or self.hermes_fallback
                    or any(secret(m.get("key_env", "")) for m in self.models))

    def planner_available(self) -> bool:
        return bool(self._post is not None or self.hermes_fallback
                    or any(secret(m.get("key_env", "")) for m in self.planner_models))

    def _http(self, purpose: str = "fill"):
        if purpose not in self._clients:
            import httpx

            self._clients[purpose] = httpx.Client(http2=True, timeout=httpx.Timeout(15.0, connect=5.0),
                                                  limits=httpx.Limits(max_keepalive_connections=8))
        return self._clients[purpose]

    @staticmethod
    def _body(m: dict, system: str, user: dict, schema: Optional[dict] = None) -> dict:
        # Mercury supports strict JSON-schema structured outputs: the provider then guarantees the exact field
        # keys (code still validates). Without a schema: JSON mode.
        if schema is not None and m.get("response_format") == "json_schema":
            fmt: dict = {"type": "json_schema", "json_schema": {"name": "FormValues", "strict": True, "schema": schema}}
        else:
            fmt = {"type": "json_object"}
        body: dict[str, Any] = {
            "model": m["model"], "max_tokens": int(m.get("max_tokens", 800)), "response_format": fmt,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": json.dumps(user)}],
        }
        if "temperature" in m:
            body["temperature"] = m["temperature"]
        if m.get("reasoning_effort"):
            body["reasoning_effort"] = m["reasoning_effort"]
        return body

    def _call_openai(self, m: dict, system: str, user: dict, schema: Optional[dict] = None,
                     purpose: str = "fill") -> Any:
        body = self._body(m, system, user, schema)
        timeout = float(m.get("timeout_s", self.timeout))
        if self._post is not None:
            result = self._post(m, body)
        else:
            key = secret(m.get("key_env", ""))
            if not key:
                raise TextModelError(f"{m.get('key_env')} is not set")
            import httpx

            budget = _budget_for(m)
            text = "".join(msg["content"] for msg in body["messages"])
            queue_s = float(settings().get("mercury.queue_wait_s", 30))
            if purpose == 'decision_fallback':
                queue_s = min(queue_s, float(settings().get('decision_fallback.timeout_s', 5)))
            attempts = 1 if purpose == 'decision_fallback' else 3
            r = None
            # httpx's own timeouts bound the call (connect, then each read): no extra thread per request, so
            # concurrent tasks cannot starve a shared pool (measured in M4: a nested executor deadlocked
            # three parallel form fills until their timeouts).
            for attempt in range(attempts):
                # Wait in line for room in the account's per-minute budget (not part of the call's own timeout:
                # a queued call is slower, a refused one fails the step).
                try:
                    grant = budget.acquire(ratelimit.estimate_tokens(text), body["max_tokens"], timeout=queue_s)
                except ratelimit.RateBudgetTimeout as exc:
                    raise TextModelError(f"{m['model']}: {exc}") from None
                status, usage = 599, None
                try:
                    r = self._http(purpose).post(m["base_url"].rstrip("/") + "/chat/completions", json=body,
                                                 headers={"Authorization": f"Bearer {key}"},
                                                 timeout=httpx.Timeout(timeout, connect=min(timeout, 2.0)))
                    status = r.status_code
                    if not r.is_error:
                        usage = (r.json() or {}).get("usage")
                finally:
                    budget.release(grant, status=status,
                                   input_tokens=(usage or {}).get("prompt_tokens"),
                                   output_tokens=(usage or {}).get("completion_tokens"))
                # A 429 or 503 is transient: the budget has learned a lower cap and paused; queue again.
                if status in (429, 503) and attempt < attempts - 1:
                    continue
                break
            if r is None:
                raise TextModelError(f"{m['model']}: no reply")
            if r.is_error:
                # The provider's own error text (never our request, which may hold page text) helps diagnose.
                detail = ""
                try:
                    err = r.json().get("error")
                    detail = str(err.get("message") if isinstance(err, dict) else err or "")[:160]
                except Exception:
                    pass
                raise TextModelError(f"{m['model']} returned HTTP {r.status_code}" + (f": {detail}" if detail else ""))
            result = r.json()
        content = result["choices"][0]["message"].get("content")
        if not content:
            raise TextModelError(f"{m['model']} returned no content")
        return json.loads(content)

    def _call_llm(self, system: str, user: dict, schema: dict, timeout: float, purpose: str) -> tuple[Any, str]:
        """Hermes's own model (only with hermes_model: fallback). Returns (parsed JSON, "hermes-llm:<provider>/<model>")
        so reports show which model Hermes routed the call to."""
        result = self.llm.complete_structured(instructions=system, input=[{"type": "text", "text": json.dumps(user)}],
                                              json_schema=schema, timeout=timeout, purpose=purpose)
        label = f"hermes-llm:{getattr(result, 'provider', '') or '?'}/{getattr(result, 'model', '') or '?'}"
        if result.parsed is None:
            raise TextModelError(f"{label} returned no JSON")
        return result.parsed, label

    def _record(self, name: str, started: float, ok: bool, error: str = "") -> None:
        entry = {"model": name, "ms": round((time.perf_counter() - started) * 1000), "ok": ok}
        if error:
            entry["error"] = error[:200]
        self.calls.append(entry)

    def fill(self, fields: dict[str, dict], context: dict, system: str = TEXT_FORM) -> dict[str, Optional[str]]:
        """``fields``: index → descriptor (label, type, options...). Returns index → value or None."""
        keys = list(fields)
        if not keys:
            return {}
        user = redact.scrub({**context, "fields": fields})
        schema = {"type": "object", "additionalProperties": False, "required": keys,
                  "properties": {k: {"type": ["string", "null"]} for k in keys}}
        chain: list[tuple[str, Callable[[], Any]]] = [
            (m["model"], (lambda m=m: self._call_openai(m, system, user, schema))) for m in self.models
            if self._post is not None or secret(m.get("key_env", ""))]
        errors: list[str] = []
        values = self._hedged(chain, keys, errors)
        if values is not None:
            return values
        if self.hermes_fallback:
            started = time.perf_counter()
            try:
                parsed, label = self._call_llm(system, user, schema, max(self.timeout, 10), "hermes-swift form values")
                values = validate_reply(parsed, keys)
                self._record(label, started, True)
                return values
            except Exception as exc:
                self._record("hermes-llm", started, False, str(exc))
                errors.append(f"hermes-llm: {exc}")
        raise TextModelError("no text model produced valid values: " + "; ".join(errors))

    def _hedged(self, chain: list, keys: list[str], errors: list[str]) -> Optional[dict]:
        """Models in preference order, each with its own timeout. With several models, if the current one has not
        answered within ``text_hedge_s`` the next starts in parallel; the earliest-preferred valid reply wins."""
        from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait

        if not chain:
            return None
        if len(chain) == 1:
            name, fn = chain[0]
            started = time.perf_counter()
            try:
                out = validate_reply(fn(), keys)
                self._record(name, started, True)
                return out
            except Exception as exc:
                self._record(name, started, False, str(exc))
                errors.append(f"{name}: {exc}")
                return None
        hedge = float(settings().get("text_hedge_s", 0.9))
        if self._pool is None:
            from .platform import MAX_AUTO, parallel_tasks

            # At most two attempts per fill run at once; size for every parallel task doing so.
            self._pool = ThreadPoolExecutor(max_workers=2 * max(parallel_tasks(), MAX_AUTO) + 2,
                                            thread_name_prefix="swift-text")

        def attempt(name, fn):
            started = time.perf_counter()
            try:
                out = validate_reply(fn(), keys)
                self._record(name, started, True)
                return out
            except Exception as exc:  # timeouts, HTTP errors, bad JSON, wrong keys: try the next model
                self._record(name, started, False, str(exc))
                errors.append(f"{name}: {exc}")
                return None

        pending: dict = {}
        next_i = 0
        results: dict[int, Optional[dict]] = {}
        while next_i < len(chain) or pending:
            if next_i < len(chain) and (not pending or len(pending) < 2):
                name, fn = chain[next_i]
                fut = self._pool.submit(attempt, name, fn)
                pending[fut] = next_i
                next_i += 1
            done, _ = wait(list(pending), timeout=hedge if next_i < len(chain) else None,
                           return_when=FIRST_COMPLETED)
            for fut in done:
                results[pending.pop(fut)] = fut.result()
            # Return the most-preferred valid answer once nothing more preferred is still running.
            for i in sorted(results):
                if results[i] is not None and not any(j < i for j in pending.values()):
                    return results[i]
            if not done and len(pending) >= 2:
                continue
        return None

    def plan(self, system: str, user: dict, schema: dict, purpose: str = "hermes-swift planner",
             timeout: float = 30.0, fast: bool = False, max_tokens: Optional[int] = None) -> Any:
        """Structured JSON from Mercury 3 (``planner_models``), validated against ``schema``; Hermes's model only
        with ``hermes_model: fallback``. ``fast`` is for tiebreaks inside a running step (a choice among
        observed candidates, on the critical path): the lowest reasoning effort. ``max_tokens`` caps the
        output this call reserves against the per-minute budget (reviews and tiebreaks answer in a few hundred)."""
        user = redact.scrub(user)
        errors: list[str] = []
        prompt = system + "\nReturn JSON matching this schema exactly: " + json.dumps(schema)
        for m in self.planner_models:
            if self._post is None and not secret(m.get("key_env", "")):
                continue
            started = time.perf_counter()
            m = {**m, "timeout_s": min(float(m.get("timeout_s", timeout)), timeout)}
            if max_tokens:
                m["max_tokens"] = min(int(m.get("max_tokens", max_tokens)), int(max_tokens))
            if fast and m.get("reasoning_effort"):
                m["reasoning_effort"] = "instant"
            try:
                parsed = self._call_openai(m, prompt, user, purpose="plan")
                check_schema(parsed, schema)
                self._record(m["model"], started, True)
                return parsed
            except Exception as exc:
                self._record(m["model"], started, False, str(exc))
                errors.append(f"{m['model']}: {exc}")
        if self.hermes_fallback:
            started = time.perf_counter()
            try:
                parsed, label = self._call_llm(system, user, schema, timeout, purpose)
                check_schema(parsed, schema)
                self._record(label, started, True)
                return parsed
            except Exception as exc:
                self._record("hermes-llm", started, False, str(exc))
                errors.append(f"hermes-llm: {exc}")
        raise TextModelError("no planner model available: " + "; ".join(errors))

    def close(self) -> None:
        for client in self._clients.values():
            client.close()
        if self._pool is not None:
            self._pool.shutdown(wait=False, cancel_futures=True)
