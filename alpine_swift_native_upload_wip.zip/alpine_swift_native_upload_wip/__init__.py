"""hermes-swift plugin registration: tools and the browse skill.

Hermes imports a directory plugin as the package ``hermes_plugins.<slug>``, so everything below is a
relative import. Registration is cheap and makes no network calls (``hermes plugins doctor`` blocks
sockets while it runs): the runtime, Jev client and live view are built on the first tool call.
"""

from __future__ import annotations

from pathlib import Path

from .swift import tools as _tools

TOOLSET = "hermes_swift"
_HERE = Path(__file__).resolve().parent
EMOJI = {"browse": "🌐", "browser_status": "📋", "browser_close_task": "🧹", "identity_list": "🪪"}


def register(ctx):
    handlers = _tools.make_handlers(ctx)
    for name, schema in _tools.SCHEMAS.items():
        ctx.register_tool(name=name, toolset=TOOLSET, schema=schema, handler=handlers[name],
                          description=schema["description"], emoji=EMOJI[name])
    skill = _HERE / "skills" / "browse" / "SKILL.md"
    if skill.exists() and hasattr(ctx, "register_skill"):
        ctx.register_skill("browse", skill, description="When and how to call the hermes-swift browse() tool")
