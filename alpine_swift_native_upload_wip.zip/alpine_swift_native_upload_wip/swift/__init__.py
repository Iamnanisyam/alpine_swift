"""hermes-swift: a fast, verified browser agent for Hermes.

The fast loop (snapshot.js, page.py, jev.py, loop.py) is ported from
browser-use/jev-ultrafast (MIT, Copyright (c) 2026 Browser Use). See THIRD_PARTY_NOTICES.md.
"""

__version__ = "0.1.0"
