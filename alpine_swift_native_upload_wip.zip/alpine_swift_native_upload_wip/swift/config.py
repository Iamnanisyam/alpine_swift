"""Plugin settings: defaults, nested lookup, and a single accessor used by every module.

Hermes stores settings under ``plugins.entries.hermes-swift.settings``; ``ctx.get_config("a.b")``
reads nested keys. Outside Hermes (development, eval, tests) the same keys come from a dict.
"""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Callable, Optional

DEFAULTS: dict[str, Any] = {
    "chrome": {
        "mode": "cloak",
        "profile_dir": "~/.local/share/hermes-cloak",
        "port": 9242,
        "headless": False,  # use Xvfb on servers
        "autostart": False, # start the external Cloak service explicitly
        "disable_password_manager": True,
    },
    "decision_fallback": {"enabled": True, "timeout_s": 5.0},
    "jev_model": "jev-1.14.0",
    "jev_concurrency": 18,
    "jev_url": "https://api.typesafe.ai/v1/systemone",
    "jev_key_env": "TYPESAFE_API_KEY",
    # Browser tasks at once. "auto" sizes it from this machine (cores, free memory) and the Mercury budget:
    # see swift/platform.py, which documents the measurement behind the formula.
    "parallel_tasks": "auto",
    # Mercury 3 is the only model the plugin calls: form values (instant), planner, irreversible-step reviewer
    # and tiebreaks. Measured in M0 (NOTES.md): a 12-field form in ~0.6 s; temperature 0.5-1.0 only.
    "text_models": [
        {"base_url": "https://api.inceptionlabs.ai/v1", "model": "mercury-3", "key_env": "INCEPTION_API_KEY",
         "reasoning_effort": "instant", "temperature": 0.5, "response_format": "json_schema", "max_tokens": 800},
    ],
    "text_timeout_s": 3.0,
    "text_hedge_s": 0.9,  # with more than one text model: start the next if the current one is slow
    # max_tokens is reserved against the per-minute output budget while a call runs (swift/ratelimit.py), so it
    # is sized to measured use: plans 250-350 tokens and reviews 300-330 (incl. ~200 reasoning) at "low".
    "planner_models": [
        {"base_url": "https://api.inceptionlabs.ai/v1", "model": "mercury-3", "key_env": "INCEPTION_API_KEY",
         "reasoning_effort": "low", "temperature": 0.5, "max_tokens": 1500, "timeout_s": 12},
    ],
    # Per call type, the most output a call may reserve (planner calls use planner_models' max_tokens).
    "max_tokens": {"review": 900, "tiebreak": 500},
    # Hermes's own model (ctx.llm) is not used by default: Mercury 3 only. "fallback" = only when Mercury fails.
    "hermes_model": "off",
    # The Mercury account's per-minute limits (docs.inceptionlabs.ai/get-started/rate-limits). The plugin keeps
    # every call inside `safety` of them, so parallel tasks wait for budget instead of drawing HTTP 429.
    # A refusal teaches the real cap (saved in the data dir): the key measured here allowed ~100 requests/min.
    # queue_wait_s: how long a call may wait in line for budget before its step fails.
    "mercury": {"tier": "free", "limits": {}, "safety": 0.8, "queue_wait_s": 30},
    # read_only / reversible apply to operation and target confidence (spec). reversible_operation is the
    # M4-tuned floor for the *operation* head of a reversible step whose target is certain and whose
    # shuffled twin agrees: two valid orderings of reversible steps split the operation head (NOTES.md).
    "thresholds": {"read_only": 0.5, "reversible": 0.7, "reversible_operation": 0.4},
    "failed_task_tab_ttl_minutes": 30,
    "max_steps_per_subgoal": 40,
    "max_steps_per_task": 120,
    "challenge_timeout_s": 300,  # visible CAPTCHA/OTP handoff timeout
    "irreversible_policy": "auto_after_checks",  # review | auto_after_checks
    "max_wait_s": 30,  # total WAIT per subgoal; each wait ends as soon as the page changes
    "max_reviews_per_subgoal": 8,  # irreversible steps reviewed in one subgoal (a checkout needs about four)
    "max_no_change": 6,  # different controls in a row that changed nothing (the same one 3 times stops at once)
    "max_idle_tiebreaks": 2,  # planner tiebreaks in a row whose action changed nothing
    "tiebreak_timeout_s": 8,
    "payment_cap": 0,
    "id_patterns": ["aadhaar", "aadhar", "\\bpan\\b", "passport", "voter", "uid"],
    "liveview": {"enabled": True, "port": 8766},
    "task_contexts": "default",  # auto | context | default; see sessions.py and NOTES.md
    "planner": "never",  # kept for old configuration readers; browse never uses an LLM planner
    "allow_private_urls": False,  # true only for local fixtures; never on the VPS
}


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for key, value in (override or {}).items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _merge(out[key], value)
        else:
            out[key] = value
    return out


class Settings:
    """Read-only view over plugin settings with dotted-key lookup."""

    def __init__(self, values: Optional[dict] = None, getter: Optional[Callable[..., Any]] = None):
        self._values = _merge(DEFAULTS, values or {})
        self._getter = getter

    def get(self, key: str, default: Any = None) -> Any:
        fallback = self._lookup(key, default)
        if self._getter is not None:
            try:
                value = self._getter(key, default=fallback)
            except TypeError:
                value = self._getter(key)
            if value is not None:
                if isinstance(value, dict) and isinstance(fallback, dict):
                    return _merge(fallback, value)
                return value
        return fallback

    def _lookup(self, key: str, default: Any) -> Any:
        node: Any = self._values
        for part in key.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    def as_dict(self) -> dict:
        return copy.deepcopy(self._values)


_SETTINGS = Settings()


def settings() -> Settings:
    return _SETTINGS


def configure(values: Optional[dict] = None, getter: Optional[Callable[..., Any]] = None) -> Settings:
    """Replace the active settings (Hermes: ``getter`` is ``ctx.get_config``; tools and tests: ``values``)."""
    global _SETTINGS
    _SETTINGS = Settings(values, getter)
    return _SETTINGS


def secret(name: str, default: str = "") -> str:
    """An API key or credential by env-var name. Inside Hermes this goes through ``agent.secret_scope.get_secret``
    (the documented plugin path: honours the active profile's ``~/.hermes/.env``); standalone it is the
    process environment. Values are never logged."""
    if not name:
        return default
    try:
        from agent.secret_scope import get_secret  # type: ignore

        value = get_secret(name)
        if value:
            return str(value)
    except ImportError:
        pass
    except Exception:  # an unscoped read under multiplexing: fail closed, never another profile's key
        return default
    return os.environ.get(name, default) or default


def data_dir() -> Path:
    """The plugin's durable data directory (Hermes ``plugin_data_dir`` when available)."""
    override = os.environ.get("HERMES_SWIFT_DATA_DIR")
    if override:
        path = Path(override).expanduser()
    else:
        try:
            from plugins.plugin_storage import plugin_data_dir  # type: ignore

            path = Path(plugin_data_dir("hermes-swift"))
        except Exception:
            path = Path("~/.hermes/plugin-data/hermes-swift").expanduser()
    path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    return path
