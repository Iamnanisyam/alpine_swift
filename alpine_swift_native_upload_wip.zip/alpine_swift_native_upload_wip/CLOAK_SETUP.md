# Configure one browser, one profile, and an optional proxy

## Credentials

`deploy/credentials.env.example` lists the variables. Set the real values only in
`~/.hermes/.env` on your VPS (mode `600`) or export them to the service environment.
The service units read that file. Manual `python -m swift.cloak serve` requires the
variables exported in that shell; merely copying an example file does not load it.

`CLOAK_PROXY_URL` is optional; when used, for example:

```text
CLOAK_PROXY_URL=http://USERNAME:PASSWORD@STATIC_PROXY_HOST:PORT
```

Use the provider's static endpoint and credentials. URL-encode reserved characters
in username/password. Do not use a rotating endpoint or session-rotation options.
HTTP, HTTPS and SOCKS5 schemes with an explicit port are accepted. Residential and
static status are properties of your provider; the application cannot prove them
from a URL. The code never selects another proxy, switches by domain, or falls
back to a direct browser connection. Jev and Mercury API traffic is unchanged;
the configured browser proxy applies to browsing. An unset proxy means a direct browser connection.

Supply `CLOAKBROWSER_LICENSE_KEY` if your Cloak account requires it. Existing
`TYPESAFE_API_KEY` and `INCEPTION_API_KEY` values keep working unchanged.

## Migrate

Stop Hermes and its old browser service normally. Leave the previous Chrome
profile intact. The new profile is `~/.local/share/hermes-cloak`; log in once there.
Do not share it with another browser process. Merge `config.example.yaml` into
Hermes's configuration; keep other plugins and settings. Remove an old
`BROWSER_CDP_URL` override or set it to `http://127.0.0.1:9242`.

The required Hermes browser settings are:

```yaml
browser:
  cloud_provider: local
  cdp_url: http://127.0.0.1:9242
  use_real_profile: false
```

The `chrome` plugin settings namespace and `hermes-chrome.service` filenames are
retained for upgrades; their implementation is now Cloak-only. Legacy
`proxy.enabled: true` or `task_contexts: context` is rejected. Remove those old
settings; all cookies belong to the shared profile.

## Ubuntu/Debian installer

Run `bash deploy/install-ubuntu.sh --server` as the Hermes user. It installs native
browser libraries, Xvfb and Python dependencies, installs this extracted source
through Hermes, and starts the service. The dependency command
`playwright install-deps chromium` installs shared OS libraries only; it does not
download a stock Chromium browser. Do not run `playwright install chromium`.

The installer needs sudo for OS dependencies and the system service. It never
silently falls back to downloading the old repository. `--dry-run --yes` prints
the planned steps. For a desktop use `--desktop`.

## Manual Linux startup

Install dependencies from `requirements-runtime.txt` in the environment used by
Hermes/service. Run as a non-root user, with your credentials exported:

```bash
# Desktop
python -m swift.cloak serve
# Server without a display
xvfb-run -a python -m swift.cloak serve
```

In another shell with the same Hermes configuration:

```bash
python -m swift.cloak status
python tests/cloak_smoke.py
```

Restart Hermes after migration: existing native-tool supervisors may retain their
previous endpoint. Cloak remains running between tasks; task cleanup closes tabs.
`python -m swift.cloak stop` stops the recorded service gracefully.

Alpine/musl: do not run the Ubuntu installer. The Cloak Linux binary needs a
compatible native runtime, typically a glibc-based environment/container. This ZIP
has not been validated on Alpine/musl; no tested Alpine deployment is claimed.
Keep Hermes and Cloak in the same network namespace for the loopback CDP URL.

## Runtime behavior and limits

A profile lock prevents duplicate service owners, and the exact WebSocket identity
plus service PID are checked on attachment. This is an operational ownership
check, not protection from a malicious process running as the same OS user.
The fingerprint seed persists. Swift never creates isolated browser contexts.
Site popups can choose window presentation but remain in the same browser/profile.

Swift tasks are serialized across processes to avoid input/focus conflicts.
External independent drivers must follow the same ownership policy. The prior browser-use fallback is disabled in the normal browse path. External independent drivers must be verified separately.

Swift connects to the existing browser and applies CloakBrowser's Playwright human patch before supported input. This integration still requires live verification. Existing hit-testing, verification, secrets
routing, CAPTCHA/OTP handoff and payment limits remain. Jev image/Box routing has
not been added in this release.

Before production use, verify the live proxy exit IP and perform navigation,
login persistence, Amazon-chat popup, upload/download and vault smoke tests on
your VPS. Offline tests are not a substitute for these deployment checks.
