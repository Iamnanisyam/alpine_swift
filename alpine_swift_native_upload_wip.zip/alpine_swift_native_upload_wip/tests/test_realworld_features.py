"""Offline contracts for what the live-site benchmarks added: Enter, board squares, multi-select, clickable
elements, Jev candidates and the planner tiebreak, repetition guard, vault identifiers (no network)."""

import pytest

from conftest import answers_for, choice, make_page
from swift import forms, jev, loop
from swift.page import _slim


def test_enter_is_its_own_operation_and_risk_depends_on_the_form():
    plain = {"id": "e1", "kind": "enter", "label": "Press Enter in New todo", "role": "textbox", "node": 4}
    in_form = {**plain, "form": 9, "field": {"type": "text"}}
    search = {**plain, "form": 9, "role": "searchbox", "field": {"type": "search"}}
    assert jev.code_risk(plain) == "reversible"
    assert jev.code_risk(search) == "reversible"
    assert jev.code_risk(in_form) == "irreversible"  # Enter may submit the form
    _, targets, _ = jev.action_space([plain, {"id": "wait", "kind": "wait", "label": "Wait"}])
    assert "PRESS_ENTER" in targets


def test_board_squares_are_distinct_targets_on_one_node():
    squares = [{"id": f"e{i}", "kind": "click", "role": "square", "node": 50, "vkey": f"50:{k}",
                "label": f"square {k} (empty)", "point": {"fx": fx, "fy": 0.5}}
               for i, (k, fx) in enumerate([("a1", 0.0625), ("b1", 0.1875)], start=1)]
    elements, targets, _ = jev.action_space(squares)
    assert len(elements) == 2 and set(targets["CLICK"]) == {"1", "2"}


def test_click_point_comes_only_from_the_snapshot_and_is_bounded():
    assert _slim({"node": 1, "kind": "click", "point": {"fx": 0.25, "fy": 0.75}})["point"] == {"fx": 0.25, "fy": 0.75}
    assert "point" not in _slim({"node": 1, "kind": "click", "point": {"fx": "0.2; alert(1)", "fy": 1}})
    assert "point" not in _slim({"node": 1, "kind": "click"})


def test_candidates_rank_concrete_actions_and_never_include_done():
    page = make_page()

    def post(body):
        reply = answers_for(body, "CLICK", "2")
        ops = list(body["questions"]["operation"]["criteria"])
        reply["answers"]["operation"] = {"type": "choice", "choice": "CLICK", "confidence": 0.5,
                                         "probabilities": {o: (0.5 if o == "CLICK" else 0.5 / (len(ops) - 1)) for o in ops}}
        return reply

    d = jev.decide(jev.JevClient(post=post), page, "s", "g", [])
    ids = [c["id"] for c in d["candidates"]]
    assert ids[0] == "e3" and "DONE" not in ids and "BLOCKED" not in ids
    assert all(c["id"] in {a["id"] for a in page["actions"]} for c in d["candidates"])


def test_type_text_twins_agree_on_the_same_form():
    a1 = {"id": "e1", "kind": "fill", "label": "User", "role": "textbox", "node": 1, "form": 7}
    a2 = {"id": "e2", "kind": "fill", "label": "Pass", "role": "textbox", "node": 2, "form": 7}
    page = make_page([a1, a2, {"id": "wait", "kind": "wait", "label": "Wait"}])

    def post(body):
        live = "subgoal_done" in body["questions"]
        return answers_for(body, "TYPE_TEXT", "1" if live else "2")

    d = jev.decide(jev.JevClient(post=post), page, "s", "g", [], shuffled_check=True, seed=2)
    assert d["agree"] is True


def test_repetition_guard_warns_then_stops():
    ctx = loop.LoopContext(page=None, jev=None, goal="g", trace=None)
    fl = loop.FastLoop.__new__(loop.FastLoop)
    fl.ctx = ctx
    step = {"action": "Share via DM", "kind": "click", "choice_node": 5, "url": "u", "page_changed": True}
    for i in range(3):
        ctx.history.append(dict(step, step=i + 1))
    assert fl.repetition_guard() is None and ctx.history[-1].get("note")
    for i in range(2):
        ctx.history.append(dict(step, step=10 + i))
    stop = fl.repetition_guard()
    assert stop and stop.status == loop.BLOCKED


@pytest.mark.parametrize("desc,ok", [
    ({"label": "Username"}, True), ({"label": "Email address", "type": "email"}, True),
    ({"autocomplete": "username"}, True), ({"label": "Login"}, True), ({"label": "First name"}, False),
])
def test_identifier_field_detection(desc, ok):
    assert forms.identifier_field(desc) is ok


class VaultStub:
    def __init__(self):
        self.fills = []

    def login_identifier(self, url):
        return "tomsmith"

    def fill(self, kind, page, obs, probe_node=None):
        self.fills.append((kind, probe_node))
        page.typed[probe_node] = "<from vault>"
        return {"success": True, "filled_fields": 1, "kind": kind}


class Page:
    def __init__(self):
        self.typed = {}

    def fill_node(self, node, text, *, per_key=False, secret=False):
        self.typed[node] = text
        return True

    def read_value(self, node):
        return self.typed.get(node, "")

    def observe(self):
        return login_obs()

    def evaluate(self, expr):
        return "https://site.test/login"

    def focus_node(self, node):
        return True


def login_obs():
    return {"url": "https://site.test/login", "actions": [
        {"id": "e1", "kind": "fill", "node": 1, "form": 3, "label": "Username", "role": "textbox", "value": "",
         "field": {"type": "text", "name": "username"}},
        {"id": "e2", "kind": "fill", "node": 2, "form": 3, "label": "Password", "role": "textbox", "value": "",
         "sensitive": "password", "field": {"type": "password", "required": True}},
        {"id": "e3", "kind": "click", "node": 4, "form": 3, "label": "Login", "role": "button"}],
        "disabled_fields": []}


def test_login_form_uses_vault_identifier_and_vault_password_never_a_model():
    class NoModel:
        def available(self):
            return True

        def fill(self, fields, context):
            raise AssertionError("no text model call is needed for a login form")

    vault, page = VaultStub(), Page()
    record = forms.FormFiller(textmodel=NoModel(), vault=vault).fill_form(page, login_obs(), {"node": 1, "form": 3},
                                                                         goal="Sign in")
    assert page.typed == {1: "tomsmith", 2: "<from vault>"}
    assert vault.fills == [("login", 2)]
    assert record["sources"]["Username"] == "vault_identifier"
    assert "Password: filled from the vault" in record["summary"] and "<from vault>" not in record["summary"]


def test_multiselect_is_left_to_select_operations():
    obs = {"actions": [{"id": "e1", "kind": "select", "node": 1, "form": 2, "label": "Countries → Guam",
                        "value": "gu", "multiple": True, "role": "combobox", "field": {"type": "select-multiple"}}],
           "disabled_fields": []}
    assert forms.collect(obs, {"node": 1, "form": 2}) == []


def test_choice_helper_still_validates():
    with pytest.raises(jev.InvalidAnswer):
        jev.validate_choice(choice(["a"], "b"), {"a"})


# ---------------------------------------------------------------- second live-site round (Oct 2026)


def test_enter_in_a_search_box_with_a_button_is_reversible():
    arxiv = {"id": "e2", "kind": "enter", "label": "Press Enter in Search arXiv", "role": "textbox", "node": 4,
             "form": 9, "field": {"type": "text", "search": True}}
    login = {**arxiv, "label": "Press Enter in Username", "field": {"type": "text"}}
    assert jev.code_risk(arxiv) == "reversible"
    assert jev.code_risk(login) == "irreversible"


@pytest.mark.parametrize("label,paying", [
    ("Pay ₹1,250", True), ("Place order", True), ("Proceed to pay", True),
    # A container's text that happens to contain a payment word is content, not a payment control.
    ("todos New Todo Input Toggle All Input buy milk Delete todo pay rent Delete todo", False),
])
def test_payment_needs_a_short_imperative_label(label, paying):
    assert jev.is_payment({"kind": "click", "role": "button", "label": label}) is paying
    assert jev.code_risk({"kind": "click", "role": "clickable", "label": label}) == "irreversible"


def test_password_manager_preferences_merge_and_keep_the_rest(tmp_path):
    from swift.chrome import PASSWORD_PREFS, agent_preferences

    prefs = tmp_path / "Default" / "Preferences"
    prefs.parent.mkdir(parents=True)
    prefs.write_text('{"intl": {"accept_languages": "en-IN,en"}, "profile": {"name": "Agent"}}')
    assert agent_preferences(tmp_path) is True
    import json

    data = json.loads(prefs.read_text())
    assert data["intl"] == {"accept_languages": "en-IN,en"} and data["profile"]["name"] == "Agent"
    assert data["credentials_enable_service"] is False
    assert data["profile"]["password_manager_enabled"] is False
    assert data["profile"]["password_manager_leak_detection"] is False
    assert agent_preferences(tmp_path) is False  # already set: the file is not rewritten
    assert agent_preferences(tmp_path / "other", enabled=False) is False
    assert PASSWORD_PREFS["credentials_enable_service"] is False


class _WaitPage:
    def __init__(self):
        self.waits = []

    def act(self, action, obs):
        self.waits.append(action["wait_s"])
        return {"executed": action["id"]}


def _fast(page, history=None):
    ctx = loop.LoopContext(page=page, jev=None, goal="g", trace=None, history=history or [])
    fl = loop.FastLoop.__new__(loop.FastLoop)
    fl.ctx, fl.decision, fl.covered, fl.waited_s, fl.max_wait_s = ctx, None, 0, 0.0, 30.0
    fl.subgoal = loop.Subgoal("s", {})
    return fl


def test_waits_grow_and_are_not_a_repetition():
    page = _WaitPage()
    fl = _fast(page)
    wait = {"id": "wait", "kind": "wait", "label": "Wait for the page to update"}
    for i in range(4):
        rec = fl.execute({"action": wait, "operation": "WAIT"}, {"url": "u"})
        assert isinstance(rec, dict)
        fl.ctx.history.append({"step": i + 1, "action": wait["label"], "kind": "wait", "operation": "WAIT",
                               "choice_node": None, "url": "u", "page_changed": False})
        assert fl.repetition_guard() is None
    assert page.waits == [1.0, 2.0, 3.0, 4.0]
    assert fl.no_change_stop() is None  # waits never count as "changed nothing"


def test_waiting_stops_at_the_time_budget():
    fl = _fast(_WaitPage())
    fl.waited_s = 30.0
    out = fl.execute({"action": {"id": "wait", "kind": "wait", "label": "Wait"}, "operation": "WAIT"}, {"url": "u"})
    assert isinstance(out, loop.LoopResult) and out.status == loop.BLOCKED


def test_a_covered_target_is_noted_then_stops():
    from swift.page import Covered

    class CoveredPage:
        def act(self, action, obs):
            raise Covered("Search", "Press Enter to search")

    fl = _fast(CoveredPage())
    click = {"id": "e5", "kind": "click", "label": "Search", "node": 5}
    assert fl.execute({"action": click, "operation": "CLICK"}, {"url": "u"}) == "stale"
    note = fl.ctx.history[-1]
    assert note["note"] and "covered by 'Press Enter to search'" in note["action"]
    assert fl.execute({"action": click, "operation": "CLICK"}, {"url": "u"}) == "stale"
    out = fl.execute({"action": click, "operation": "CLICK"}, {"url": "u"})
    assert isinstance(out, loop.LoopResult) and out.status == loop.BLOCKED


def test_login_fields_outside_a_form_element_share_a_group():
    # The snapshot gives fields without a <form> the id of their nearest ancestor holding two text-like fields;
    # the filler then treats username and password as one login form (vault identifier + vault password).
    obs = login_obs()
    for a in obs["actions"]:
        a["form"] = 77  # an implicit group id, as the snapshot assigns it
    vault, page = VaultStub(), Page()
    record = forms.FormFiller(textmodel=None, vault=vault).fill_form(page, obs, {"node": 1, "form": 77},
                                                                    goal="Log in to the practice test site")
    assert page.typed == {1: "tomsmith", 2: "<from vault>"} and record["sources"]["Username"] == "vault_identifier"


def test_vault_fill_does_not_dispatch_hermes_external_fill():
    from swift import vaultfill
    def dispatch(tool, args):
        assert args['action'] == 'list'
        return {'items': []}
    out = vaultfill.VaultFill(dispatch).fill('login', object(), {'url': 'https://a.test'}, 3)
    assert not out['success'] and 'origin-bound' in out['needs_user']


def test_irreversible_actions_require_user_review_without_mercury():
    from swift.controller import Controller
    ctl = Controller.__new__(Controller)
    verdict = ctl.review('complete checkout', loop.Subgoal('checkout', {}),
                         {'action': {'label': 'Continue', 'kind': 'click'}}, {})
    assert verdict['to_user'] and not verdict['approve']
