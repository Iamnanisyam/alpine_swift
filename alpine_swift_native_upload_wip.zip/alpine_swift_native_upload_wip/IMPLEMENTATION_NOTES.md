# Alpine Swift: implementation and verification notes

**This build is work in progress, not production-ready.** The new tests use fakes. No real CloakBrowser, Hermes vault, VNC, model API, CAPTCHA or OTP integration test has been run for this build.

## Changes in this pass

### Latest fallback and file-classification changes

`decision_fallback.enabled` defaults to `true` and `decision_fallback.timeout_s` to `5`. The normal path remains Jev operation/target selection and Mercury text generation. If Jev is unavailable, returns malformed data, or a decision fails the low-confidence gate, `DecisionFallback` makes a direct Mercury 3 JSON request for one **existing observed action ID**, risk and confidence. This is the user's explicitly requested exception to Mercury's usual TYPE_TEXT-only role. Code validates IDs and shape, rechecks page freshness and risk, and keeps independent success predicates. A fallback's self-reported confidence is not independent Jev agreement: in `auto_after_checks` mode, non-payment irreversible actions additionally require a supplied success predicate and code-level readiness check; otherwise they require review. Payment actions still require review. Its per-operation network timeout and queue wait are capped, with one HTTP attempt; this is not a guaranteed end-to-end latency limit. Set `decision_fallback.enabled: false` to disable it.

`swift/upload_classification.py:map_files()` is a preparatory API, **not connected to the browser loop**. It asks Jev to map all explicitly supplied filenames to observed field IDs in one request and falls back to one direct model request if Jev fails or confidence is low. It validates output and rejects invented IDs or duplicate file assignments. Only basenames are sent to model providers. No files are uploaded by this function. It is not evidence of a native chooser implementation or end-to-end multi-file support.


- `swift/vaultfill.py` resolves an origin-bound Hermes vault item inside the plugin using Hermes backend APIs. It checks item kind and exact allowed origin, uses Hermes's classifier to select the observed field, checks the backend snapshot inside `fill_context()`, registers secret redactions before input, and calls `Page.fill_vault_value()` rather than dispatching Hermes's browser `fill` action. The patched Playwright adapter checks the live page origin again immediately before filling a temporary selector for the observed node. The normal host metadata `browser_vault list` call remains. Payment fields retain Hermes's explicit confirmation; denial occurs before resolving the card. Locked vaults, missing/unsupported fields and unavailable/incompatible Hermes APIs still stop the fill. Checkout `select` controls and complex cross-origin checkout frames have not been verified.
- `Page.set_value_native()` uses the patched Playwright locator `fill()` and reads back the result. Native HTML date/time formats and Cloak's patch behavior vary by browser; this has **not** been confirmed to operate a native picker UI or to work for every date/time input.
- Native chooser upload is **not implemented**. `Page.set_files()` explicitly refuses the operation, and Jev is not offered an `UPLOAD` action. Playwright's documented `FileChooser.set_files()` sets the file input programmatically; replacing `set_input_files()` with it would not meet the request to operate the native OS dialog. Implementing that dialog requires an OS-level accessibility/input integration that is not present in this project and whose behavior cannot be verified here. The old direct file assignment path has been disabled rather than silently used. See [Playwright FileChooser](https://playwright.dev/python/docs/api/class-filechooser).
- Challenge handoff requires both Jev's current decision to identify CAPTCHA/OTP as blocking the goal and `swift/challenge.js` to find currently visible, unobscured challenge evidence on the same fresh page. A visible unused widget, provider badge, or Jev suspicion alone does not trigger handoff. The loop waits in the same tab, checks twice for clearance, takes a fresh observation, and discards pending decisions. `challenge_timeout_s` defaults to 300 seconds; on timeout the task ends blocked and its failed tab is retained under existing WIP tab policy. Detection is heuristic: false positives and missed cross-origin/custom challenges remain possible, and a filled OTP field remains a challenge until the field disappears or is disabled. There is no universal proof that a detected challenge actually blocks the user's current objective.
- `irreversible_policy` defaults to `auto_after_checks`. A non-payment irreversible action can proceed only when the goal has a code-level success predicate and the existing risk, confidence, shuffled-agreement and form-readiness checks pass. Set it to `review` to require user review for all such actions. Payments retain the existing review path, and Hermes separately confirms payment-card filling. No LLM is used to replace these checks. Missing credentials, blocked sites, timeouts and low confidence can still stop or require user input; the system cannot guarantee that only CAPTCHA/OTP ever require intervention.
- `cursor.js` is initialized on new documents/frames and reinjected into accessible frames on action attachment; its label follows page mouse events, shows a short redacted action label and result, and avoids intercepting clicks. It is a DOM badge, **not a native pointer**. Visibility in cross-origin frames, browser chrome, and real VNC clients still requires testing.
- Jev remains the primary indexed decision engine; Mercury generates text and can now select one step only when the configured direct fallback is triggered. Independent code predicates and redaction are retained. Proxy remains optional, while configured proxies use GeoIP and no intentional direct fallback.

## Setup and launch

As the non-root Hermes user, from the project folder:

```bash
python -m pip install -r requirements-runtime.txt
python -m swift setup
python -m swift.cloak serve
```

The setup command prompts for both model keys and an optional proxy; it writes `$HERMES_HOME/.env` (default `~/.hermes/.env`) with owner-only permissions and creates or reuses the profile seed. It does not launch a browser. Ensure Hermes and the launcher use the same environment and profile. Existing systemd units must be inspected for their user, `EnvironmentFile`, and display settings. Chromium 155+ may require a CloakBrowser license.

Example plugin settings:

```yaml
plugins:
  entries:
    hermes-swift:
      settings:
        challenge_timeout_s: 300
        decision_fallback:
          enabled: true
          timeout_s: 5.0
        irreversible_policy: auto_after_checks  # or review
```

## Native pointer via VNC/noVNC: test on your Ubuntu server

These are an **untested setup recipe**, not a claim that cursor rendering is verified on your system. Install `xvfb`, `openbox`, `x11vnc`, `novnc`, and `websockify`. As the browser user, run `x11vnc -storepasswd` first and protect the password file. Then:

```bash
Xvfb :99 -screen 0 1280x800x24 -nolisten tcp &
export DISPLAY=:99
openbox &
x11vnc -display "$DISPLAY" -localhost -rfbauth "$HOME/.vnc/passwd" -forever -shared -cursor most &
websockify --web=/usr/share/novnc 127.0.0.1:6080 127.0.0.1:5900 &
python -m swift.cloak serve
```

From the Windows client, open an SSH tunnel with `ssh -L 6080:127.0.0.1:6080 USER@SERVER`, then visit `http://127.0.0.1:6080/vnc.html` locally and authenticate. Confirm in the viewer that the **native X cursor**, not only the badge, moves. Do not start the systemd browser simultaneously. Bind CDP/VNC/noVNC to loopback and use authenticated SSH.

## Tests and live verification

```bash
python -m unittest discover -s checks -v
node checks/challenge_detector_test.js
python -m pytest tests -q
node --check swift/snapshot.js
node --check swift/challenge.js
node --check swift/cursor.js
bash -n deploy/install-ubuntu.sh
# After starting the one existing browser service on the displayed desktop:
python tests/humanized_smoke.py
```

Thirty-two offline contract tests and the JavaScript challenge scenarios passed for this pass. The smoke script opens and closes temporary tabs in the existing session; it has not been run here and does not test the vault, VNC, model APIs or CAPTCHA. With a test account and test site, additionally verify: an unlocked origin-bound vault login and a denied payment, date/time fields, frames/popups/navigation, native VNC cursor, CAPTCHA/OTP detection and solve/timeout on the *same tab*, independent final success predicates, and optional model requests. Never put real secrets in test logs or screenshots.

Before deployment, run the complete pytest suite and live tests on the actual installed Hermes/Cloak versions. In particular verify imported Hermes backend APIs and classifier shapes, target matching, payment confirmation, page-origin races, patch markers and action behavior, date/time behavior, a future native OS upload implementation, frame targeting, redaction for short secrets, challenge false positives/negatives and timing, browser disconnects, VNC security, Chromium license/version, proxy leakage, multi-tab performance, and model compatibility. Additional independent CDP clients do not automatically use this adapter. Jev Images/Box remains unimplemented. The separate upload classifier has not been tested against a real TypeSafe or Mercury account. The WIP still serializes full tasks under the shared input lock; fast concurrent multi-tab throughput is not verified. No test establishes undetectability or guarantees production readiness.
# Native-dialog upload follow-up

Native uploads and integration of the file classifier into agent execution remain
**unimplemented**. The requested combination of a real OS chooser and only
humanized Playwright input has no demonstrated implementation: Playwright's
file chooser API sets the file input, while Playwright's mouse and keyboard
operate browser content rather than the operating system's chooser. A genuine
native chooser requires a separately verified desktop accessibility or input
driver, plus explicit permission to use that path. No `FileChooser.set_files`,
direct file-input assignment, or fake native-dialog success was added. Uploads
remain fail-closed, and upload is not offered to Jev as an executable action.

The standalone batched classifier now falls back once when Jev assigns the same
file to multiple fields, and explicitly redacts its question payload as well as
its state. It still does not upload files or run from the agent loop. The
existing classifier tests and a new duplicate-mapping fallback test are offline
only. A desktop driver, chooser focus and ownership, dialog cancellation, file
selection verification, multiple fields, CloakBrowser behavior, and the actual
browser session all still require integration and live verification.

